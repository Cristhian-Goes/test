/*
  # Corrigir políticas RLS e estrutura do banco

  1. Remover políticas existentes
  2. Criar políticas corretas para todas as tabelas
  3. Garantir acesso completo para usuários autenticados
  4. Adicionar índices para performance
*/

-- Remover políticas existentes
DROP POLICY IF EXISTS "Users can manage all data" ON clientes;
DROP POLICY IF EXISTS "Users can manage all data" ON colaboradores;
DROP POLICY IF EXISTS "Users can manage all data" ON orcamentos;
DROP POLICY IF EXISTS "Users can manage all data" ON despesas;
DROP POLICY IF EXISTS "Users can manage all data" ON atendimentos;
DROP POLICY IF EXISTS "Users can manage all data" ON pedidos;
DROP POLICY IF EXISTS "Users can manage all data" ON veiculos;
DROP POLICY IF EXISTS "Users can manage all data" ON ferramentas;
DROP POLICY IF EXISTS "Users can manage all data" ON estabelecimentos;
DROP POLICY IF EXISTS "Users can manage all data" ON movimentos_financeiros;

-- Políticas para clientes
CREATE POLICY "Enable all operations for authenticated users" ON clientes
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Políticas para colaboradores
CREATE POLICY "Enable all operations for authenticated users" ON colaboradores
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Políticas para orçamentos
CREATE POLICY "Enable all operations for authenticated users" ON orcamentos
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Políticas para despesas
CREATE POLICY "Enable all operations for authenticated users" ON despesas
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Políticas para atendimentos
CREATE POLICY "Enable all operations for authenticated users" ON atendimentos
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Políticas para pedidos
CREATE POLICY "Enable all operations for authenticated users" ON pedidos
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Políticas para veículos
CREATE POLICY "Enable all operations for authenticated users" ON veiculos
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Políticas para ferramentas
CREATE POLICY "Enable all operations for authenticated users" ON ferramentas
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Políticas para estabelecimentos
CREATE POLICY "Enable all operations for authenticated users" ON estabelecimentos
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Políticas para movimentos financeiros
CREATE POLICY "Enable all operations for authenticated users" ON movimentos_financeiros
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Adicionar índices para performance
CREATE INDEX IF NOT EXISTS idx_clientes_nome ON clientes(nome);
CREATE INDEX IF NOT EXISTS idx_orcamentos_status ON orcamentos(status);
CREATE INDEX IF NOT EXISTS idx_pedidos_status ON pedidos(status);
CREATE INDEX IF NOT EXISTS idx_despesas_status ON despesas(status);
CREATE INDEX IF NOT EXISTS idx_atendimentos_data ON atendimentos(data);