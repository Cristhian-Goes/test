/*
  # Adicionar controle de saldo separado (conta e dinheiro)

  1. Alterações
    - Adicionar coluna `tipo_saldo` na tabela `movimentos_financeiros`
    - Adicionar coluna `tipo_saldo` na tabela `pedidos`
    - Criar tabela `configuracao_saldos` para armazenar saldos iniciais

  2. Segurança
    - Habilitar RLS na nova tabela
    - Adicionar políticas para usuários autenticados
*/

-- Adicionar coluna tipo_saldo na tabela movimentos_financeiros
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'movimentos_financeiros' AND column_name = 'tipo_saldo'
  ) THEN
    ALTER TABLE movimentos_financeiros ADD COLUMN tipo_saldo text DEFAULT 'conta' CHECK (tipo_saldo IN ('conta', 'dinheiro'));
  END IF;
END $$;

-- Adicionar coluna tipo_saldo na tabela pedidos
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pedidos' AND column_name = 'tipo_saldo'
  ) THEN
    ALTER TABLE pedidos ADD COLUMN tipo_saldo text DEFAULT 'conta' CHECK (tipo_saldo IN ('conta', 'dinheiro'));
  END IF;
END $$;

-- Criar tabela para configuração de saldos iniciais
CREATE TABLE IF NOT EXISTS configuracao_saldos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  saldo_conta decimal(10,2) DEFAULT 14670.00,
  saldo_dinheiro decimal(10,2) DEFAULT 8734.00,
  data_atualizacao date DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE configuracao_saldos ENABLE ROW LEVEL SECURITY;

-- Política de acesso
CREATE POLICY "Allow all for authenticated users" ON configuracao_saldos
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Trigger para updated_at
CREATE TRIGGER update_configuracao_saldos_updated_at
  BEFORE UPDATE ON configuracao_saldos
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Inserir configuração inicial se não existir
INSERT INTO configuracao_saldos (saldo_conta, saldo_dinheiro)
SELECT 14670.00, 8734.00
WHERE NOT EXISTS (SELECT 1 FROM configuracao_saldos);