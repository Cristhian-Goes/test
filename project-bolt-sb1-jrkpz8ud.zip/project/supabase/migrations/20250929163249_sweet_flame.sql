/*
  # Reset Database - Limpar todos os dados

  Esta migração remove todos os dados das tabelas, mantendo apenas a estrutura.
  
  ## Tabelas que serão limpas:
  1. parcelas_cartao - Parcelas de cartão de crédito
  2. parcelas_boleto - Parcelas de boleto
  3. pedidos - Pedidos de produção
  4. orcamentos - Orçamentos gerados
  5. atendimentos - Histórico de atendimentos
  6. movimentos_financeiros - Movimentações financeiras
  7. despesas - Controle de despesas
  8. ferramentas - Cadastro de ferramentas
  9. veiculos - Cadastro de veículos
  10. colaboradores - Cadastro de colaboradores
  11. estabelecimentos - Cadastro de estabelecimentos
  12. clientes - Cadastro de clientes
  13. configuracao_saldos - Configurações de saldo

  ## Importante:
  - A ordem de exclusão respeita as dependências de chaves estrangeiras
  - Todas as tabelas serão completamente zeradas
  - A estrutura das tabelas será mantida
*/

-- Desabilitar verificações de chave estrangeira temporariamente
SET session_replication_role = replica;

-- Limpar tabelas dependentes primeiro (ordem importante)
DELETE FROM parcelas_cartao;
DELETE FROM parcelas_boleto;
DELETE FROM pedidos;
DELETE FROM orcamentos;
DELETE FROM atendimentos;
DELETE FROM movimentos_financeiros;
DELETE FROM despesas;
DELETE FROM ferramentas;
DELETE FROM veiculos;
DELETE FROM colaboradores;
DELETE FROM estabelecimentos;
DELETE FROM clientes;
DELETE FROM configuracao_saldos;

-- Reabilitar verificações de chave estrangeira
SET session_replication_role = DEFAULT;

-- Resetar sequências (se houver)
-- Como estamos usando UUIDs, não há sequências para resetar

-- Inserir configuração inicial de saldos zerada
INSERT INTO configuracao_saldos (
  saldo_conta,
  saldo_dinheiro,
  data_atualizacao
) VALUES (
  0.00,
  0.00,
  CURRENT_DATE
);