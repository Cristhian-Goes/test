/*
  # Corrigir colunas da tabela parcelas_cartao

  1. Alterações
    - Adicionar coluna `parcelas_cartao` na tabela `orcamentos` se não existir
    - Garantir que todas as colunas necessárias existam

  2. Segurança
    - Manter RLS existente
*/

-- Adicionar coluna parcelas_cartao na tabela orcamentos se não existir
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orcamentos' AND column_name = 'parcelas_cartao'
  ) THEN
    ALTER TABLE orcamentos ADD COLUMN parcelas_cartao integer;
  END IF;
END $$;

-- Garantir que a coluna data_recebimento existe na tabela parcelas_boleto
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'parcelas_boleto' AND column_name = 'data_recebimento'
  ) THEN
    ALTER TABLE parcelas_boleto ADD COLUMN data_recebimento date;
  END IF;
END $$;