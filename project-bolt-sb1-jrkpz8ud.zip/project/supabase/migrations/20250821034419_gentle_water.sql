/*
  # Update atendimentos tipo constraint

  1. Changes
    - Drop existing check constraint for tipo column
    - Add new check constraint allowing 'interno' and 'externo' values
    - This aligns the database schema with frontend application values

  2. Security
    - No RLS changes needed (existing policies remain)
*/

-- Drop the existing check constraint
ALTER TABLE atendimentos DROP CONSTRAINT IF EXISTS atendimentos_tipo_check;

-- Add new check constraint with correct values
ALTER TABLE atendimentos ADD CONSTRAINT atendimentos_tipo_check 
CHECK (tipo = ANY (ARRAY['interno'::text, 'externo'::text, 'visita'::text, 'ligacao'::text, 'email'::text, 'whatsapp'::text]));