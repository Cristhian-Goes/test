/*
  # Atualizar tabela de atendimentos

  1. Alterações na tabela atendimentos
    - Remove coluna tipo_pagamento (não é mais necessária)
    - Mantém estrutura existente

  2. Alterações na tabela orcamentos  
    - Adiciona coluna tipo_atendimento para identificar se é interno ou externo
    - Remove coluna tamanho_servico (não é mais necessária)

  3. Segurança
    - Mantém RLS existente
    - Mantém políticas existentes
*/

-- Remover coluna tipo_pagamento da tabela atendimentos
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'atendimentos' AND column_name = 'tipo_pagamento'
  ) THEN
    ALTER TABLE atendimentos DROP COLUMN tipo_pagamento;
  END IF;
END $$;

-- Adicionar coluna tipo_atendimento na tabela orcamentos
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orcamentos' AND column_name = 'tipo_atendimento'
  ) THEN
    ALTER TABLE orcamentos ADD COLUMN tipo_atendimento text DEFAULT 'interno';
    ALTER TABLE orcamentos ADD CONSTRAINT orcamentos_tipo_atendimento_check 
      CHECK (tipo_atendimento = ANY (ARRAY['interno'::text, 'externo'::text]));
  END IF;
END $$;

-- Remover coluna tamanho_servico da tabela orcamentos
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orcamentos' AND column_name = 'tamanho_servico'
  ) THEN
    ALTER TABLE orcamentos DROP COLUMN tamanho_servico;
  END IF;
END $$;

-- Adicionar colunas de referência na tabela movimentos_financeiros para integração
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'movimentos_financeiros' AND column_name = 'referencia_id'
  ) THEN
    ALTER TABLE movimentos_financeiros ADD COLUMN referencia_id uuid;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'movimentos_financeiros' AND column_name = 'referencia_tipo'
  ) THEN
    ALTER TABLE movimentos_financeiros ADD COLUMN referencia_tipo text;
    ALTER TABLE movimentos_financeiros ADD CONSTRAINT movimentos_financeiros_referencia_tipo_check 
      CHECK (referencia_tipo = ANY (ARRAY['orcamento'::text, 'pedido'::text, 'despesa'::text]));
  END IF;
END $$;