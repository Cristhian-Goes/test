/*
  # Corrigir fluxo de orçamentos e financeiro

  1. Alterações na tabela orcamentos
    - Adicionar coluna tipo_atendimento se não existir
    - Simplificar status para apenas 'pendente', 'aceito', 'recusado'
    - Remover campos de pagamento desnecessários

  2. Segurança
    - Manter RLS existente
*/

-- Garantir que a coluna tipo_atendimento existe na tabela orcamentos
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orcamentos' AND column_name = 'tipo_atendimento'
  ) THEN
    ALTER TABLE orcamentos ADD COLUMN tipo_atendimento text DEFAULT 'interno';
  END IF;
END $$;

-- Adicionar constraint para tipo_atendimento se não existir
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE table_name = 'orcamentos' AND constraint_name = 'orcamentos_tipo_atendimento_check'
  ) THEN
    ALTER TABLE orcamentos ADD CONSTRAINT orcamentos_tipo_atendimento_check 
      CHECK (tipo_atendimento = ANY (ARRAY['interno'::text, 'externo'::text]));
  END IF;
END $$;

-- Atualizar constraint de status para simplificar
DO $$
BEGIN
  -- Remover constraint existente se existir
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE table_name = 'orcamentos' AND constraint_name = 'orcamentos_status_check'
  ) THEN
    ALTER TABLE orcamentos DROP CONSTRAINT orcamentos_status_check;
  END IF;
  
  -- Adicionar nova constraint simplificada
  ALTER TABLE orcamentos ADD CONSTRAINT orcamentos_status_check 
    CHECK (status = ANY (ARRAY['pendente'::text, 'aceito'::text, 'recusado'::text]));
END $$;