/*
  # Zerar saldos iniciais do sistema

  1. Configuração de Saldos
    - Zerar saldo_conta para 0
    - Zerar saldo_dinheiro para 0
    - Atualizar data para hoje
  
  2. Objetivo
    - Sistema começar do zero
    - Considerar apenas movimentações futuras
    - Dashboard e Financeiro mostrar valores reais
*/

-- Limpar configurações de saldo existentes
DELETE FROM configuracao_saldos;

-- Inserir configuração inicial zerada
INSERT INTO configuracao_saldos (
  saldo_conta,
  saldo_dinheiro,
  data_atualizacao
) VALUES (
  0.00,
  0.00,
  CURRENT_DATE
);