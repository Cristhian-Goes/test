/*
  # Criar função para gerar parcelas de crédito no dia 1º de cada mês

  1. Nova Função
    - `create_credit_installments` - Cria parcelas de crédito com data de recebimento no dia 1º de cada mês
    - Primeira parcela: 1º dia do mês seguinte à aprovação
    - Demais parcelas: 1º dia de cada mês subsequente
    
  2. Comportamento
    - Aceita: orcamento_id, numero_parcelas, valor_total
    - Calcula valor por parcela (valor_total / numero_parcelas)
    - Define data_recebimento como 1º dia do mês seguinte para primeira parcela
    - Demais parcelas: adiciona 1 mês a cada iteração
    - Cria todas as parcelas com status 'pendente'
*/

-- Função para criar parcelas de crédito no dia 1º de cada mês
CREATE OR REPLACE FUNCTION create_credit_installments(
  p_orcamento_id uuid,
  p_numero_parcelas integer,
  p_valor_total numeric
)
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  v_valor_parcela numeric;
  v_data_primeira_parcela date;
  v_contador integer;
BEGIN
  -- Calcular valor de cada parcela
  v_valor_parcela := p_valor_total / p_numero_parcelas;
  
  -- Data da primeira parcela: 1º dia do mês seguinte
  v_data_primeira_parcela := date_trunc('month', CURRENT_DATE + interval '1 month')::date;
  
  -- Criar todas as parcelas
  FOR v_contador IN 1..p_numero_parcelas LOOP
    INSERT INTO parcelas_cartao (
      orcamento_id,
      numero_parcela,
      total_parcelas,
      valor,
      data_recebimento,
      status
    ) VALUES (
      p_orcamento_id,
      v_contador,
      p_numero_parcelas,
      v_valor_parcela,
      v_data_primeira_parcela + ((v_contador - 1) || ' months')::interval,
      'pendente'
    );
  END LOOP;
END;
$$;