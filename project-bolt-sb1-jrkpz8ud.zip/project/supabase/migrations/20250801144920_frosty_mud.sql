/*
  # Add tipo_pagamento column to atendimentos table

  1. Changes
    - Add `tipo_pagamento` column to `atendimentos` table
    - Set default value to 'dinheiro'
    - Add check constraint for valid payment types

  2. Security
    - No RLS changes needed (table already has policies)
*/

-- Add tipo_pagamento column to atendimentos table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'atendimentos' AND column_name = 'tipo_pagamento'
  ) THEN
    ALTER TABLE atendimentos ADD COLUMN tipo_pagamento text DEFAULT 'dinheiro'::text NOT NULL;
  END IF;
END $$;

-- Add check constraint for valid payment types
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.constraint_column_usage
    WHERE table_name = 'atendimentos' AND constraint_name = 'atendimentos_tipo_pagamento_check'
  ) THEN
    ALTER TABLE atendimentos ADD CONSTRAINT atendimentos_tipo_pagamento_check 
    CHECK (tipo_pagamento = ANY (ARRAY['dinheiro'::text, 'pix'::text, 'debito'::text, 'credito'::text, 'boleto'::text, 'transferencia'::text]));
  END IF;
END $$;