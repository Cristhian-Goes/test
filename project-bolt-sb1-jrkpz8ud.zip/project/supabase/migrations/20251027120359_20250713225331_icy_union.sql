/*
  # Sistema de Gestão - Gráfica

  1. New Tables
    - `clientes` - Cadastro de clientes
    - `colaboradores` - Cadastro de colaboradores  
    - `veiculos` - Cadastro de veículos
    - `ferramentas` - Cadastro de ferramentas
    - `estabelecimentos` - Cadastro de estabelecimentos
    - `atendimentos` - Registro de atendimentos
    - `orcamentos` - Orçamentos com sistema de pagamento
    - `pedidos` - Pedidos de produção
    - `despesas` - Controle de despesas
    - `movimentos_financeiros` - Fluxo de caixa

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Clientes
CREATE TABLE IF NOT EXISTS clientes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  cpf_cnpj text NOT NULL,
  endereco jsonb NOT NULL DEFAULT '{}',
  telefone text NOT NULL,
  email text DEFAULT '',
  observacoes text DEFAULT '',
  data_cadastro date DEFAULT CURRENT_DATE,
  despesas_associadas decimal(10,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Colaboradores
CREATE TABLE IF NOT EXISTS colaboradores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  funcao text NOT NULL,
  salario decimal(10,2) NOT NULL DEFAULT 0,
  telefone text NOT NULL,
  email text NOT NULL,
  data_entrada date NOT NULL,
  status text NOT NULL DEFAULT 'ativo' CHECK (status IN ('ativo', 'inativo')),
  despesas_associadas decimal(10,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Veículos
CREATE TABLE IF NOT EXISTS veiculos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  placa text NOT NULL,
  modelo text NOT NULL,
  ano integer NOT NULL,
  motorista_responsavel text NOT NULL,
  status text NOT NULL DEFAULT 'ativo' CHECK (status IN ('ativo', 'manutencao', 'inativo')),
  despesas_associadas decimal(10,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Ferramentas
CREATE TABLE IF NOT EXISTS ferramentas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  descricao text NOT NULL,
  quantidade integer NOT NULL DEFAULT 1,
  data_compra date NOT NULL,
  proxima_manutencao date NOT NULL,
  despesas_associadas decimal(10,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Estabelecimentos
CREATE TABLE IF NOT EXISTS estabelecimentos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  endereco jsonb NOT NULL DEFAULT '{}',
  cnpj text NOT NULL,
  responsavel text NOT NULL,
  telefone text NOT NULL,
  email text DEFAULT '',
  status text NOT NULL DEFAULT 'ativo' CHECK (status IN ('ativo', 'inativo')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Atendimentos
CREATE TABLE IF NOT EXISTS atendimentos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cliente_id uuid REFERENCES clientes(id) ON DELETE CASCADE,
  cliente_nome text NOT NULL,
  tipo text NOT NULL CHECK (tipo IN ('visita', 'ligacao', 'email', 'whatsapp', 'interno', 'externo')),
  descricao text NOT NULL,
  data timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'em_andamento' CHECK (status IN ('em_andamento', 'finalizado', 'aguardando_orcamento')),
  responsavel text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Orçamentos com sistema de pagamento
CREATE TABLE IF NOT EXISTS orcamentos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cliente_id uuid REFERENCES clientes(id) ON DELETE CASCADE,
  cliente_nome text NOT NULL,
  descricao text NOT NULL,
  valor decimal(10,2) NOT NULL,
  data_gerado date DEFAULT CURRENT_DATE,
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'enviado', 'aceito', 'recusado')),
  observacoes text DEFAULT '',
  tipo_pagamento text NOT NULL DEFAULT 'dinheiro' CHECK (tipo_pagamento IN ('dinheiro', 'pix', 'debito', 'credito', 'boleto', 'transferencia')),
  status_pagamento text NOT NULL DEFAULT 'pendente' CHECK (status_pagamento IN ('pendente', 'pago', 'parcial', 'atrasado')),
  data_pagamento date,
  data_entrada_caixa date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Pedidos
CREATE TABLE IF NOT EXISTS pedidos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  orcamento_id uuid REFERENCES orcamentos(id) ON DELETE CASCADE,
  cliente_nome text NOT NULL,
  descricao text NOT NULL,
  valor decimal(10,2) NOT NULL,
  status text NOT NULL DEFAULT 'aguardando_corte' CHECK (status IN ('aguardando_corte', 'em_corte', 'pronto_instalacao', 'em_instalacao', 'finalizado')),
  data_inicio date DEFAULT CURRENT_DATE,
  data_final date,
  responsavel text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Despesas
CREATE TABLE IF NOT EXISTS despesas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  categoria text NOT NULL,
  subcategoria text DEFAULT '',
  descricao text NOT NULL,
  valor decimal(10,2) NOT NULL,
  data_vencimento date NOT NULL,
  data_pagamento date,
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'pago', 'atrasado', 'cancelado')),
  recorrente boolean DEFAULT false,
  frequencia_recorrencia text CHECK (frequencia_recorrencia IN ('mensal', 'bimestral', 'trimestral', 'semestral', 'anual')),
  fornecedor text DEFAULT '',
  observacoes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Movimentos Financeiros
CREATE TABLE IF NOT EXISTS movimentos_financeiros (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tipo text NOT NULL CHECK (tipo IN ('entrada', 'saida')),
  categoria text NOT NULL,
  descricao text NOT NULL,
  valor decimal(10,2) NOT NULL,
  data date NOT NULL,
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'pago', 'recebido')),
  recorrente boolean DEFAULT false,
  referencia_id uuid,
  referencia_tipo text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE colaboradores ENABLE ROW LEVEL SECURITY;
ALTER TABLE veiculos ENABLE ROW LEVEL SECURITY;
ALTER TABLE ferramentas ENABLE ROW LEVEL SECURITY;
ALTER TABLE estabelecimentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE atendimentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE orcamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE pedidos ENABLE ROW LEVEL SECURITY;
ALTER TABLE despesas ENABLE ROW LEVEL SECURITY;
ALTER TABLE movimentos_financeiros ENABLE ROW LEVEL SECURITY;

-- Policies for authenticated users
CREATE POLICY "Users can manage all data" ON clientes FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage all data" ON colaboradores FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage all data" ON veiculos FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage all data" ON ferramentas FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage all data" ON estabelecimentos FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage all data" ON atendimentos FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage all data" ON orcamentos FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage all data" ON pedidos FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage all data" ON despesas FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage all data" ON movimentos_financeiros FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Triggers for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_clientes_updated_at BEFORE UPDATE ON clientes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_colaboradores_updated_at BEFORE UPDATE ON colaboradores FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_veiculos_updated_at BEFORE UPDATE ON veiculos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_ferramentas_updated_at BEFORE UPDATE ON ferramentas FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_estabelecimentos_updated_at BEFORE UPDATE ON estabelecimentos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_atendimentos_updated_at BEFORE UPDATE ON atendimentos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_orcamentos_updated_at BEFORE UPDATE ON orcamentos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_pedidos_updated_at BEFORE UPDATE ON pedidos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_despesas_updated_at BEFORE UPDATE ON despesas FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_movimentos_financeiros_updated_at BEFORE UPDATE ON movimentos_financeiros FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();