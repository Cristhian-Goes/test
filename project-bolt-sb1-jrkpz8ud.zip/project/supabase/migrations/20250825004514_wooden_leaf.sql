/*
  # Fix pedidos table - add executores column

  1. Changes
    - Add `executores` column to `pedidos` table as jsonb array
    - This will store the list of executors for each order

  2. Security
    - No RLS changes needed (existing policies remain)
*/

-- Add executores column to pedidos table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pedidos' AND column_name = 'executores'
  ) THEN
    ALTER TABLE pedidos ADD COLUMN executores jsonb DEFAULT '[]'::jsonb;
  END IF;
END $$;