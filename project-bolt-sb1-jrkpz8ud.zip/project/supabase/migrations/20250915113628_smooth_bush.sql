/*
  # Adicionar tipo_saldo à tabela despesas

  1. Alterações
    - Adicionar coluna `tipo_saldo` na tabela `despesas`
    - Definir valores permitidos: 'conta', 'dinheiro'
    - Definir valor padrão como 'conta'

  2. Segurança
    - Manter RLS existente
*/

-- Adicionar coluna tipo_saldo na tabela despesas
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'despesas' AND column_name = 'tipo_saldo'
  ) THEN
    ALTER TABLE despesas ADD COLUMN tipo_saldo text DEFAULT 'conta' CHECK (tipo_saldo IN ('conta', 'dinheiro'));
  END IF;
END $$;