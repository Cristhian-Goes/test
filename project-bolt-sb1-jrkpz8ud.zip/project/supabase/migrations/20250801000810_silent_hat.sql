/*
  # Corrigir políticas RLS para permitir operações

  1. Políticas RLS
    - Permitir todas as operações para usuários autenticados
    - Remover restrições que estavam bloqueando inserções
  
  2. Ajustes nas tabelas
    - Tornar campos opcionais onde necessário
    - Ajustar valores padrão
*/

-- Remover políticas existentes e criar novas mais permissivas
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON clientes;
DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON clientes;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON colaboradores;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON veiculos;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON ferramentas;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON estabelecimentos;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON atendimentos;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON orcamentos;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON pedidos;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON despesas;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON movimentos_financeiros;

-- Criar políticas mais permissivas para todas as tabelas
CREATE POLICY "Allow all for authenticated users" ON clientes
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all for authenticated users" ON colaboradores
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all for authenticated users" ON veiculos
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all for authenticated users" ON ferramentas
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all for authenticated users" ON estabelecimentos
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all for authenticated users" ON atendimentos
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all for authenticated users" ON orcamentos
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all for authenticated users" ON pedidos
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all for authenticated users" ON despesas
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all for authenticated users" ON movimentos_financeiros
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Tornar campos opcionais onde necessário
ALTER TABLE colaboradores ALTER COLUMN salario DROP NOT NULL;
ALTER TABLE colaboradores ALTER COLUMN telefone DROP NOT NULL;
ALTER TABLE colaboradores ALTER COLUMN email DROP NOT NULL;
ALTER TABLE colaboradores ALTER COLUMN data_entrada DROP NOT NULL;

ALTER TABLE veiculos ALTER COLUMN ano DROP NOT NULL;
ALTER TABLE veiculos ALTER COLUMN motorista_responsavel DROP NOT NULL;

ALTER TABLE ferramentas ALTER COLUMN quantidade DROP NOT NULL;
ALTER TABLE ferramentas ALTER COLUMN data_compra DROP NOT NULL;
ALTER TABLE ferramentas ALTER COLUMN proxima_manutencao DROP NOT NULL;

ALTER TABLE clientes ALTER COLUMN telefone DROP NOT NULL;

ALTER TABLE estabelecimentos ALTER COLUMN cnpj DROP NOT NULL;
ALTER TABLE estabelecimentos ALTER COLUMN responsavel DROP NOT NULL;
ALTER TABLE estabelecimentos ALTER COLUMN telefone DROP NOT NULL;

ALTER TABLE atendimentos ALTER COLUMN data DROP NOT NULL;
ALTER TABLE atendimentos ALTER COLUMN responsavel DROP NOT NULL;

ALTER TABLE orcamentos ALTER COLUMN valor DROP NOT NULL;

ALTER TABLE despesas ALTER COLUMN valor DROP NOT NULL;
ALTER TABLE despesas ALTER COLUMN data_vencimento DROP NOT NULL;

ALTER TABLE movimentos_financeiros ALTER COLUMN valor DROP NOT NULL;
ALTER TABLE movimentos_financeiros ALTER COLUMN data DROP NOT NULL;