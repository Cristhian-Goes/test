/*
  # Fix RLS policies for clientes table

  1. Security Changes
    - Drop existing restrictive policies
    - Create new policies allowing all operations for authenticated users
    - Ensure INSERT, SELECT, UPDATE, DELETE permissions work correctly

  2. Policy Details
    - Allow authenticated users to perform all CRUD operations
    - Remove any restrictive conditions that might block operations
*/

-- Drop existing policies that might be causing issues
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON clientes;
DROP POLICY IF EXISTS "Users can read own data" ON clientes;
DROP POLICY IF EXISTS "Users can insert own data" ON clientes;
DROP POLICY IF EXISTS "Users can update own data" ON clientes;
DROP POLICY IF EXISTS "Users can delete own data" ON clientes;

-- Create comprehensive policies for all operations
CREATE POLICY "Allow all operations for authenticated users"
  ON clientes
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Ensure RLS is enabled
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;

-- Grant necessary permissions to authenticated role
GRANT ALL ON clientes TO authenticated;
GRANT USAGE ON SCHEMA public TO authenticated;