/*
  # Criar tabelas para controle de parcelas

  1. Novas Tabelas
    - `parcelas_boleto`
      - `id` (uuid, primary key)
      - `orcamento_id` (uuid, foreign key)
      - `numero_parcela` (integer)
      - `total_parcelas` (integer)
      - `valor` (numeric)
      - `data_vencimento` (date)
      - `status` (text: pendente, recebida)
      - `data_recebimento` (date, nullable)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `parcelas_cartao`
      - `id` (uuid, primary key)
      - `orcamento_id` (uuid, foreign key)
      - `numero_parcela` (integer)
      - `total_parcelas` (integer)
      - `valor` (numeric)
      - `data_recebimento` (date) - sempre 1º dia do mês
      - `status` (text: pendente, recebida)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Segurança
    - Habilitar RLS nas tabelas
    - Adicionar políticas para usuários autenticados
*/

-- Tabela para parcelas de boleto
CREATE TABLE IF NOT EXISTS parcelas_boleto (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  orcamento_id uuid REFERENCES orcamentos(id) ON DELETE CASCADE,
  numero_parcela integer NOT NULL,
  total_parcelas integer NOT NULL,
  valor numeric(10,2) NOT NULL,
  data_vencimento date NOT NULL,
  status text DEFAULT 'pendente' CHECK (status IN ('pendente', 'recebida')),
  data_recebimento date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tabela para parcelas de cartão de crédito
CREATE TABLE IF NOT EXISTS parcelas_cartao (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  orcamento_id uuid REFERENCES orcamentos(id) ON DELETE CASCADE,
  numero_parcela integer NOT NULL,
  total_parcelas integer NOT NULL,
  valor numeric(10,2) NOT NULL,
  data_recebimento date NOT NULL, -- sempre 1º dia do mês
  status text DEFAULT 'pendente' CHECK (status IN ('pendente', 'recebida')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE parcelas_boleto ENABLE ROW LEVEL SECURITY;
ALTER TABLE parcelas_cartao ENABLE ROW LEVEL SECURITY;

-- Políticas de acesso
CREATE POLICY "Allow all for authenticated users" ON parcelas_boleto
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Allow all for authenticated users" ON parcelas_cartao
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Triggers para updated_at
CREATE TRIGGER update_parcelas_boleto_updated_at
  BEFORE UPDATE ON parcelas_boleto
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_parcelas_cartao_updated_at
  BEFORE UPDATE ON parcelas_cartao
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_parcelas_boleto_orcamento ON parcelas_boleto(orcamento_id);
CREATE INDEX IF NOT EXISTS idx_parcelas_boleto_vencimento ON parcelas_boleto(data_vencimento);
CREATE INDEX IF NOT EXISTS idx_parcelas_cartao_orcamento ON parcelas_cartao(orcamento_id);
CREATE INDEX IF NOT EXISTS idx_parcelas_cartao_recebimento ON parcelas_cartao(data_recebimento);