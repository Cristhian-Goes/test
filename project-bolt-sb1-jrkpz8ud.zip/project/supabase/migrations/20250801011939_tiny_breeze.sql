/*
  # Adicionar campo tamanho_servico à tabela orcamentos

  1. Alterações
    - Adiciona coluna `tamanho_servico` do tipo text à tabela `orcamentos`
    - Campo opcional para especificar o tamanho/dimensões do serviço
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orcamentos' AND column_name = 'tamanho_servico'
  ) THEN
    ALTER TABLE orcamentos ADD COLUMN tamanho_servico text DEFAULT '';
  END IF;
END $$;