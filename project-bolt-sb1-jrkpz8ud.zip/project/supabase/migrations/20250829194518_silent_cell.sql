/*
  # Add payment fields to orcamentos table

  1. Changes
    - Add `data_vencimento_boleto` column for boleto due date
    - Add `parcelas_boleto` column for number of boleto installments
    - Add `parcelas_cartao` column for number of credit card installments

  2. Security
    - No RLS changes needed (existing policies remain)
*/

-- Add missing payment fields to orcamentos table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orcamentos' AND column_name = 'data_vencimento_boleto'
  ) THEN
    ALTER TABLE orcamentos ADD COLUMN data_vencimento_boleto date;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orcamentos' AND column_name = 'parcelas_boleto'
  ) THEN
    ALTER TABLE orcamentos ADD COLUMN parcelas_boleto integer;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orcamentos' AND column_name = 'parcelas_cartao'
  ) THEN
    ALTER TABLE orcamentos ADD COLUMN parcelas_cartao integer;
  END IF;
END $$;