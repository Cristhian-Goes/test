/*
  # Criar tabela para vendas no cartão de crédito

  1. Nova Tabela
    - `vendas_cartao_credito`
      - `id` (uuid, primary key)
      - `pedido_id` (uuid, foreign key) - referência ao pedido
      - `valor` (numeric) - valor da venda
      - `data_venda` (date) - data em que a venda foi realizada
      - `data_recebimento` (date) - sempre 1º dia do mês seguinte
      - `status` (text: pendente, recebida)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
  
  2. Segurança
    - Habilitar RLS na tabela
    - Adicionar políticas para usuários autenticados
*/

-- Tabela para vendas no cartão de crédito
CREATE TABLE IF NOT EXISTS vendas_cartao_credito (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pedido_id uuid REFERENCES pedidos(id) ON DELETE CASCADE,
  valor numeric(10,2) NOT NULL,
  data_venda date NOT NULL,
  data_recebimento date NOT NULL,
  status text DEFAULT 'pendente' CHECK (status IN ('pendente', 'recebida')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE vendas_cartao_credito ENABLE ROW LEVEL SECURITY;

-- Políticas de acesso
CREATE POLICY "Allow all for authenticated users" ON vendas_cartao_credito
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Trigger para updated_at
CREATE TRIGGER update_vendas_cartao_credito_updated_at
  BEFORE UPDATE ON vendas_cartao_credito
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_vendas_cartao_pedido ON vendas_cartao_credito(pedido_id);
CREATE INDEX IF NOT EXISTS idx_vendas_cartao_recebimento ON vendas_cartao_credito(data_recebimento);
CREATE INDEX IF NOT EXISTS idx_vendas_cartao_status ON vendas_cartao_credito(status);