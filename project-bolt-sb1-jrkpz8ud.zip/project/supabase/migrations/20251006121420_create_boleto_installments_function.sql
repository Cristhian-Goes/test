/*
  # Criar função para gerar parcelas de boleto

  1. Nova Função
    - `create_boleto_installments` - Cria parcelas de boleto com data de vencimento mensal
    - Primeira parcela: data especificada (data_vencimento_boleto do orçamento)
    - Demais parcelas: adiciona 1 mês a cada iteração
    
  2. Comportamento
    - Aceita: orcamento_id, numero_parcelas, valor_total, data_primeira_parcela
    - Calcula valor por parcela (valor_total / numero_parcelas)
    - Define data_vencimento conforme data_primeira_parcela informada
    - Demais parcelas: adiciona 1 mês a cada iteração
    - Cria todas as parcelas com status 'pendente'
*/

-- Função para criar parcelas de boleto
CREATE OR REPLACE FUNCTION create_boleto_installments(
  p_orcamento_id uuid,
  p_numero_parcelas integer,
  p_valor_total numeric,
  p_data_primeira_parcela date
)
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  v_valor_parcela numeric;
  v_contador integer;
BEGIN
  -- Calcular valor de cada parcela
  v_valor_parcela := p_valor_total / p_numero_parcelas;
  
  -- Criar todas as parcelas
  FOR v_contador IN 1..p_numero_parcelas LOOP
    INSERT INTO parcelas_boleto (
      orcamento_id,
      numero_parcela,
      total_parcelas,
      valor,
      data_vencimento,
      status
    ) VALUES (
      p_orcamento_id,
      v_contador,
      p_numero_parcelas,
      v_valor_parcela,
      p_data_primeira_parcela + ((v_contador - 1) || ' months')::interval,
      'pendente'
    );
  END LOOP;
END;
$$;