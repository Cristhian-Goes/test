/*
  # Adicionar controle de pagamento aos pedidos

  1. Alterações na tabela pedidos
    - Adicionar coluna `status_pagamento` para controlar se foi pago
    - Adicionar coluna `data_pagamento` para registrar quando foi pago
    - Adicionar coluna `entrada_caixa` para controlar se já foi para o caixa

  2. Segurança
    - Manter RLS existente
*/

-- Adicionar colunas de controle de pagamento aos pedidos
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pedidos' AND column_name = 'status_pagamento'
  ) THEN
    ALTER TABLE pedidos ADD COLUMN status_pagamento text DEFAULT 'pendente' CHECK (status_pagamento IN ('pendente', 'pago'));
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pedidos' AND column_name = 'data_pagamento'
  ) THEN
    ALTER TABLE pedidos ADD COLUMN data_pagamento date;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pedidos' AND column_name = 'entrada_caixa'
  ) THEN
    ALTER TABLE pedidos ADD COLUMN entrada_caixa boolean DEFAULT false;
  END IF;
END $$;