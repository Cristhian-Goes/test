import React, { useState, useEffect } from 'react';
import { Search, Phone, MessageCircle, TrendingUp, FileText, RotateCcw, CheckCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface RecuperacaoVendasProps {
  onNavigateToOrcamentos?: (clienteData?: any) => void;
}

const RecuperacaoVendas: React.FC<RecuperacaoVendasProps> = ({ onNavigateToOrcamentos }) => {
  const [orcamentos, setOrcamentos] = useState<any[]>([]);
  const [clientes, setClientes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchOrcamentos();
    fetchClientes();
  }, []);

  const fetchOrcamentos = async () => {
    try {
      const { data, error } = await supabase
        .from('orcamentos')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const orcamentosFormatted = data?.map(item => ({
        id: item.id,
        clienteId: item.cliente_id,
        clienteNome: item.cliente_nome,
        descricao: item.descricao,
        valor: item.valor,
        dataGerado: item.data_gerado,
        status: item.status,
        observacoes: item.observacoes || ''
      })) || [];

      setOrcamentos(orcamentosFormatted);
    } catch (error) {
      console.error('Erro ao buscar orçamentos:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchClientes = async () => {
    try {
      const { data, error } = await supabase
        .from('clientes')
        .select('*')
        .order('nome');

      if (error) throw error;
      setClientes(data || []);
    } catch (error) {
      console.error('Erro ao buscar clientes:', error);
    }
  };

  const handleWhatsApp = (orcamento: any) => {
    const cliente = clientes.find(c => c.id === orcamento.clienteId);
    if (cliente && cliente.telefone) {
      // Limpar o telefone e formatar para WhatsApp
      const telefone = cliente.telefone.replace(/\D/g, '');
      const mensagem = encodeURIComponent(
        `Olá ${cliente.nome}! Tudo bem?\n\nEstou entrando em contato sobre o orçamento que enviamos para ${orcamento.descricao}.\n\nGostaria de esclarecer alguma dúvida ou renegociar as condições?\n\nFico no aguardo do seu retorno!`
      );
      window.open(`https://web.whatsapp.com/send?phone=55${telefone}&text=${mensagem}`, '_blank');
    } else {
      alert('Telefone do cliente não encontrado!');
    }
  };

  const handleNovoOrcamento = (orcamento: any) => {
    const cliente = clientes.find(c => c.id === orcamento.clienteId);
    if (cliente && onNavigateToOrcamentos) {
      // Navegar para orçamentos com cliente pré-selecionado
      const orcamentoPreenchido = {
        clienteId: cliente.id,
        clienteNome: cliente.nome,
        descricao: `Recuperação - ${orcamento.descricao}`,
        valor: orcamento.valor,
        observacoes: `Orçamento de recuperação baseado no orçamento ${orcamento.status} anterior.`,
        tipoPagamento: 'dinheiro'
      };
      onNavigateToOrcamentos(orcamentoPreenchido);
    } else {
      alert('Cliente não encontrado!');
    }
  };

  const handleReverterStatus = async (orcamentoId: string) => {
    if (window.confirm('Tem certeza que deseja reverter este orçamento para pendente?')) {
      try {
        const { error } = await supabase
          .from('orcamentos')
          .update({ status: 'pendente' })
          .eq('id', orcamentoId);

        if (error) throw error;
        
        await fetchOrcamentos();
        alert('Status do orçamento revertido para pendente com sucesso!');
      } catch (error) {
        console.error('Erro ao reverter status:', error);
        alert('Erro ao reverter status do orçamento');
      }
    }
  };

  const orcamentosRecusados = orcamentos.filter(o => o.status === 'recusado');
  const orcamentosAceitos = orcamentos.filter(o => o.status === 'aceito');
  const totalOrcamentos = orcamentos.length;

  const searchFiltered = orcamentosRecusados.filter(orcamento =>
    orcamento.clienteNome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    orcamento.descricao.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalValorPerdido = orcamentosRecusados.reduce((sum, o) => sum + o.valor, 0);
  const totalValorRecuperado = orcamentosAceitos.reduce((sum, o) => sum + o.valor, 0);
  
  // Calcular taxa de recuperação real
  const taxaRecuperacao = totalOrcamentos > 0 
    ? Math.round((orcamentosAceitos.length / totalOrcamentos) * 100)
    : 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-800">Recuperação de Vendas</h1>
        <p className="text-gray-600">Recupere orçamentos recusados através de contato direto</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-red-50 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-red-800">Vendas Perdidas</p>
              <p className="text-2xl font-bold text-red-900">{orcamentosRecusados.length}</p>
              <p className="text-sm text-red-600 mt-1">
                R$ {totalValorPerdido.toLocaleString('pt-BR')}
              </p>
            </div>
            <TrendingUp className="text-red-600" size={32} />
          </div>
        </div>

        <div className="bg-green-50 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-800">Vendas Recuperadas</p>
              <p className="text-2xl font-bold text-green-900">{orcamentosAceitos.length}</p>
              <p className="text-sm text-green-600 mt-1">
                R$ {totalValorRecuperado.toLocaleString('pt-BR')}
              </p>
            </div>
            <TrendingUp className="text-green-600" size={32} />
          </div>
        </div>

        <div className="bg-blue-50 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-800">Taxa de Recuperação</p>
              <p className="text-2xl font-bold text-blue-900">{taxaRecuperacao}%</p>
              <p className="text-sm text-blue-600 mt-1">
                {orcamentosAceitos.length} de {totalOrcamentos} orçamentos
              </p>
            </div>
            <TrendingUp className="text-blue-600" size={32} />
          </div>
        </div>
      </div>

      {/* Orçamentos Recusados */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="border-b">
          <div className="px-6 py-4">
            <h3 className="text-lg font-semibold text-red-600">
              Orçamentos Recusados ({orcamentosRecusados.length})
            </h3>
          </div>
        </div>

        <div className="p-6">
          {/* Search */}
          <div className="relative mb-6">
            <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar por cliente ou descrição..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Recovery List */}
          <div className="space-y-4">
            {searchFiltered.map((orcamento) => (
              <div key={orcamento.id} className="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">{orcamento.clienteNome}</h3>
                    <p className="text-gray-600 mb-2">{orcamento.descricao}</p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span>Valor: R$ {Number(orcamento.valor || 0).toLocaleString('pt-BR')}</span>
                      <span>Data: {orcamento.dataGerado ? new Date(orcamento.dataGerado + 'T00:00:00').toLocaleDateString('pt-BR') : 'N/A'}</span>
                      <span className="px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                        Recusado
                      </span>
                    </div>
                    {orcamento.observacoes && (
                      <div className="mt-3 p-3 bg-white rounded-lg border">
                        <p className="text-sm text-gray-700">{orcamento.observacoes}</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="flex flex-wrap gap-3">
                    <button 
                      onClick={() => handleNovoOrcamento(orcamento)}
                      className="inline-flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <FileText size={16} />
                      <span>Novo Orçamento</span>
                    </button>
                    <button 
                      onClick={() => handleWhatsApp(orcamento)}
                      className="inline-flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                    >
                      <MessageCircle size={16} />
                      <span>WhatsApp</span>
                    </button>
                    <button 
                      onClick={() => handleReverterStatus(orcamento.id)}
                      className="inline-flex items-center space-x-2 bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors"
                      title="Reverter status para pendente"
                    >
                      <RotateCcw size={16} />
                      <span>Reverter Status</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}

            {searchFiltered.length === 0 && (
              <div className="text-center py-12">
                <TrendingUp size={48} className="mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-600">
                  Nenhum orçamento recusado encontrado
                </h3>
                <p className="text-gray-500">
                  {searchTerm ? 'Tente ajustar sua busca.' : 'Ótimo! Suas vendas estão indo bem.'}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Orçamentos Aceitos (para referência) */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="border-b">
          <div className="px-6 py-4">
            <h3 className="text-lg font-semibold text-green-600">
              Orçamentos Aceitos ({orcamentosAceitos.length})
            </h3>
          </div>
        </div>

        <div className="p-6">
          <div className="space-y-4">
            {orcamentosAceitos.slice(0, 5).map((orcamento) => (
              <div key={orcamento.id} className="bg-green-50 rounded-lg p-4 border border-green-200">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-gray-800">{orcamento.clienteNome}</h4>
                    <p className="text-sm text-gray-600">{orcamento.descricao}</p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500 mt-1">
                      <span>R$ {Number(orcamento.valor || 0).toLocaleString('pt-BR')}</span>
                      <span>{orcamento.dataGerado ? new Date(orcamento.dataGerado + 'T00:00:00').toLocaleDateString('pt-BR') : 'N/A'}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="text-green-600" size={20} />
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      Aceito
                    </span>
                  </div>
                </div>
              </div>
            ))}

            {orcamentosAceitos.length === 0 && (
              <div className="text-center py-8">
                <CheckCircle size={32} className="mx-auto text-gray-400 mb-2" />
                <p className="text-gray-500">Nenhum orçamento aceito ainda</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecuperacaoVendas;