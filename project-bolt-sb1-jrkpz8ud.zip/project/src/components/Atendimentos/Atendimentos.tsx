import React, { useState, useEffect } from 'react';
import { Plus, Search, Calendar, User, Headphones, Edit, Trash2, FileText, Printer, Building, Home, Filter, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Atendimento } from '../../types';
import { generateOrcamentoPDF } from '../../utils/pdfGenerator';
import ClienteSearch from '../Common/ClienteSearch';

interface AtendimentosProps {
  onNavigateToOrcamentos?: (atendimentoData?: any) => void;
}

const Atendimentos: React.FC<AtendimentosProps> = ({ onNavigateToOrcamentos }) => {
  const [atendimentos, setAtendimentos] = useState<Atendimento[]>([]);
  const [clientes, setClientes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingAtendimento, setEditingAtendimento] = useState<Atendimento | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [tipoFilter, setTipoFilter] = useState<string>('todos');
  const [showFilters, setShowFilters] = useState(false);
  const [dateFilter, setDateFilter] = useState<string>('');
  const [selectedCliente, setSelectedCliente] = useState<any>(null);
  const [formData, setFormData] = useState<Omit<Atendimento, 'id'>>({
    clienteId: '',
    clienteNome: '',
    tipo: 'interno',
    descricao: '',
    data: new Date().toISOString().split('T')[0],
  });

  useEffect(() => {
    fetchAtendimentos();
    fetchClientes();
  }, []);

  const fetchAtendimentos = async () => {
    try {
      const { data, error } = await supabase
        .from('atendimentos')
        .select('*')
        .order('data', { ascending: false, nullsLast: true });

      if (error) throw error;

      const atendimentosFormatted = data?.map(item => ({
        id: item.id,
        clienteId: item.cliente_id,
        clienteNome: item.cliente_nome,
        tipo: item.tipo,
        descricao: item.descricao,
        data: item.data,
        responsavel: item.responsavel
      })) || [];

      setAtendimentos(atendimentosFormatted);
    } catch (error) {
      console.error('Erro ao buscar atendimentos:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchClientes = async () => {
    try {
      const { data, error } = await supabase
        .from('clientes')
        .select('*')
        .order('nome');

      if (error) throw error;
      setClientes(data || []);
    } catch (error) {
      console.error('Erro ao buscar clientes:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (!selectedCliente) {
        alert('Por favor, selecione um cliente');
        setLoading(false);
        return;
      }

      const atendimentoData = {
        cliente_id: selectedCliente.id,
        cliente_nome: selectedCliente.nome,
        tipo: formData.tipo,
        descricao: formData.descricao,
        data: formData.data
      };

      if (editingAtendimento) {
        const { error } = await supabase
          .from('atendimentos')
          .update(atendimentoData)
          .eq('id', editingAtendimento.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('atendimentos')
          .insert([atendimentoData]);

        if (error) throw error;
      }

      await fetchAtendimentos();
      handleCloseForm();
    } catch (error) {
      console.error('Erro ao salvar atendimento:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (atendimento: Atendimento) => {
    setEditingAtendimento(atendimento);
    const cliente = clientes.find(c => c.id === atendimento.clienteId);
    setSelectedCliente(cliente || null);
    setFormData({
      clienteId: atendimento.clienteId,
      clienteNome: atendimento.clienteNome,
      tipo: atendimento.tipo,
      descricao: atendimento.descricao,
      data: atendimento.data,
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir este atendimento?')) {
      try {
        const { error } = await supabase
          .from('atendimentos')
          .delete()
          .eq('id', id);

        if (error) throw error;
        await fetchAtendimentos();
      } catch (error) {
        console.error('Erro ao excluir atendimento:', error);
      }
    }
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingAtendimento(null);
    setSelectedCliente(null);
    setFormData({
      clienteId: '',
      clienteNome: '',
      tipo: 'interno',
      descricao: '',
      data: new Date().toISOString().split('T')[0],
    });
  };

  const handleGenerateOrcamento = async (atendimento: Atendimento) => {
    try {
      // Preparar dados para navegar diretamente para orçamentos
      const orcamentoPreenchido = {
        clienteId: atendimento.clienteId,
        clienteNome: atendimento.clienteNome,
        descricao: atendimento.descricao,
        tipoAtendimento: atendimento.tipo,
        observacoes: `Baseado no atendimento: ${getTipoText(atendimento.tipo)}`
      };

      // Navegar diretamente para orçamentos com dados preenchidos
      if (onNavigateToOrcamentos) {
        onNavigateToOrcamentos(orcamentoPreenchido);
      }
    } catch (error) {
      console.error('Erro ao gerar orçamento:', error);
      alert('Erro ao gerar orçamento');
    }
  };

  const handlePrintOrcamento = (atendimento: Atendimento) => {
    const cliente = clientes.find(c => c.id === atendimento.clienteId);
    if (!cliente) {
      alert('Cliente não encontrado!');
      return;
    }

    const numeroOrcamento = `ORC-${Date.now().toString().slice(-6)}`;
    
    const orcamentoData = {
      id: numeroOrcamento,
      clienteNome: atendimento.clienteNome,
      descricao: atendimento.descricao,
      valor: 0,
      dataGerado: atendimento.data,
      observacoes: `Tipo: ${getTipoText(atendimento.tipo)}`,
      numeroOrcamento,
      dataEmissao: atendimento.data
    };

    const clienteData = {
      nome: cliente.nome,
      endereco: cliente.endereco || {
        rua: '',
        numero: '',
        bairro: '',
        cidade: '',
        estado: '',
        cep: ''
      },
      telefone: cliente.telefone || ''
    };

    generateOrcamentoPDF(orcamentoData, clienteData, atendimento.tipo === 'externo');
  };

  const filteredAtendimentos = atendimentos.filter(atendimento => {
    const matchesSearch = atendimento.clienteNome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         atendimento.descricao.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTipo = tipoFilter === 'todos' || atendimento.tipo === tipoFilter;
    const matchesDate = !dateFilter || atendimento.data.startsWith(dateFilter);
    return matchesSearch && matchesTipo && matchesDate;
  });

  const getTipoIcon = (tipo: string) => {
    const icons = {
      'interno': Building,
      'externo': Home
    };
    return icons[tipo as keyof typeof icons] || Headphones;
  };

  const getTipoColor = (tipo: string) => {
    const colors = {
      'interno': 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300',
      'externo': 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
    };
    return colors[tipo as keyof typeof colors] || 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300';
  };

  const getTipoText = (tipo: string) => {
    const texts = {
      'interno': 'Serviço Interno',
      'externo': 'Serviço Externo'
    };
    return texts[tipo as keyof typeof texts] || tipo;
  };

  // Estatísticas dos atendimentos
  const totalAtendimentos = atendimentos.length;
  const atendimentosInternos = atendimentos.filter(a => a.tipo === 'interno').length;
  const atendimentosExternos = atendimentos.filter(a => a.tipo === 'externo').length;
  const atendimentosHoje = atendimentos.filter(a => 
    a.data === new Date().toISOString().split('T')[0]
  ).length;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6 p-4 sm:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-800 dark:text-white">Atendimentos</h1>
          <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">Gerencie o histórico de atendimentos aos clientes</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="inline-flex items-center justify-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors w-full sm:w-auto"
        >
          <Plus size={20} />
          <span>Novo Atendimento</span>
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-800 dark:text-blue-300">Total</p>
              <p className="text-xl sm:text-2xl font-bold text-blue-900 dark:text-blue-100">{totalAtendimentos}</p>
            </div>
            <Headphones className="text-blue-600 dark:text-blue-400" size={24} />
          </div>
        </div>

        <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 border border-green-200 dark:border-green-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-800 dark:text-green-300">Externos</p>
              <p className="text-xl sm:text-2xl font-bold text-green-900 dark:text-green-100">{atendimentosExternos}</p>
            </div>
            <Home className="text-green-600 dark:text-green-400" size={24} />
          </div>
        </div>

        <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4 border border-purple-200 dark:border-purple-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-purple-800 dark:text-purple-300">Internos</p>
              <p className="text-xl sm:text-2xl font-bold text-purple-900 dark:text-purple-100">{atendimentosInternos}</p>
            </div>
            <Building className="text-purple-600 dark:text-purple-400" size={24} />
          </div>
        </div>

        <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-4 border border-orange-200 dark:border-orange-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-orange-800 dark:text-orange-300">Hoje</p>
              <p className="text-xl sm:text-2xl font-bold text-orange-900 dark:text-orange-100">{atendimentosHoje}</p>
            </div>
            <Calendar className="text-orange-600 dark:text-orange-400" size={24} />
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar por cliente ou descrição..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="inline-flex items-center space-x-2 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            <Filter size={20} />
            <span className="hidden sm:inline">Filtros</span>
          </button>
        </div>

        {showFilters && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
            <select
              value={tipoFilter}
              onChange={(e) => setTipoFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="todos">Todos os Tipos</option>
              <option value="interno">Serviço Interno</option>
              <option value="externo">Serviço Externo</option>
            </select>

            <input
              type="month"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />

            <button
              onClick={() => {
                setSearchTerm('');
                setTipoFilter('todos');
                setDateFilter('');
              }}
              className="inline-flex items-center justify-center space-x-2 px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            >
              <X size={16} />
              <span>Limpar Filtros</span>
            </button>
          </div>
        )}
      </div>

      {/* Atendimentos List */}
      <div className="space-y-4">
        {filteredAtendimentos.map((atendimento) => {
          const TipoIcon = getTipoIcon(atendimento.tipo);
          return (
            <div key={atendimento.id} className="bg-white dark:bg-gray-800 rounded-lg p-4 sm:p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                <div className="flex items-start space-x-3 flex-1">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                    <TipoIcon size={20} className="text-blue-600 dark:text-blue-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-base sm:text-lg font-semibold text-gray-800 dark:text-white">{atendimento.clienteNome}</h3>
                    <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-xs sm:text-sm text-gray-600 dark:text-gray-400 mt-1">
                      <div className="flex items-center space-x-1">
                        <Calendar size={14} />
                        <span>{atendimento.data ? new Date(atendimento.data + 'T00:00:00').toLocaleDateString('pt-BR') : 'N/A'}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <User size={14} />
                        <span>Sistema</span>
                      </div>
                    </div>
                    {atendimento.descricao && (
                      <div className="mt-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <p className="text-sm text-gray-700 dark:text-gray-300">{atendimento.descricao}</p>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center justify-between lg:flex-col lg:items-end gap-3">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTipoColor(atendimento.tipo)}`}>
                    {getTipoText(atendimento.tipo)}
                  </span>
                  <div className="flex flex-wrap gap-2">
                    <button 
                      onClick={() => handleGenerateOrcamento(atendimento)}
                      className="inline-flex items-center space-x-1 bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700 transition-colors"
                      title="Gerar Orçamento"
                    >
                      <FileText size={16} />
                      <span className="hidden sm:inline">Orçamento</span>
                    </button>
                    <button 
                      onClick={() => handlePrintOrcamento(atendimento)}
                      className="inline-flex items-center space-x-1 bg-purple-600 text-white px-3 py-1 rounded text-sm hover:bg-purple-700 transition-colors"
                      title="Imprimir Folha de Orçamento"
                    >
                      <Printer size={16} />
                      <span className="hidden sm:inline">Imprimir</span>
                    </button>
                    <button 
                      onClick={() => handleEdit(atendimento)}
                      className="inline-flex items-center space-x-1 bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 transition-colors"
                      title="Editar"
                    >
                      <Edit size={16} />
                      <span className="hidden sm:inline">Editar</span>
                    </button>
                    <button 
                      onClick={() => handleDelete(atendimento.id)}
                      className="inline-flex items-center space-x-1 bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700 transition-colors"
                      title="Excluir"
                    >
                      <Trash2 size={16} />
                      <span className="hidden sm:inline">Excluir</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {filteredAtendimentos.length === 0 && (
          <div className="text-center py-12">
            <Headphones size={48} className="mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-600 dark:text-gray-400">Nenhum atendimento encontrado</h3>
            <p className="text-gray-500 dark:text-gray-500">
              {searchTerm || tipoFilter !== 'todos' || dateFilter 
                ? 'Tente ajustar os filtros de busca' 
                : 'Comece registrando um novo atendimento'
              }
            </p>
          </div>
        )}
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 sm:p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-lg sm:text-xl font-bold text-gray-800 dark:text-white mb-6">
              {editingAtendimento ? 'Editar Atendimento' : 'Novo Atendimento'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Cliente
                  </label>
                  <ClienteSearch
                    onClienteSelect={setSelectedCliente}
                    selectedCliente={selectedCliente}
                    placeholder="Buscar cliente por nome, CPF/CNPJ ou telefone..."
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Tipo de Atendimento
                  </label>
                  <select
                    value={formData.tipo}
                    onChange={(e) => setFormData(prev => ({ ...prev, tipo: e.target.value as any }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="interno">Serviço Interno</option>
                    <option value="externo">Serviço Externo</option>
                  </select>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Interno: Produção com/sem instalação | Externo: Visita para medição
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Data do Atendimento
                </label>
                <input
                  type="date"
                  value={formData.data}
                  onChange={(e) => setFormData(prev => ({ ...prev, data: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              {/* Campos condicionais baseados no tipo de atendimento */}
              {formData.tipo === 'externo' && (
                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-700">
                  <h4 className="font-medium text-blue-800 dark:text-blue-300 mb-2">
                    💡 Dicas para Serviço Externo
                  </h4>
                  <p className="text-sm text-blue-600 dark:text-blue-400">
                    • Inclua endereço completo e pontos de referência<br/>
                    • Anote horário disponível do cliente<br/>
                    • Mencione ferramentas necessárias para medição
                  </p>
                </div>
              )}
              
              {formData.tipo === 'interno' && (
                <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-700">
                  <h4 className="font-medium text-green-800 dark:text-green-300 mb-2">
                    💡 Dicas para Serviço Interno
                  </h4>
                  <p className="text-sm text-green-600 dark:text-green-400">
                    • Especifique dimensões e medidas exatas<br/>
                    • Inclua tipo de material e cor desejada<br/>
                    • Mencione se inclui instalação ou apenas produção
                  </p>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Descrição Detalhada
                </label>
                <textarea
                  rows={4}
                  value={formData.descricao}
                  onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder={
                    formData.tipo === 'externo' 
                      ? "Ex: Visita para medição de calhas na residência. Endereço: Rua das Flores, 123. Horário: 14h às 16h. Cliente precisa de orçamento para calhas frontais e laterais."
                      : "Ex: Produção de 15 metros de calha galvanizada branca, com 4 descidas e instalação completa. Material: chapa galvanizada 0,5mm."
                  }
                  required
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Seja específico para facilitar a elaboração do orçamento
                </p>
              </div>

              <div className="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 pt-4">
                <button
                  type="button"
                  onClick={handleCloseForm}
                  className="px-4 py-2 text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Salvando...' : (editingAtendimento ? 'Atualizar' : 'Salvar')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Atendimentos;