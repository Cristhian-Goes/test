import React, { useState, useEffect, useRef } from 'react';
import { Search, User, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface Cliente {
  id: string;
  nome: string;
  cpf_cnpj: string;
  telefone: string;
  endereco: any;
}

interface ClienteSearchProps {
  onClienteSelect: (cliente: Cliente) => void;
  selectedCliente?: Cliente | null;
  placeholder?: string;
  className?: string;
}

const ClienteSearch: React.FC<ClienteSearchProps> = ({
  onClienteSelect,
  selectedCliente,
  placeholder = "Buscar cliente...",
  className = ""
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [filteredClientes, setFilteredClientes] = useState<Cliente[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [loading, setLoading] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchClientes();
  }, []);

  useEffect(() => {
    if (searchTerm.length >= 2) {
      const filtered = clientes.filter(cliente =>
        cliente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cliente.cpf_cnpj.includes(searchTerm) ||
        cliente.telefone.includes(searchTerm)
      );
      setFilteredClientes(filtered);
      setShowDropdown(true);
    } else {
      setFilteredClientes([]);
      setShowDropdown(false);
    }
  }, [searchTerm, clientes]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const fetchClientes = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('clientes')
        .select('*')
        .order('nome');

      if (error) throw error;

      const clientesFormatted = data?.map(item => ({
        id: item.id,
        nome: item.nome,
        cpf_cnpj: item.cpf_cnpj,
        telefone: item.telefone,
        endereco: item.endereco || {}
      })) || [];

      setClientes(clientesFormatted);
    } catch (error) {
      console.error('Erro ao buscar clientes:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleClienteSelect = (cliente: Cliente) => {
    onClienteSelect(cliente);
    setSearchTerm('');
    setShowDropdown(false);
  };

  const handleClearSelection = () => {
    onClienteSelect(null as any);
    setSearchTerm('');
  };

  return (
    <div ref={searchRef} className={`relative ${className}`}>
      {selectedCliente ? (
        <div className="flex items-center justify-between p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-blue-50 dark:bg-blue-900/20">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
              <User size={16} className="text-white" />
            </div>
            <div>
              <p className="font-medium text-gray-800 dark:text-white">{selectedCliente.nome}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">{selectedCliente.cpf_cnpj}</p>
            </div>
          </div>
          <button
            onClick={handleClearSelection}
            className="p-1 text-gray-400 hover:text-red-600 transition-colors"
            title="Remover seleção"
          >
            <X size={16} />
          </button>
        </div>
      ) : (
        <div className="relative">
          <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder={placeholder}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onFocus={() => searchTerm.length >= 2 && setShowDropdown(true)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          
          {showDropdown && (
            <div className="absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg shadow-lg max-h-60 overflow-y-auto">
              {loading ? (
                <div className="p-4 text-center">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto"></div>
                </div>
              ) : filteredClientes.length > 0 ? (
                filteredClientes.map((cliente) => (
                  <button
                    key={cliente.id}
                    onClick={() => handleClienteSelect(cliente)}
                    className="w-full text-left p-3 hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-700 last:border-b-0 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                        <User size={14} className="text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-800 dark:text-white truncate">{cliente.nome}</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                          <span>{cliente.cpf_cnpj}</span>
                          <span>•</span>
                          <span>{cliente.telefone}</span>
                        </div>
                      </div>
                    </div>
                  </button>
                ))
              ) : searchTerm.length >= 2 ? (
                <div className="p-4 text-center text-gray-500 dark:text-gray-400">
                  <User size={24} className="mx-auto mb-2 opacity-50" />
                  <p>Nenhum cliente encontrado</p>
                  <p className="text-xs mt-1">Tente buscar por nome, CPF/CNPJ ou telefone</p>
                </div>
              ) : (
                <div className="p-4 text-center text-gray-500 dark:text-gray-400">
                  <p className="text-sm">Digite pelo menos 2 caracteres para buscar</p>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ClienteSearch;