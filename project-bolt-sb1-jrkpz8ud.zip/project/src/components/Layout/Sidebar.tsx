import React from 'react';
import { 
  Home, 
  Users, 
  UserCheck, 
  Car, 
  Wrench, 
  Building, 
  Headphones,
  FileText,
  ShoppingCart,
  TrendingUp,
  DollarSign,
  Menu,
  X,
  Calculator,
  ChevronDown,
  ChevronRight
} from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  isOpen: boolean;
  onToggle: () => void;
}

interface MenuGroup {
  id: string;
  label: string;
  items: {
    id: string;
    label: string;
    icon: React.ComponentType<any>;
  }[];
}

const menuGroups: MenuGroup[] = [
  {
    id: 'painel',
    label: 'Painel',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: Home }
    ]
  },
  {
    id: 'cadastros',
    label: 'Cadastros',
    items: [
      { id: 'clientes', label: 'Clientes', icon: Users },
      { id: 'colaboradores', label: 'Colaboradores', icon: UserCheck },
      { id: 'veiculos', label: 'Veículos', icon: Car },
      { id: 'estabelecimentos', label: 'Estabelecimentos', icon: Building },
      { id: 'ferramentas', label: 'Ferramentas', icon: Wrench }
    ]
  },
  {
    id: 'vendas',
    label: 'Vendas',
    items: [
      { id: 'atendimentos', label: 'Atendimentos', icon: Headphones },
      { id: 'orcamentos', label: 'Orçamentos', icon: FileText },
      { id: 'pedidos', label: 'Pedidos', icon: ShoppingCart }
    ]
  },
  {
    id: 'fluxo_caixa',
    label: 'Fluxo de Caixa',
    items: [
      { id: 'despesas', label: 'Despesas', icon: DollarSign },
      { id: 'recuperacao', label: 'Recuperação de Vendas', icon: TrendingUp },
      { id: 'financeiro', label: 'Financeiro', icon: DollarSign }
    ]
  },
  {
    id: 'calculos',
    label: 'Cálculo Orçamento',
    items: [
      { id: 'calculox', label: 'CalculoX', icon: Calculator }
    ]
  }
];

const Sidebar: React.FC<SidebarProps> = ({ currentPage, onPageChange, isOpen, onToggle }) => {
  const [expandedGroups, setExpandedGroups] = React.useState<Set<string>>(
    new Set(['painel', 'cadastros', 'vendas', 'fluxo_caixa', 'calculos'])
  );

  const toggleGroup = (groupId: string) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(groupId)) {
      newExpanded.delete(groupId);
    } else {
      newExpanded.add(groupId);
    }
    setExpandedGroups(newExpanded);
  };

  const handleItemClick = (itemId: string) => {
    onPageChange(itemId);
    if (window.innerWidth < 1024) {
      onToggle();
    }
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onToggle}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed top-0 left-0 z-50 h-full w-64 bg-white dark:bg-gray-800 shadow-lg transform transition-transform duration-300 ease-in-out
        lg:relative lg:translate-x-0 lg:z-auto
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <h1 className="text-xl font-bold text-gray-800 dark:text-white">Gestão Gráfica</h1>
          <button
            onClick={onToggle}
            className="lg:hidden p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <X size={20} className="text-gray-600 dark:text-gray-300" />
          </button>
        </div>
        
        <nav className="p-4 h-full overflow-y-auto custom-scrollbar">
          <div className="space-y-2">
            {menuGroups.map((group) => (
              <div key={group.id} className="mb-4">
                {/* Group Header */}
                <button
                  onClick={() => toggleGroup(group.id)}
                  className="w-full flex items-center justify-between px-3 py-2 text-left text-sm font-semibold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                >
                  <span className="uppercase tracking-wide text-xs">{group.label}</span>
                  {expandedGroups.has(group.id) ? (
                    <ChevronDown size={16} className="text-gray-500" />
                  ) : (
                    <ChevronRight size={16} className="text-gray-500" />
                  )}
                </button>

                {/* Group Items */}
                {expandedGroups.has(group.id) && (
                  <div className="mt-2 space-y-1 ml-2">
                    {group.items.map((item) => {
                      const Icon = item.icon;
                      const isActive = currentPage === item.id;
                      
                      return (
                        <button
                          key={item.id}
                          onClick={() => handleItemClick(item.id)}
                          className={`
                            w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-all duration-200
                            ${isActive 
                              ? 'bg-blue-600 dark:bg-blue-500 text-white shadow-sm transform scale-105' 
                              : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 hover:translate-x-1'
                            }
                          `}
                        >
                          <Icon size={18} className={isActive ? 'text-white' : 'text-gray-500 dark:text-gray-400'} />
                          <span className="text-sm font-medium">{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            ))}
          </div>
        </nav>
      </div>
    </>
  );
};

export default Sidebar;