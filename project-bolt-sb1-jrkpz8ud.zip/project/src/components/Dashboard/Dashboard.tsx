import React, { useState, useEffect } from 'react';
import { Users, FileText, ShoppingCart, DollarSign, TrendingUp, TrendingDown, Calendar, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface DashboardStats {
  clientesTotal: number;
  orcamentosAbertos: number;
  pedidosAndamento: number;
  faturamentoMes: number;
  despesasMes: number;
  saldoAtual: number;
  saldoAtualConta: number;
  saldoAtualDinheiro: number;
  totalEntradas: number;
  totalSaidas: number;
  orcamentosPendentes: number;
  orcamentosAceitos: number;
  orcamentosRecusados: number;
  valorOrcamentosPendentes: number;
  valorOrcamentosAceitos: number;
  despesasPendentes: number;
  despesasVencidas: number;
}

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats>({
    clientesTotal: 0,
    orcamentosAbertos: 0,
    pedidosAndamento: 0,
    faturamentoMes: 0,
    despesasMes: 0,
    saldoAtual: 0,
    saldoAtualConta: 0,
    saldoAtualDinheiro: 0,
    totalEntradas: 0,
    totalSaidas: 0,
    orcamentosPendentes: 0,
    orcamentosAceitos: 0,
    orcamentosRecusados: 0,
    valorOrcamentosPendentes: 0,
    valorOrcamentosAceitos: 0,
    despesasPendentes: 0,
    despesasVencidas: 0
  });
  const [loading, setLoading] = useState(true);
  const [recentMovimentos, setRecentMovimentos] = useState<any[]>([]);
  const [saldoConfig, setSaldoConfig] = useState<any>(null);

  useEffect(() => {
    fetchDashboardData();
    fetchSaldoConfig();
  }, []);

  const fetchSaldoConfig = async () => {
    try {
      const { data, error } = await supabase
        .from('configuracao_saldos')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;
      setSaldoConfig(data);
    } catch (error) {
      console.error('Erro ao buscar configuração de saldos:', error);
    }
  };

  const fetchDashboardData = async () => {
    try {
      // Buscar dados de todas as tabelas com tratamento de erro
      const [
        clientesData,
        orcamentosData,
        pedidosData,
        despesasData,
        movimentosData
      ] = await Promise.all([
        supabase.from('clientes').select('*').then(r => r.error ? { data: [] } : r),
        supabase.from('orcamentos').select('*').then(r => r.error ? { data: [] } : r),
        supabase.from('pedidos').select('*').then(r => r.error ? { data: [] } : r),
        supabase.from('despesas').select('*').then(r => r.error ? { data: [] } : r),
        supabase.from('movimentos_financeiros').select('*').then(r => r.error ? { data: [] } : r)
      ]);

      // Buscar parcelas com tratamento robusto de erro
      let parcelasBoletoData = { data: [] };
      let parcelasCartaoData = { data: [] };
      let vendasCreditoData = { data: [] };

      try {
        const boletoResult = await supabase.from('parcelas_boleto').select('*');
        if (!boletoResult.error) parcelasBoletoData = boletoResult;
      } catch (error) {
        console.warn('Tabela parcelas_boleto não encontrada:', error);
      }

      try {
        const cartaoResult = await supabase.from('parcelas_cartao').select('*');
        if (!cartaoResult.error) parcelasCartaoData = cartaoResult;
      } catch (error) {
        console.warn('Tabela parcelas_cartao não encontrada:', error);
      }

      try {
        const creditoResult = await supabase.from('vendas_cartao_credito').select('*');
        if (!creditoResult.error) vendasCreditoData = creditoResult;
      } catch (error) {
        console.warn('Tabela vendas_cartao_credito não encontrada:', error);
      }

      const clientes = clientesData.data || [];
      const orcamentos = orcamentosData.data || [];
      const pedidos = pedidosData.data || [];
      const despesas = despesasData.data || [];
      const movimentos = movimentosData.data || [];
      const parcelasBoleto = parcelasBoletoData.data || [];
      const parcelasCartao = parcelasCartaoData.data || [];
      const vendasCredito = vendasCreditoData.data || [];

      // ===== LÓGICA IDÊNTICA AO MÓDULO FINANCEIRO =====
      
      // 1. Combinar todos os movimentos financeiros
      const allMovimentos = [
        // Movimentos manuais
        ...movimentos.map(m => ({
          ...m,
          origem: 'manual',
          dataDisplay: m.data,
          valor_display: parseFloat(m.valor) || 0,
          tipoSaldo: m.tipo_saldo || 'conta',
          status_real: m.status
        })),
        
        // 2. Despesas pagas (apenas as que NÃO têm movimento manual associado)
        ...despesas
          .filter(d => {
            if (d.status !== 'pago' || !d.data_pagamento) return false;
            const hasManualMovement = movimentos.some(m => 
              m.referencia_id === d.id && m.referencia_tipo === 'despesa'
            );
            return !hasManualMovement;
          })
          .map(d => ({
            id: `despesa-${d.id}`,
            tipo: 'saida',
            categoria: d.categoria,
            descricao: d.descricao,
            valor: parseFloat(d.valor) || 0,
            data: d.data_pagamento,
            status: 'pago',
            status_real: 'pago',
            origem: 'despesa',
            dataDisplay: d.data_pagamento,
            valor_display: parseFloat(d.valor) || 0,
            tipoSaldo: d.tipo_saldo || 'conta'
          })),
        
        // 3. Pedidos pagos (vendas à vista com entrada no caixa)
        ...pedidos
          .filter(p => p.status_pagamento === 'pago' && p.entrada_caixa && p.data_pagamento)
          .map(p => ({
            id: `pedido-${p.id}`,
            tipo: 'entrada',
            categoria: 'Vendas - À Vista',
            descricao: `Venda - ${p.cliente_nome}`,
            valor: parseFloat(p.valor) || 0,
            data: p.data_pagamento,
            status: 'recebido',
            status_real: 'recebido',
            origem: 'pedido',
            dataDisplay: p.data_pagamento,
            valor_display: parseFloat(p.valor) || 0,
            tipoSaldo: p.tipo_saldo || 'conta'
          })),
        
        // 4. Parcelas de boleto recebidas
        ...parcelasBoleto
          .filter(p => p.status === 'recebida' && p.data_recebimento)
          .map(p => ({
            id: `boleto-${p.id}`,
            tipo: 'entrada',
            categoria: 'Vendas - Boleto',
            descricao: `Boleto ${p.numero_parcela}/${p.total_parcelas}`,
            valor: parseFloat(p.valor) || 0,
            data: p.data_recebimento,
            status: 'recebido',
            status_real: 'recebido',
            origem: 'boleto',
            dataDisplay: p.data_recebimento,
            valor_display: parseFloat(p.valor) || 0,
            tipoSaldo: 'conta'
          })),
        
        // 5. Parcelas de cartão recebidas
        ...parcelasCartao
          .filter(p => p.status === 'recebida' && p.data_recebimento)
          .map(p => ({
            id: `cartao-${p.id}`,
            tipo: 'entrada',
            categoria: 'Vendas - Crédito',
            descricao: `Cartão ${p.numero_parcela}/${p.total_parcelas}`,
            valor: parseFloat(p.valor) || 0,
            data: p.data_recebimento,
            status: 'recebido',
            status_real: 'recebido',
            origem: 'cartao',
            dataDisplay: p.data_recebimento,
            valor_display: parseFloat(p.valor) || 0,
            tipoSaldo: 'conta'
          })),

        // 6. Vendas no cartão de crédito recebidas
        ...vendasCredito
          .filter(v => v.status === 'recebida' && v.data_recebimento)
          .map(v => ({
            id: `venda-credito-${v.id}`,
            tipo: 'entrada',
            categoria: 'Vendas - Crédito',
            descricao: `Venda Cartão de Crédito`,
            valor: parseFloat(v.valor) || 0,
            data: v.data_recebimento,
            status: 'recebido',
            status_real: 'recebido',
            origem: 'venda-credito',
            dataDisplay: v.data_recebimento,
            valor_display: parseFloat(v.valor) || 0,
            tipoSaldo: 'conta'
          }))
      ];

      const saldoInicialConta = saldoConfig?.saldo_conta || 0;
      const saldoInicialDinheiro = saldoConfig?.saldo_dinheiro || 0;
      // ===== CÁLCULOS IDÊNTICOS AO MÓDULO FINANCEIRO =====
      
      // Filtrar apenas movimentos com status válido
      const movimentosValidos = allMovimentos.filter(m => 
        m.dataDisplay && 
        (m.status_real === 'recebido' || m.status_real === 'pago') &&
        !isNaN(m.valor_display) &&
        m.valor_display > 0
      );

      const totalEntradas = allMovimentos
        .filter(m => 
          m.tipo === 'entrada' && 
          (m.status_real === 'recebido' || m.status === 'recebido') &&
          !isNaN(m.valor_display) &&
          m.valor_display > 0
        )
        .reduce((sum, m) => sum + (m.valor_display || 0), 0);

      const totalSaidas = allMovimentos
        .filter(m => 
          m.tipo === 'saida' && 
          (m.status_real === 'pago' || m.status === 'pago') &&
          !isNaN(m.valor_display) &&
          m.valor_display > 0
        )
        .reduce((sum, m) => sum + (m.valor_display || 0), 0);

      const totalEntradasConta = allMovimentos
        .filter(m => 
          m.tipo === 'entrada' && 
          (m.status_real === 'recebido' || m.status === 'recebido') && 
          m.tipoSaldo === 'conta' &&
          !isNaN(m.valor_display) &&
          m.valor_display > 0
        )
        .reduce((sum, m) => sum + (m.valor_display || 0), 0);

      const totalEntradasDinheiro = allMovimentos
        .filter(m => 
          m.tipo === 'entrada' && 
          (m.status_real === 'recebido' || m.status === 'recebido') && 
          m.tipoSaldo === 'dinheiro' &&
          !isNaN(m.valor_display) &&
          m.valor_display > 0
        )
        .reduce((sum, m) => sum + (m.valor_display || 0), 0);

      const totalSaidasConta = allMovimentos
        .filter(m => 
          m.tipo === 'saida' && 
          (m.status_real === 'pago' || m.status === 'pago') && 
          m.tipoSaldo === 'conta' &&
          !isNaN(m.valor_display) &&
          m.valor_display > 0
        )
        .reduce((sum, m) => sum + (m.valor_display || 0), 0);

      const totalSaidasDinheiro = allMovimentos
        .filter(m => 
          m.tipo === 'saida' && 
          (m.status_real === 'pago' || m.status === 'pago') && 
          m.tipoSaldo === 'dinheiro' &&
          !isNaN(m.valor_display) &&
          m.valor_display > 0
        )
        .reduce((sum, m) => sum + (m.valor_display || 0), 0);

      const saldoAtualConta = saldoInicialConta + totalEntradasConta - totalSaidasConta;
      const saldoAtualDinheiro = saldoInicialDinheiro + totalEntradasDinheiro - totalSaidasDinheiro;
      const saldoAtual = saldoAtualConta + saldoAtualDinheiro;

      // ===== ESTATÍSTICAS DOS ORÇAMENTOS =====
      const orcamentosPendentes = orcamentos.filter(o => o.status === 'pendente').length;
      const orcamentosAceitos = orcamentos.filter(o => o.status === 'aceito').length;
      const orcamentosRecusados = orcamentos.filter(o => o.status === 'recusado').length;
      const valorOrcamentosPendentes = orcamentos
        .filter(o => o.status === 'pendente')
        .reduce((sum, o) => sum + (parseFloat(o.valor) || 0), 0);
      const valorOrcamentosAceitos = orcamentos
        .filter(o => o.status === 'aceito')
        .reduce((sum, o) => sum + (parseFloat(o.valor) || 0), 0);

      const pedidosAndamento = pedidos.filter(p => 
        !['finalizado', 'cancelado'].includes(p.status)
      ).length;

      const despesasPendentes = despesas.filter(d => d.status === 'pendente').length;
      const hoje = new Date();
      const despesasVencidas = despesas.filter(d => {
        if (d.status !== 'pendente') return false;
        const vencimento = new Date(d.data_vencimento);
        return vencimento < hoje;
      }).length;

      // ===== MOVIMENTAÇÕES RECENTES =====
      const allMovimentosRecentes = movimentosValidos
        .map(m => ({
          ...m,
          tipo_origem: m.origem,
          data_display: m.dataDisplay,
          descricao_display: m.descricao
        }))
        .sort((a, b) => new Date(b.data_display).getTime() - new Date(a.data_display).getTime())
        .slice(0, 10);

      setRecentMovimentos(allMovimentosRecentes);

      // ===== ATUALIZAR ESTATÍSTICAS =====
      setStats({
        clientesTotal: clientes.length,
        orcamentosAbertos: orcamentosPendentes,
        pedidosAndamento,
        faturamentoMes: totalEntradas,
        despesasMes: totalSaidas,
        saldoAtual,
        saldoAtualConta,
        saldoAtualDinheiro,
        totalEntradas,
        totalSaidas,
        orcamentosPendentes,
        orcamentosAceitos,
        orcamentosRecusados,
        valorOrcamentosPendentes,
        valorOrcamentosAceitos,
        despesasPendentes,
        despesasVencidas
      });

      setSaldoConfig(prev => prev || { saldo_conta: 0, saldo_dinheiro: 0 });

    } catch (error) {
      console.error('Erro ao buscar dados do dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Dashboard</h1>
        <p className="text-gray-600 dark:text-gray-400">Visão geral das operações da empresa</p>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 border border-blue-200 dark:border-blue-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-800 dark:text-blue-300">Clientes</p>
              <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">{stats.clientesTotal}</p>
              <p className="text-xs text-blue-600 dark:text-blue-400">Total cadastrados</p>
            </div>
            <Users className="text-blue-600 dark:text-blue-400" size={32} />
          </div>
        </div>

        <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg p-6 border border-yellow-200 dark:border-yellow-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-yellow-800 dark:text-yellow-300">Orçamentos Abertos</p>
              <p className="text-2xl font-bold text-yellow-900 dark:text-yellow-100">{stats.orcamentosAbertos}</p>
              <p className="text-xs text-yellow-600 dark:text-yellow-400">
                R$ {stats.valorOrcamentosPendentes.toLocaleString('pt-BR')}
              </p>
            </div>
            <FileText className="text-yellow-600 dark:text-yellow-400" size={32} />
          </div>
        </div>

        <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-6 border border-purple-200 dark:border-purple-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-purple-800 dark:text-purple-300">Pedidos em Andamento</p>
              <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">{stats.pedidosAndamento}</p>
              <p className="text-xs text-purple-600 dark:text-purple-400">Em produção</p>
            </div>
            <ShoppingCart className="text-purple-600 dark:text-purple-400" size={32} />
          </div>
        </div>

        <div className={`rounded-lg p-6 border ${
          stats.saldoAtual >= 0 
            ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-700' 
            : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-700'
        }`}>
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-sm font-medium ${
                stats.saldoAtual >= 0 ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'
              }`}>
                Saldo Total
              </p>
              <p className={`text-2xl font-bold ${
                stats.saldoAtual >= 0 ? 'text-green-900 dark:text-green-100' : 'text-red-900 dark:text-red-100'
              }`}>
                R$ {stats.saldoAtual.toLocaleString('pt-BR')}
              </p>
              <p className={`text-xs ${
                stats.saldoAtual >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
              }`}>
                Conta + Dinheiro
              </p>
            </div>
            {stats.saldoAtual >= 0 ? (
              <TrendingUp className="text-green-600 dark:text-green-400" size={32} />
            ) : (
              <TrendingDown className="text-red-600 dark:text-red-400" size={32} />
            )}
          </div>
        </div>
      </div>

      {/* Financial Summary - VALORES IGUAIS AO FINANCEIRO */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-6 border border-green-200 dark:border-green-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-green-800 dark:text-green-300">Entradas do Mês</h3>
            <TrendingUp className="text-green-600 dark:text-green-400" size={24} />
          </div>
          <p className="text-3xl font-bold text-green-900 dark:text-green-100 mb-2">
            R$ {stats.totalEntradas.toLocaleString('pt-BR')}
          </p>
          <div className="space-y-1 text-sm text-green-700 dark:text-green-300">
            <p>• Vendas à vista confirmadas</p>
            <p>• Parcelas de boleto recebidas</p>
            <p>• Parcelas de cartão recebidas</p>
            <p>• Movimentos manuais recebidos</p>
          </div>
        </div>

        <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-6 border border-red-200 dark:border-red-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-red-800 dark:text-red-300">Saídas do Mês</h3>
            <TrendingDown className="text-red-600 dark:text-red-400" size={24} />
          </div>
          <p className="text-3xl font-bold text-red-900 dark:text-red-100 mb-2">
            R$ {stats.totalSaidas.toLocaleString('pt-BR')}
          </p>
          <div className="space-y-1 text-sm text-red-700 dark:text-red-300">
            <p>• Despesas pagas no mês</p>
            <p>• Movimentos manuais pagos</p>
            <p>• Fornecedores e serviços</p>
            <p>• Outras saídas confirmadas</p>
          </div>
        </div>
      </div>

      {/* Orçamentos e Alertas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Status dos Orçamentos */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">Status dos Orçamentos</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
              <div className="flex items-center space-x-3">
                <Clock className="text-yellow-600 dark:text-yellow-400" size={20} />
                <div>
                  <p className="font-medium text-yellow-800 dark:text-yellow-300">Pendentes</p>
                  <p className="text-sm text-yellow-600 dark:text-yellow-400">
                    R$ {stats.valorOrcamentosPendentes.toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
              <span className="text-xl font-bold text-yellow-900 dark:text-yellow-100">
                {stats.orcamentosPendentes}
              </span>
            </div>

            <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="flex items-center space-x-3">
                <CheckCircle className="text-green-600 dark:text-green-400" size={20} />
                <div>
                  <p className="font-medium text-green-800 dark:text-green-300">Aceitos</p>
                  <p className="text-sm text-green-600 dark:text-green-400">
                    R$ {stats.valorOrcamentosAceitos.toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
              <span className="text-xl font-bold text-green-900 dark:text-green-100">
                {stats.orcamentosAceitos}
              </span>
            </div>

            <div className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
              <div className="flex items-center space-x-3">
                <AlertTriangle className="text-red-600 dark:text-red-400" size={20} />
                <div>
                  <p className="font-medium text-red-800 dark:text-red-300">Recusados</p>
                  <p className="text-sm text-red-600 dark:text-red-400">Oportunidades perdidas</p>
                </div>
              </div>
              <span className="text-xl font-bold text-red-900 dark:text-red-100">
                {stats.orcamentosRecusados}
              </span>
            </div>
          </div>
        </div>

        {/* Alertas e Pendências */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">Alertas e Pendências</h3>
          <div className="space-y-4">
            {stats.despesasVencidas > 0 && (
              <div className="flex items-center space-x-3 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-700">
                <AlertTriangle className="text-red-600 dark:text-red-400" size={20} />
                <div>
                  <p className="font-medium text-red-800 dark:text-red-300">Despesas Vencidas</p>
                  <p className="text-sm text-red-600 dark:text-red-400">
                    {stats.despesasVencidas} despesa(s) em atraso
                  </p>
                </div>
              </div>
            )}

            {stats.despesasPendentes > 0 && (
              <div className="flex items-center space-x-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-700">
                <Clock className="text-yellow-600 dark:text-yellow-400" size={20} />
                <div>
                  <p className="font-medium text-yellow-800 dark:text-yellow-300">Despesas Pendentes</p>
                  <p className="text-sm text-yellow-600 dark:text-yellow-400">
                    {stats.despesasPendentes} despesa(s) para pagar
                  </p>
                </div>
              </div>
            )}

            {stats.orcamentosAbertos > 0 && (
              <div className="flex items-center space-x-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700">
                <FileText className="text-blue-600 dark:text-blue-400" size={20} />
                <div>
                  <p className="font-medium text-blue-800 dark:text-blue-300">Orçamentos Aguardando</p>
                  <p className="text-sm text-blue-600 dark:text-blue-400">
                    {stats.orcamentosAbertos} orçamento(s) pendente(s)
                  </p>
                </div>
              </div>
            )}

            {stats.despesasVencidas === 0 && stats.despesasPendentes === 0 && stats.orcamentosAbertos === 0 && (
              <div className="flex items-center space-x-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-700">
                <CheckCircle className="text-green-600 dark:text-green-400" size={20} />
                <div>
                  <p className="font-medium text-green-800 dark:text-green-300">Tudo em Dia!</p>
                  <p className="text-sm text-green-600 dark:text-green-400">
                    Nenhuma pendência encontrada
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Movimentações Recentes */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <div className="px-6 py-4">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Movimentações Recentes</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Últimas 10 movimentações financeiras (valores iguais ao módulo Financeiro)
            </p>
          </div>
        </div>
        
        <div className="p-6">
          <div className="space-y-3">
            {recentMovimentos.map((movimento) => (
              <div key={movimento.id} className="flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${
                    movimento.tipo === 'entrada' 
                      ? 'bg-green-100 dark:bg-green-900/30' 
                      : 'bg-red-100 dark:bg-red-900/30'
                  }`}>
                    {movimento.tipo === 'entrada' ? (
                      <TrendingUp className="text-green-600 dark:text-green-400" size={16} />
                    ) : (
                      <TrendingDown className="text-red-600 dark:text-red-400" size={16} />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-gray-800 dark:text-white text-sm">{movimento.descricao_display}</p>
                    <div className="flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-400">
                      <span>{movimento.categoria}</span>
                      <span>•</span>
                      <span>{movimento.data_display ? new Date(movimento.data_display + 'T00:00:00').toLocaleDateString('pt-BR') : 'N/A'}</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        movimento.tipoSaldo === 'conta' 
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' 
                          : 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
                      }`}>
                        {movimento.tipoSaldo === 'conta' ? 'Conta' : 'Dinheiro'}
                      </span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        movimento.tipo_origem === 'boleto' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' :
                        movimento.tipo_origem === 'cartao' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300' :
                        movimento.tipo_origem === 'despesa' ? 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300' :
                        movimento.tipo_origem === 'pedido' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' :
                        'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300'
                      }`}>
                        {movimento.tipo_origem === 'boleto' ? 'Boleto' :
                         movimento.tipo_origem === 'cartao' ? 'Cartão' :
                         movimento.tipo_origem === 'despesa' ? 'Despesa' :
                         movimento.tipo_origem === 'pedido' ? 'Venda' : 'Manual'}
                      </span>
                    </div>
                  </div>
                </div>
                <span className={`font-bold ${
                  movimento.tipo === 'entrada' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                }`}>
                  {movimento.tipo === 'entrada' ? '+' : '-'}R$ {movimento.valor_display.toLocaleString('pt-BR')}
                </span>
              </div>
            ))}

            {recentMovimentos.length === 0 && (
              <div className="text-center py-8">
                <DollarSign size={32} className="mx-auto text-gray-400 mb-2" />
                <p className="text-gray-500 dark:text-gray-400">Nenhuma movimentação recente</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Resumo Financeiro Detalhado */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <div className="px-6 py-4">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Resumo Financeiro Detalhado</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Saldos separados por tipo (conta bancária e dinheiro físico)
            </p>
          </div>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <p className="text-sm font-medium text-blue-800 dark:text-blue-300">Saldo em Conta</p>
              <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                R$ {stats.saldoAtualConta.toLocaleString('pt-BR')}
              </p>
              <p className="text-xs text-blue-600 dark:text-blue-400">Banco/PIX/Cartão</p>
            </div>

            <div className="text-center">
              <p className="text-sm font-medium text-green-800 dark:text-green-300">Saldo em Dinheiro</p>
              <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                R$ {stats.saldoAtualDinheiro.toLocaleString('pt-BR')}
              </p>
              <p className="text-xs text-green-600 dark:text-green-400">Caixa físico</p>
            </div>
            
            <div className="text-center">
              <p className="text-sm font-medium text-green-800 dark:text-green-300">Total de Entradas</p>
              <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                R$ {stats.totalEntradas.toLocaleString('pt-BR')}
              </p>
              <p className="text-xs text-green-600 dark:text-green-400">Valores confirmados</p>
            </div>
            
            <div className="text-center">
              <p className={`text-sm font-medium ${
                stats.saldoAtual >= 0 ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'
              }`}>
                Saldo Total
              </p>
              <p className={`text-2xl font-bold ${
                stats.saldoAtual >= 0 ? 'text-green-900 dark:text-green-100' : 'text-red-900 dark:text-red-100'
              }`}>
                R$ {stats.saldoAtual.toLocaleString('pt-BR')}
              </p>
              <p className={`text-xs ${
                stats.saldoAtual >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
              }`}>
                Conta + Dinheiro
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <button className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow text-center">
          <Users className="mx-auto text-blue-600 dark:text-blue-400 mb-2" size={24} />
          <p className="text-sm font-medium text-gray-800 dark:text-white">Novo Cliente</p>
        </button>
        
        <button className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow text-center">
          <FileText className="mx-auto text-green-600 dark:text-green-400 mb-2" size={24} />
          <p className="text-sm font-medium text-gray-800 dark:text-white">Novo Orçamento</p>
        </button>
        
        <button className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow text-center">
          <ShoppingCart className="mx-auto text-purple-600 dark:text-purple-400 mb-2" size={24} />
          <p className="text-sm font-medium text-gray-800 dark:text-white">Novo Pedido</p>
        </button>
        
        <button className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow text-center">
          <DollarSign className="mx-auto text-orange-600 dark:text-orange-400 mb-2" size={24} />
          <p className="text-sm font-medium text-gray-800 dark:text-white">Nova Despesa</p>
        </button>
      </div>
    </div>
  );
};

export default Dashboard;