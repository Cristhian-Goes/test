import React, { useState, useEffect } from 'react';
import { Plus, Search, CreditCard as Edit, Trash2, FileText, Calculator, Check, X, Clock, Printer, Eye } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { generateOrcamentoPDF } from '../../utils/pdfGenerator';
import ClienteSearch from '../Common/ClienteSearch';
import { useAuth } from '../../contexts/AuthContext';

interface OrcamentosAprimoradosProps {
  prefilledData?: any;
}

interface Orcamento {
  id: string;
  clienteId: string;
  cliente_nome: string;
  descricao: string;
  valor: number;
  data_gerado: string;
  status: 'pendente' | 'aceito' | 'recusado';
  tipo_pagamento: string;
  tipo_atendimento: string;
  observacoes?: string;
  created_at: string;
}

const OrcamentosAprimorados: React.FC<OrcamentosAprimoradosProps> = ({ prefilledData }) => {
  const { user } = useAuth();
  const [orcamentos, setOrcamentos] = useState<Orcamento[]>([]);
  const [clientes, setClientes] = useState<any[]>([]);
  const [colaboradores, setColaboradores] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('todos');
  const [showModal, setShowModal] = useState(false);
  const [editingOrcamento, setEditingOrcamento] = useState<Orcamento | null>(null);
  const [selectedCliente, setSelectedCliente] = useState<any>(null);

  const [formData, setFormData] = useState({
    clienteId: '',
    clienteNome: '',
    descricao: '',
    valor: '',
    status: 'pendente' as const,
    tipo_pagamento: 'dinheiro' as const,
    tipo_atendimento: 'interno' as const,
    observacoes: '',
    parcelas_cartao: 1,
    parcelas_boleto: 1,
    data_vencimento_boleto: ''
  });

  useEffect(() => {
    fetchOrcamentos();
    fetchClientes();
    fetchColaboradores();
  }, [user]);

  useEffect(() => {
    if (prefilledData) {
      setFormData({
        clienteId: prefilledData.clienteId || '',
        clienteNome: prefilledData.clienteNome || '',
        descricao: prefilledData.descricao || '',
        valor: prefilledData.valor ? prefilledData.valor.toString() : '',
        status: 'pendente',
        tipo_pagamento: prefilledData.tipoPagamento || 'dinheiro',
        tipo_atendimento: prefilledData.tipoAtendimento || 'interno',
        observacoes: prefilledData.observacoes || ''
      });
      
      if (prefilledData.clienteId) {
        const cliente = clientes.find(c => c.id === prefilledData.clienteId);
        setSelectedCliente(cliente || null);
      }
      
      setShowModal(true);
    }
  }, [prefilledData, clientes]);
  const fetchOrcamentos = async () => {
    try {
      const { data, error } = await supabase
        .from('orcamentos')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      const orcamentosFormatted = data?.map(item => ({
        id: item.id,
        clienteId: item.cliente_id,
        cliente_nome: item.cliente_nome,
        descricao: item.descricao,
        valor: item.valor,
        data_gerado: item.data_gerado,
        status: item.status,
        tipo_pagamento: item.tipo_pagamento,
        tipo_atendimento: item.tipo_atendimento || 'interno',
        observacoes: item.observacoes || '',
        created_at: item.created_at
      })) || [];
      
      setOrcamentos(orcamentosFormatted);
    } catch (error) {
      console.error('Erro ao buscar orçamentos:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchClientes = async () => {
    try {
      const { data, error } = await supabase
        .from('clientes')
        .select('*')
        .order('nome');

      if (error) throw error;
      setClientes(data || []);
    } catch (error) {
      console.error('Erro ao buscar clientes:', error);
    }
  };

  const fetchColaboradores = async () => {
    try {
      const { data, error } = await supabase
        .from('colaboradores')
        .select('nome')
        .eq('status', 'ativo')
        .order('nome');

      if (error) throw error;
      setColaboradores(data || []);
    } catch (error) {
      console.error('Erro ao buscar colaboradores:', error);
    }
  };

  const updateOrcamentoStatus = async (id: string, newStatus: 'aceito' | 'recusado') => {
    try {
      const { error } = await supabase
        .from('orcamentos')
        .update({ status: newStatus })
        .eq('id', id);

      if (error) throw error;

      const orcamento = orcamentos.find(o => o.id === id);
      if (!orcamento) return;

      if (newStatus === 'aceito') {
        // Buscar dados completos do orçamento incluindo parcelas
        const { data: orcamentoCompleto, error: fetchError } = await supabase
          .from('orcamentos')
          .select('*')
          .eq('id', id)
          .single();

        if (fetchError) throw fetchError;

        // Criar parcelas se for pagamento em crédito
        if (orcamentoCompleto.tipo_pagamento === 'credito' && orcamentoCompleto.parcelas_cartao > 1) {
          const { error: parcelasError } = await supabase.rpc('create_credit_installments', {
            p_orcamento_id: id,
            p_numero_parcelas: orcamentoCompleto.parcelas_cartao,
            p_valor_total: orcamentoCompleto.valor
          });

          if (parcelasError) {
            console.error('Erro ao criar parcelas de crédito:', parcelasError);
            throw parcelasError;
          }
        }

        // Criar parcelas se for pagamento em boleto
        if (orcamentoCompleto.tipo_pagamento === 'boleto' && orcamentoCompleto.parcelas_boleto > 1) {
          const { error: parcelasError } = await supabase.rpc('create_boleto_installments', {
            p_orcamento_id: id,
            p_numero_parcelas: orcamentoCompleto.parcelas_boleto,
            p_valor_total: orcamentoCompleto.valor,
            p_data_primeira_parcela: orcamentoCompleto.data_vencimento_boleto
          });

          if (parcelasError) {
            console.error('Erro ao criar parcelas de boleto:', parcelasError);
            throw parcelasError;
          }
        }

        // Criar pedido automaticamente
        await createPedidoFromOrcamento(orcamento);
        alert('Orçamento aceito! Pedido criado automaticamente e parcelas geradas.');
      } else if (newStatus === 'recusado') {
        alert('Orçamento recusado! Disponível na seção de Recuperação de Vendas.');
      }

      await fetchOrcamentos();
    } catch (error) {
      console.error('Erro ao atualizar status:', error);
      alert('Erro ao atualizar status do orçamento');
    }
  };

  const createPedidoFromOrcamento = async (orcamento: Orcamento) => {
    try {
      const pedidoData = {
        orcamento_id: orcamento.id,
        cliente_nome: orcamento.cliente_nome,
        descricao: orcamento.descricao,
        valor: orcamento.valor,
        status: 'aguardando_corte',
        status_pagamento: 'pendente',
        entrada_caixa: false,
        tipo_saldo: 'conta',
        data_inicio: new Date().toISOString().split('T')[0],
        responsavel: user?.name || 'Sistema',
        executores: []
      };

      const { error } = await supabase
        .from('pedidos')
        .insert([pedidoData]);

      if (error) throw error;
    } catch (error) {
      console.error('Erro ao criar pedido:', error);
      throw error;
    }
  };
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const clienteNome = selectedCliente ? selectedCliente.nome : formData.clienteNome;
      const clienteId = selectedCliente ? selectedCliente.id : null;
      
      if (!clienteNome) {
        alert('Por favor, selecione um cliente ou digite o nome');
        return;
      }

      const orcamentoData: any = {
        cliente_id: clienteId,
        cliente_nome: clienteNome,
        descricao: formData.descricao,
        valor: parseFloat(formData.valor) || 0,
        data_gerado: new Date().toISOString().split('T')[0],
        status: formData.status,
        tipo_pagamento: formData.tipo_pagamento,
        tipo_atendimento: formData.tipo_atendimento,
        observacoes: formData.observacoes
      };

      // Adicionar dados de parcelamento se necessário
      if (formData.tipo_pagamento === 'credito') {
        orcamentoData.parcelas_cartao = formData.parcelas_cartao;
      }

      if (formData.tipo_pagamento === 'boleto') {
        orcamentoData.parcelas_boleto = formData.parcelas_boleto;
        orcamentoData.data_vencimento_boleto = formData.data_vencimento_boleto;
      }

      if (editingOrcamento) {
        const { error } = await supabase
          .from('orcamentos')
          .update(orcamentoData)
          .eq('id', editingOrcamento.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('orcamentos')
          .insert([orcamentoData]);

        if (error) throw error;
      }

      handleCloseModal();
      await fetchOrcamentos();
    } catch (error) {
      console.error('Erro ao salvar orçamento:', error);
      alert('Erro ao salvar orçamento');
    }
  };

  const handleEdit = (orcamento: Orcamento) => {
    setEditingOrcamento(orcamento);
    const cliente = clientes.find(c => c.id === orcamento.clienteId);
    setSelectedCliente(cliente || null);
    setFormData({
      clienteId: orcamento.clienteId,
      clienteNome: orcamento.cliente_nome,
      descricao: orcamento.descricao,
      valor: orcamento.valor.toString(),
      status: orcamento.status,
      tipo_pagamento: orcamento.tipo_pagamento,
      tipo_atendimento: orcamento.tipo_atendimento,
      observacoes: orcamento.observacoes || ''
    });
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingOrcamento(null);
    setSelectedCliente(null);
    setFormData({
      clienteId: '',
      clienteNome: '',
      descricao: '',
      valor: '',
      status: 'pendente',
      tipo_pagamento: 'dinheiro',
      tipo_atendimento: 'interno',
      observacoes: '',
      parcelas_cartao: 1,
      parcelas_boleto: 1,
      data_vencimento_boleto: ''
    });
  };

  const handleDelete = async (id: string) => {
    if (confirm('Tem certeza que deseja excluir este orçamento?')) {
      try {
        const { error } = await supabase
          .from('orcamentos')
          .delete()
          .eq('id', id);

        if (error) throw error;
        await fetchOrcamentos();
      } catch (error) {
        console.error('Erro ao excluir orçamento:', error);
      }
    }
  };

  const handlePrintOrcamento = (orcamento: Orcamento) => {
    const cliente = clientes.find(c => c.id === orcamento.clienteId);
    if (!cliente) {
      alert('Cliente não encontrado!');
      return;
    }

    const numeroOrcamento = `ORC-${orcamento.id.slice(-6).toUpperCase()}`;
    
    const orcamentoData = {
      id: numeroOrcamento,
      clienteNome: orcamento.cliente_nome,
      descricao: orcamento.descricao,
      valor: orcamento.valor,
      dataGerado: orcamento.data_gerado,
      observacoes: orcamento.observacoes,
      numeroOrcamento,
      dataEmissao: orcamento.data_gerado
    };

    const clienteData = {
      nome: cliente.nome,
      endereco: cliente.endereco || {
        rua: '',
        numero: '',
        bairro: '',
        cidade: '',
        estado: '',
        cep: ''
      },
      telefone: cliente.telefone || ''
    };

    generateOrcamentoPDF(orcamentoData, clienteData, orcamento.tipo_atendimento === 'externo');
  };

  const filteredOrcamentos = orcamentos.filter(orcamento => {
    const matchesSearch = orcamento.cliente_nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         orcamento.descricao.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'todos' || orcamento.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'aceito': return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
      case 'recusado': return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300';
      default: return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'aceito': return 'Aceito';
      case 'recusado': return 'Recusado';
      default: return 'Pendente';
    }
  };

  // Estatísticas dos orçamentos
  const totalOrcamentos = orcamentos.length;
  const orcamentosPendentes = orcamentos.filter(o => o.status === 'pendente').length;
  const orcamentosAceitos = orcamentos.filter(o => o.status === 'aceito').length;
  const orcamentosRecusados = orcamentos.filter(o => o.status === 'recusado').length;
  const valorTotalPendente = orcamentos
    .filter(o => o.status === 'pendente')
    .reduce((sum, o) => sum + o.valor, 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6 p-4 sm:p-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <Calculator className="w-6 h-6" />
          Orçamentos
        </h1>
        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Novo Orçamento
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg p-4 border border-yellow-200 dark:border-yellow-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-yellow-800 dark:text-yellow-300">Pendentes</p>
              <p className="text-xl sm:text-2xl font-bold text-yellow-900 dark:text-yellow-100">{orcamentosPendentes}</p>
              <p className="text-xs text-yellow-600 dark:text-yellow-400">
                R$ {valorTotalPendente.toLocaleString('pt-BR')}
              </p>
            </div>
            <Clock className="text-yellow-600 dark:text-yellow-400" size={24} />
          </div>
        </div>

        <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 border border-green-200 dark:border-green-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-800 dark:text-green-300">Aceitos</p>
              <p className="text-xl sm:text-2xl font-bold text-green-900 dark:text-green-100">{orcamentosAceitos}</p>
            </div>
            <Check className="text-green-600 dark:text-green-400" size={24} />
          </div>
        </div>

        <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4 border border-red-200 dark:border-red-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-red-800 dark:text-red-300">Recusados</p>
              <p className="text-xl sm:text-2xl font-bold text-red-900 dark:text-red-100">{orcamentosRecusados}</p>
            </div>
            <X className="text-red-600 dark:text-red-400" size={24} />
          </div>
        </div>

        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-800 dark:text-blue-300">Total</p>
              <p className="text-xl sm:text-2xl font-bold text-blue-900 dark:text-blue-100">{totalOrcamentos}</p>
            </div>
            <FileText className="text-blue-600 dark:text-blue-400" size={24} />
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Buscar orçamentos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
            >
              <option value="todos">Todos os Status</option>
              <option value="pendente">Pendente</option>
              <option value="aceito">Aceito</option>
              <option value="recusado">Recusado</option>
            </select>
          </div>
        </div>

        <div className="space-y-4 p-6">
          {filteredOrcamentos.map((orcamento) => (
            <div key={orcamento.id} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 sm:p-6 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors">
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-800 dark:text-white">{orcamento.cliente_nome}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        ORC-{orcamento.id.slice(-6).toUpperCase()}
                      </p>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(orcamento.status)}`}>
                      {getStatusText(orcamento.status)}
                    </span>
                  </div>
                  
                  <p className="text-gray-700 dark:text-gray-300 mb-3">{orcamento.descricao}</p>
                  
                  <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                    <span>Valor: R$ {Number(orcamento.valor || 0).toLocaleString('pt-BR')}</span>
                    <span>Data: {orcamento.data_gerado ? new Date(orcamento.data_gerado + 'T00:00:00').toLocaleDateString('pt-BR') : 'N/A'}</span>
                    <span>Tipo: {orcamento.tipo_atendimento === 'externo' ? 'Externo' : 'Interno'}</span>
                    <span>Pagamento: {orcamento.tipo_pagamento}</span>
                  </div>
                  
                  {orcamento.observacoes && (
                    <div className="mt-3 p-3 bg-white dark:bg-gray-800 rounded-lg border">
                      <p className="text-sm text-gray-700 dark:text-gray-300">{orcamento.observacoes}</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                {/* Botões de ação baseados no status */}
                {orcamento.status === 'pendente' && (
                  <>
                    <button
                      onClick={() => updateOrcamentoStatus(orcamento.id, 'aceito')}
                      className="inline-flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm"
                    >
                      <Check size={16} />
                      <span>Aceitar</span>
                    </button>
                    <button
                      onClick={() => updateOrcamentoStatus(orcamento.id, 'recusado')}
                      className="inline-flex items-center space-x-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors text-sm"
                    >
                      <X size={16} />
                      <span>Recusar</span>
                    </button>
                  </>
                )}
                
                <button
                  onClick={() => handlePrintOrcamento(orcamento)}
                  className="inline-flex items-center space-x-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors text-sm"
                >
                  <Printer size={16} />
                  <span>Imprimir</span>
                </button>
                
                <button
                  onClick={() => handleEdit(orcamento)}
                  className="inline-flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm"
                >
                  <Edit size={16} />
                  <span>Editar</span>
                </button>
                
                <button
                  onClick={() => handleDelete(orcamento.id)}
                  className="inline-flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors text-sm"
                >
                  <Trash2 size={16} />
                  <span>Excluir</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredOrcamentos.length === 0 && (
          <div className="text-center py-12 px-6">
            <FileText className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900 dark:text-white">Nenhum orçamento encontrado</h3>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {searchTerm ? 'Tente ajustar sua busca.' : 'Comece criando um novo orçamento.'}
            </p>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {editingOrcamento ? 'Editar Orçamento' : 'Novo Orçamento'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Cliente
                  </label>
                  <ClienteSearch
                    onClienteSelect={setSelectedCliente}
                    selectedCliente={selectedCliente}
                    placeholder="Buscar cliente por nome, CPF/CNPJ ou telefone..."
                  />
                  {!selectedCliente && (
                    <div className="mt-2">
                      <input
                        type="text"
                        value={formData.clienteNome}
                        onChange={(e) => setFormData({ ...formData, clienteNome: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                        placeholder="Ou digite o nome do cliente..."
                      />
                    </div>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Valor
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    value={formData.valor}
                    onChange={(e) => setFormData({ ...formData, valor: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                    placeholder="Digite o valor do orçamento"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Descrição do Serviço
                </label>
                <textarea
                  required
                  rows={3}
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  placeholder="Descreva o serviço a ser realizado..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Tipo de Atendimento
                  </label>
                  <select
                    value={formData.tipo_atendimento}
                    onChange={(e) => setFormData({ ...formData, tipo_atendimento: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  >
                    <option value="interno">Serviço Interno</option>
                    <option value="externo">Serviço Externo</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Tipo de Pagamento
                  </label>
                  <select
                    value={formData.tipo_pagamento}
                    onChange={(e) => setFormData({ ...formData, tipo_pagamento: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  >
                    <option value="dinheiro">Dinheiro</option>
                    <option value="pix">PIX</option>
                    <option value="debito">Débito</option>
                    <option value="credito">Crédito</option>
                    <option value="boleto">Boleto</option>
                    <option value="transferencia">Transferência</option>
                  </select>
                </div>

                {formData.tipo_pagamento === 'credito' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Número de Parcelas (Crédito)
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="24"
                      value={formData.parcelas_cartao}
                      onChange={(e) => setFormData({ ...formData, parcelas_cartao: parseInt(e.target.value) || 1 })}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                      placeholder="Ex: 3"
                    />
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      As parcelas serão lançadas no dia 1º de cada mês
                    </p>
                  </div>
                )}

                {formData.tipo_pagamento === 'boleto' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Número de Parcelas (Boleto)
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="12"
                        value={formData.parcelas_boleto}
                        onChange={(e) => setFormData({ ...formData, parcelas_boleto: parseInt(e.target.value) || 1 })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                        placeholder="Ex: 2"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Vencimento da Primeira Parcela
                      </label>
                      <input
                        type="date"
                        value={formData.data_vencimento_boleto}
                        onChange={(e) => setFormData({ ...formData, data_vencimento_boleto: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                        required={formData.tipo_pagamento === 'boleto'}
                      />
                    </div>
                  </>
                )}
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  >
                    <option value="pendente">Pendente</option>
                    <option value="aceito">Aceito</option>
                    <option value="recusado">Recusado</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Observações
                </label>
                <textarea
                  value={formData.observacoes}
                  onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  placeholder="Observações adicionais sobre o orçamento..."
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  {editingOrcamento ? 'Atualizar' : 'Criar'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrcamentosAprimorados;