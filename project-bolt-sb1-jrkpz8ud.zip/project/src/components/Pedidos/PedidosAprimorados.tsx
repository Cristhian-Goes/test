import React, { useState, useEffect } from 'react';
import { Plus, Search, ShoppingCart, Clock, Scissors, Wrench, CheckCircle, Eye, CreditCard as Edit, Trash2, DollarSign, CreditCard, Wallet, Banknote } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import ClienteSearch from '../Common/ClienteSearch';

interface Pedido {
  id: string;
  orcamentoId: string;
  clienteNome: string;
  descricao: string;
  valor: number;
  status: 'aguardando_corte' | 'em_corte' | 'pronto_instalacao' | 'em_instalacao' | 'finalizado';
  statusPagamento: 'pendente' | 'pago';
  dataPagamento?: string;
  entradaCaixa: boolean;
  tipoSaldo?: 'conta' | 'dinheiro';
  dataInicio: string;
  dataFinal?: string;
  responsavel: string;
  executores: string[];
}

const PedidosAprimorados: React.FC = () => {
  const [pedidos, setPedidos] = useState<Pedido[]>([]);
  const [clientes, setClientes] = useState<any[]>([]);
  const [colaboradores, setColaboradores] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingPedido, setEditingPedido] = useState<Pedido | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('todos');
  const [selectedCliente, setSelectedCliente] = useState<any>(null);
  const [showPaymentModal, setShowPaymentModal] = useState<string | null>(null);
  const [paymentType, setPaymentType] = useState<'conta' | 'dinheiro' | 'credito'>('conta');
  const [formData, setFormData] = useState<Omit<Pedido, 'id'>>({
    orcamentoId: '',
    clienteNome: '',
    descricao: '',
    valor: 0,
    status: 'aguardando_corte',
    statusPagamento: 'pendente',
    dataPagamento: '',
    entradaCaixa: false,
    tipoSaldo: 'conta',
    dataInicio: new Date().toISOString().split('T')[0],
    dataFinal: '',
    responsavel: '',
    executores: []
  });

  useEffect(() => {
    fetchPedidos();
    fetchClientes();
    fetchColaboradores();
  }, []);

  const fetchPedidos = async () => {
    try {
      const { data, error } = await supabase
        .from('pedidos')
        .select('*')
        .order('data_inicio', { ascending: false });

      if (error) throw error;

      const pedidosFormatted = data?.map(item => ({
        id: item.id,
        orcamentoId: item.orcamento_id,
        clienteNome: item.cliente_nome,
        descricao: item.descricao,
        valor: item.valor,
        status: item.status,
        statusPagamento: item.status_pagamento || 'pendente',
        dataPagamento: item.data_pagamento,
        entradaCaixa: item.entrada_caixa || false,
        tipoSaldo: item.tipo_saldo || 'conta',
        dataInicio: item.data_inicio,
        dataFinal: item.data_final,
        responsavel: item.responsavel,
        executores: Array.isArray(item.executores) ? item.executores : []
      })) || [];

      setPedidos(pedidosFormatted);
    } catch (error) {
      console.error('Erro ao buscar pedidos:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchClientes = async () => {
    try {
      const { data, error } = await supabase
        .from('clientes')
        .select('*')
        .order('nome');

      if (error) throw error;
      setClientes(data || []);
    } catch (error) {
      console.error('Erro ao buscar clientes:', error);
    }
  };

  const fetchColaboradores = async () => {
    try {
      const { data, error } = await supabase
        .from('colaboradores')
        .select('nome')
        .eq('status', 'ativo')
        .order('nome');

      if (error) throw error;
      setColaboradores(data || []);
    } catch (error) {
      console.error('Erro ao buscar colaboradores:', error);
    }
  };

  const updatePedidoStatus = async (id: string, newStatus: Pedido['status']) => {
    try {
      const updateData: any = { status: newStatus };
      
      // Se finalizado, adicionar data final
      if (newStatus === 'finalizado') {
        updateData.data_final = new Date().toISOString().split('T')[0];
      }

      const { error } = await supabase
        .from('pedidos')
        .update(updateData)
        .eq('id', id);

      if (error) throw error;
      await fetchPedidos();
    } catch (error) {
      console.error('Erro ao atualizar status:', error);
    }
  };

  const markAsPaid = async (id: string) => {
    setShowPaymentModal(id);
  };

  const confirmPayment = async () => {
    if (!showPaymentModal) return;

    try {
      const pedido = pedidos.find(p => p.id === showPaymentModal);
      if (!pedido) return;

      if (paymentType === 'credito') {
        // Para cartão de crédito, criar registro de venda que será recebida no dia 1º do mês seguinte
        const dataVenda = new Date().toISOString().split('T')[0];
        const proximoPrimeiroDia = new Date();
        proximoPrimeiroDia.setMonth(proximoPrimeiroDia.getMonth() + 1);
        proximoPrimeiroDia.setDate(1);
        const dataRecebimento = proximoPrimeiroDia.toISOString().split('T')[0];

        const { error: creditoError } = await supabase
          .from('vendas_cartao_credito')
          .insert([{
            pedido_id: showPaymentModal,
            valor: pedido.valor,
            data_venda: dataVenda,
            data_recebimento: dataRecebimento,
            status: 'pendente'
          }]);

        if (creditoError) throw creditoError;

        // Atualizar pedido como pago mas sem entrada no caixa imediata
        const { error: pedidoError } = await supabase
          .from('pedidos')
          .update({
            status_pagamento: 'pago',
            data_pagamento: dataVenda,
            entrada_caixa: false,
            tipo_saldo: 'conta'
          })
          .eq('id', showPaymentModal);

        if (pedidoError) throw pedidoError;

        alert(`Pagamento registrado! O valor será lançado na conta no dia ${proximoPrimeiroDia.toLocaleDateString('pt-BR')}`);
      } else {
        // Para conta ou dinheiro, entrada imediata no caixa
        const { error: pedidoError } = await supabase
          .from('pedidos')
          .update({
            status_pagamento: 'pago',
            data_pagamento: new Date().toISOString().split('T')[0],
            entrada_caixa: true,
            tipo_saldo: paymentType
          })
          .eq('id', showPaymentModal);

        if (pedidoError) throw pedidoError;
      }

      await fetchPedidos();
      setShowPaymentModal(null);
      setPaymentType('conta');
    } catch (error) {
      console.error('Erro ao marcar como pago:', error);
      alert('Erro ao processar pagamento');
    }
  };

  const handleEdit = (pedido: Pedido) => {
    setEditingPedido(pedido);
    const cliente = clientes.find(c => c.nome === pedido.clienteNome);
    setSelectedCliente(cliente || null);
    setFormData({
      orcamentoId: pedido.orcamentoId,
      clienteNome: pedido.clienteNome,
      descricao: pedido.descricao,
      valor: pedido.valor,
      status: pedido.status,
      statusPagamento: pedido.statusPagamento,
      dataPagamento: pedido.dataPagamento || '',
      entradaCaixa: pedido.entradaCaixa,
      tipoSaldo: pedido.tipoSaldo || 'conta',
      dataInicio: pedido.dataInicio,
      dataFinal: pedido.dataFinal || '',
      responsavel: pedido.responsavel,
      executores: pedido.executores
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir este pedido?')) {
      try {
        const { error } = await supabase
          .from('pedidos')
          .delete()
          .eq('id', id);

        if (error) throw error;
        await fetchPedidos();
      } catch (error) {
        console.error('Erro ao excluir pedido:', error);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const clienteNome = selectedCliente ? selectedCliente.nome : formData.clienteNome;
      
      if (!clienteNome) {
        alert('Por favor, selecione um cliente ou digite o nome');
        setLoading(false);
        return;
      }

      const pedidoData = {
        orcamento_id: formData.orcamentoId || null,
        cliente_nome: clienteNome,
        descricao: formData.descricao,
        valor: formData.valor,
        status: formData.status,
        status_pagamento: formData.statusPagamento,
        data_pagamento: formData.dataPagamento || null,
        entrada_caixa: formData.entradaCaixa,
       tipo_saldo: formData.tipoSaldo,
        data_inicio: formData.dataInicio,
        data_final: formData.dataFinal || null,
        responsavel: formData.responsavel,
        executores: formData.executores
      };

      if (editingPedido) {
        const { error } = await supabase
          .from('pedidos')
          .update(pedidoData)
          .eq('id', editingPedido.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('pedidos')
          .insert([pedidoData]);

        if (error) throw error;
      }

      await fetchPedidos();
      handleCloseForm();
    } catch (error) {
      console.error('Erro ao salvar pedido:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingPedido(null);
    setSelectedCliente(null);
    setFormData({
      orcamentoId: '',
      clienteNome: '',
      descricao: '',
      valor: 0,
      status: 'aguardando_corte',
      statusPagamento: 'pendente',
      dataPagamento: '',
      entradaCaixa: false,
      dataInicio: new Date().toISOString().split('T')[0],
      dataFinal: '',
      responsavel: '',
      executores: []
    });
  };

  const filteredPedidos = pedidos.filter(pedido => {
    const matchesSearch = pedido.clienteNome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         pedido.descricao.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         pedido.responsavel.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'todos' || pedido.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    const colors = {
      'aguardando_corte': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'em_corte': 'bg-orange-100 text-orange-800 border-orange-200',
      'pronto_instalacao': 'bg-blue-100 text-blue-800 border-blue-200',
      'em_instalacao': 'bg-purple-100 text-purple-800 border-purple-200',
      'finalizado': 'bg-green-100 text-green-800 border-green-200'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const getStatusText = (status: string) => {
    const texts = {
      'aguardando_corte': 'Aguardando Corte',
      'em_corte': 'Em Corte',
      'pronto_instalacao': 'Pronto para Instalação',
      'em_instalacao': 'Em Instalação',
      'finalizado': 'Finalizado'
    };
    return texts[status as keyof typeof texts] || status;
  };

  const getStatusIcon = (status: string) => {
    const icons = {
      'aguardando_corte': Clock,
      'em_corte': Scissors,
      'pronto_instalacao': Wrench,
      'em_instalacao': Wrench,
      'finalizado': CheckCircle
    };
    return icons[status as keyof typeof icons] || Clock;
  };

  const getNextStatus = (currentStatus: string): Pedido['status'] | null => {
    const nextStatuses = {
      'aguardando_corte': 'em_corte',
      'em_corte': 'pronto_instalacao',
      'pronto_instalacao': 'em_instalacao',
      'em_instalacao': 'finalizado',
      'finalizado': null
    };
    return nextStatuses[currentStatus as keyof typeof nextStatuses] || null;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6 p-4 sm:p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-800 dark:text-white">Pedidos</h1>
          <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">Controle de produção e instalação</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="inline-flex items-center justify-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors w-full sm:w-auto"
        >
          <Plus size={20} />
          <span>Novo Pedido</span>
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Buscar por cliente ou descrição..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="todos">Todos os Status</option>
          <option value="aguardando_corte">Aguardando Corte</option>
          <option value="em_corte">Em Corte</option>
          <option value="pronto_instalacao">Pronto para Instalação</option>
          <option value="em_instalacao">Em Instalação</option>
          <option value="finalizado">Finalizado</option>
        </select>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {['aguardando_corte', 'em_corte', 'pronto_instalacao', 'em_instalacao', 'finalizado'].map(status => {
          const StatusIcon = getStatusIcon(status);
          const count = pedidos.filter(p => p.status === status).length;
          
          return (
            <div key={status} className={`rounded-lg p-4 border ${getStatusColor(status).replace('text-', 'bg-').replace('-800', '-50')}`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm font-medium ${getStatusColor(status).split(' ')[1]}`}>
                    {getStatusText(status)}
                  </p>
                  <p className={`text-lg sm:text-xl font-bold ${getStatusColor(status).split(' ')[1].replace('-800', '-900')}`}>
                    {count}
                  </p>
                </div>
                <StatusIcon className={getStatusColor(status).split(' ')[1].replace('-800', '-600')} size={20} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Pedidos List */}
      <div className="space-y-4">
        {filteredPedidos.map((pedido) => {
          const StatusIcon = getStatusIcon(pedido.status);
          const nextStatus = getNextStatus(pedido.status);
          
          return (
            <div key={pedido.id} className="bg-white dark:bg-gray-800 rounded-lg p-4 sm:p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-start space-x-3">
                    <div className={`p-2 rounded-lg ${getStatusColor(pedido.status).replace('text-', 'bg-').replace('-800', '-100')}`}>
                      <StatusIcon size={20} className={getStatusColor(pedido.status).split(' ')[1].replace('-800', '-600')} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base sm:text-lg font-semibold text-gray-800 dark:text-white">{pedido.clienteNome}</h3>
                      <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400 mt-1">{pedido.descricao}</p>
                      <div className="flex flex-wrap items-center gap-2 sm:gap-4 mt-2 text-xs sm:text-sm text-gray-500 dark:text-gray-400">
                        <span>Iniciado: {pedido.dataInicio ? new Date(pedido.dataInicio + 'T00:00:00').toLocaleDateString('pt-BR') : 'N/A'}</span>
                        {pedido.dataFinal && (
                          <span>Finalizado: {new Date(pedido.dataFinal + 'T00:00:00').toLocaleDateString('pt-BR')}</span>
                        )}
                        <span>Responsável: {pedido.responsavel}</span>
                        {pedido.executores.length > 0 && (
                          <span>Executores: {pedido.executores.join(', ')}</span>
                        )}
                      </div>
                      
                      {/* Status de Pagamento */}
                      <div className="flex items-center gap-2 mt-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          pedido.statusPagamento === 'pago' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {pedido.tipoSaldo === 'conta' ? 'Conta' : 'Dinheiro'}
                        </span>
                        {pedido.entradaCaixa && (
                          <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            No Caixa
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:items-end space-y-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-lg sm:text-xl font-bold text-green-600">
                      R$ {Number(pedido.valor || 0).toLocaleString('pt-BR')}
                    </span>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(pedido.status)}`}>
                    {getStatusText(pedido.status)}
                  </span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                {/* Botões de ação baseados no status */}
                {nextStatus && (
                  <button
                    onClick={() => updatePedidoStatus(pedido.id, nextStatus)}
                    className="inline-flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm"
                  >
                    <span>Avançar para: {getStatusText(nextStatus)}</span>
                  </button>
                )}
                
                {/* Botão de marcar como pago (apenas para pedidos finalizados e não pagos) */}
                {pedido.status === 'finalizado' && pedido.statusPagamento === 'pendente' && (
                  <button
                    onClick={() => markAsPaid(pedido.id)}
                    className="inline-flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm"
                  >
                    <CreditCard size={16} />
                    <span>Marcar como Pago</span>
                  </button>
                )}
                
                <button
                  onClick={() => handleEdit(pedido)}
                  className="inline-flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors text-sm"
                >
                  <Edit size={16} />
                  <span>Editar</span>
                </button>
                <button
                  onClick={() => handleDelete(pedido.id)}
                  className="inline-flex items-center space-x-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors text-sm"
                >
                  <Trash2 size={16} />
                  <span>Excluir</span>
                </button>
              </div>
            </div>
          );
        })}

        {filteredPedidos.length === 0 && (
          <div className="text-center py-12">
            <ShoppingCart size={48} className="mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-600 dark:text-gray-400">Nenhum pedido encontrado</h3>
            <p className="text-gray-500 dark:text-gray-500">Os pedidos aparecerão aqui quando orçamentos forem aceitos</p>
          </div>
        )}
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 sm:p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-lg sm:text-xl font-bold text-gray-800 dark:text-white mb-6">
              {editingPedido ? 'Editar Pedido' : 'Novo Pedido'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Cliente
                  </label>
                  <ClienteSearch
                    onClienteSelect={setSelectedCliente}
                    selectedCliente={selectedCliente}
                    placeholder="Buscar cliente por nome, CPF/CNPJ ou telefone..."
                  />
                  {!selectedCliente && (
                    <div className="mt-2">
                      <input
                        type="text"
                        value={formData.clienteNome}
                        onChange={(e) => setFormData(prev => ({ ...prev, clienteNome: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Ou digite o nome do cliente..."
                      />
                    </div>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Valor
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.valor || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, valor: parseFloat(e.target.value) || 0 }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Descrição
                </label>
                <textarea
                  rows={3}
                  value={formData.descricao}
                  onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Descrição do pedido..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value as any }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="aguardando_corte">Aguardando Corte</option>
                    <option value="em_corte">Em Corte</option>
                    <option value="pronto_instalacao">Pronto para Instalação</option>
                    <option value="em_instalacao">Em Instalação</option>
                    <option value="finalizado">Finalizado</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Responsável
                  </label>
                  <select
                    value={formData.responsavel}
                    onChange={(e) => setFormData(prev => ({ ...prev, responsavel: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Selecione um responsável</option>
                    {colaboradores.map(colaborador => (
                      <option key={colaborador.nome} value={colaborador.nome}>
                        {colaborador.nome}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Controle de Pagamento */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Tipo de Saldo
                  </label>
                  <select
                    value={formData.tipoSaldo}
                    onChange={(e) => setFormData(prev => ({ ...prev, tipoSaldo: e.target.value as any }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="conta">Conta Bancária</option>
                    <option value="dinheiro">Dinheiro</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Status do Pagamento
                  </label>
                  <select
                    value={formData.statusPagamento}
                    onChange={(e) => setFormData(prev => ({ ...prev, statusPagamento: e.target.value as any }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="pendente">Pendente</option>
                    <option value="pago">Pago</option>
                  </select>
                </div>
                
                {formData.statusPagamento === 'pago' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Data do Pagamento
                    </label>
                    <input
                      type="date"
                      value={formData.dataPagamento}
                      onChange={(e) => setFormData(prev => ({ ...prev, dataPagamento: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Executores
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-32 overflow-y-auto border border-gray-300 dark:border-gray-600 rounded-lg p-3">
                  {colaboradores.map(colaborador => (
                    <label key={colaborador.nome} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={formData.executores.includes(colaborador.nome)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setFormData(prev => ({
                              ...prev,
                              executores: [...prev.executores, colaborador.nome]
                            }));
                          } else {
                            setFormData(prev => ({
                              ...prev,
                              executores: prev.executores.filter(exec => exec !== colaborador.nome)
                            }));
                          }
                        }}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <span className="text-sm text-gray-700 dark:text-gray-300">{colaborador.nome}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Data de Início
                  </label>
                  <input
                    type="date"
                    value={formData.dataInicio}
                    onChange={(e) => setFormData(prev => ({ ...prev, dataInicio: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Data Final (opcional)
                  </label>
                  <input
                    type="date"
                    value={formData.dataFinal}
                    onChange={(e) => setFormData(prev => ({ ...prev, dataFinal: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 pt-4">
                <button
                  type="button"
                  onClick={handleCloseForm}
                  className="px-4 py-2 text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Salvando...' : (editingPedido ? 'Atualizar' : 'Salvar')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Confirmação de Pagamento */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">
              Confirmar Pagamento
            </h3>
            
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Como o pagamento foi recebido?
            </p>
            
            <div className="space-y-3 mb-6">
              <label className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                <input
                  type="radio"
                  name="paymentType"
                  value="conta"
                  checked={paymentType === 'conta'}
                  onChange={(e) => setPaymentType(e.target.value as any)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                />
                <div className="flex items-center space-x-2">
                  <Wallet className="text-blue-600" size={20} />
                  <div>
                    <p className="font-medium text-gray-800 dark:text-white">Conta Bancária</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">PIX, Transferência, Débito</p>
                  </div>
                </div>
              </label>

              <label className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                <input
                  type="radio"
                  name="paymentType"
                  value="dinheiro"
                  checked={paymentType === 'dinheiro'}
                  onChange={(e) => setPaymentType(e.target.value as any)}
                  className="h-4 w-4 text-green-600 focus:ring-green-500"
                />
                <div className="flex items-center space-x-2">
                  <Banknote className="text-green-600" size={20} />
                  <div>
                    <p className="font-medium text-gray-800 dark:text-white">Dinheiro</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Pagamento em espécie</p>
                  </div>
                </div>
              </label>

              <label className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                <input
                  type="radio"
                  name="paymentType"
                  value="credito"
                  checked={paymentType === 'credito'}
                  onChange={(e) => setPaymentType(e.target.value as any)}
                  className="h-4 w-4 text-purple-600 focus:ring-purple-500"
                />
                <div className="flex items-center space-x-2">
                  <CreditCard className="text-purple-600" size={20} />
                  <div>
                    <p className="font-medium text-gray-800 dark:text-white">Cartão de Crédito</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Recebimento no dia 1º do próximo mês</p>
                  </div>
                </div>
              </label>
            </div>
            
            <div className="flex space-x-3">
              <button
                onClick={() => {
                  setShowPaymentModal(null);
                  setPaymentType('conta');
                }}
                className="flex-1 px-4 py-2 text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={confirmPayment}
                className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                Confirmar Pagamento
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PedidosAprimorados;