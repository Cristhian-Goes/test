import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { DollarSign, TrendingUp, TrendingDown, Calendar, Filter, Plus, Wallet, CreditCard, Banknote, CreditCard as Edit, Trash2 } from 'lucide-react';

interface MovimentoFinanceiro {
  id: string;
  tipo: 'entrada' | 'saida';
  categoria: string;
  descricao: string;
  valor: number;
  data: string;
  status: 'pendente' | 'pago' | 'recebido';
  tipo_saldo: 'conta' | 'dinheiro';
  origem?: string;
  created_at: string;
}

interface SaldoConfig {
  saldo_conta: number;
  saldo_dinheiro: number;
}

export default function Financeiro() {
  const [movimentos, setMovimentos] = useState<MovimentoFinanceiro[]>([]);
  const [saldoConfig, setSaldoConfig] = useState<SaldoConfig>({ saldo_conta: 14670, saldo_dinheiro: 8734 });
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'entrada' | 'saida'>('all');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingMovimento, setEditingMovimento] = useState<MovimentoFinanceiro | null>(null);
  const [formData, setFormData] = useState({
    tipo: 'entrada' as 'entrada' | 'saida',
    categoria: '',
    descricao: '',
    valor: 0,
    data: new Date().toISOString().split('T')[0],
    status: 'recebido' as 'pendente' | 'pago' | 'recebido',
    tipo_saldo: 'conta' as 'conta' | 'dinheiro'
  });

  useEffect(() => {
    fetchMovimentos();
    fetchSaldoConfig();
  }, []);

  const fetchSaldoConfig = async () => {
    try {
      const { data, error } = await supabase
        .from('configuracao_saldos')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;
      if (data) {
        setSaldoConfig({
          saldo_conta: data.saldo_conta,
          saldo_dinheiro: data.saldo_dinheiro
        });
      } else {
        // Se não existe configuração, criar uma zerada
        setSaldoConfig({
          saldo_conta: 0,
          saldo_dinheiro: 0
        });
      }
    } catch (error) {
      console.error('Erro ao buscar configuração de saldos:', error);
      // Fallback para valores zerados
      setSaldoConfig({
        saldo_conta: 0,
        saldo_dinheiro: 0
      });
    }
  };

  const fetchMovimentos = async () => {
    try {
      // 1. Buscar movimentos manuais
      const { data: movimentosData, error: movimentosError } = await supabase
        .from('movimentos_financeiros')
        .select('*')
        .order('data', { ascending: false });

      if (movimentosError) throw movimentosError;

      // 2. Buscar despesas pagas
      const { data: despesasData, error: despesasError } = await supabase
        .from('despesas')
        .select('*')
        .eq('status', 'pago')
        .not('data_pagamento', 'is', null);

      if (despesasError) throw despesasError;

      // 3. Buscar pedidos pagos com entrada no caixa
      const { data: pedidosData, error: pedidosError } = await supabase
        .from('pedidos')
        .select('*')
        .eq('status_pagamento', 'pago')
        .eq('entrada_caixa', true)
        .not('data_pagamento', 'is', null);

      if (pedidosError) throw pedidosError;

      // 4. Buscar parcelas de boleto, cartão e vendas de crédito
      let parcelasBoletoData = [];
      let parcelasCartaoData = [];
      let vendasCreditoData = [];

      try {
        const { data: boleto } = await supabase
          .from('parcelas_boleto')
          .select('*')
          .eq('status', 'recebida')
          .not('data_recebimento', 'is', null);
        parcelasBoletoData = boleto || [];
      } catch (error) {
        console.warn('Erro ao buscar parcelas boleto:', error);
      }

      try {
        const { data: cartao } = await supabase
          .from('parcelas_cartao')
          .select('*')
          .eq('status', 'recebida')
          .not('data_recebimento', 'is', null);
        parcelasCartaoData = cartao || [];
      } catch (error) {
        console.warn('Erro ao buscar parcelas cartão:', error);
      }

      try {
        const { data: credito } = await supabase
          .from('vendas_cartao_credito')
          .select('*')
          .eq('status', 'recebida')
          .not('data_recebimento', 'is', null);
        vendasCreditoData = credito || [];
      } catch (error) {
        console.warn('Erro ao buscar vendas crédito:', error);
      }

      // 5. Combinar todos os movimentos (LÓGICA IDÊNTICA AO DASHBOARD)
      const allMovimentos = [
        // Movimentos manuais
        ...(movimentosData || []).map(m => ({
          id: m.id,
          tipo: m.tipo,
          categoria: m.categoria,
          descricao: m.descricao,
          valor: parseFloat(m.valor) || 0,
          data: m.data,
          status: m.status,
          tipo_saldo: m.tipo_saldo || 'conta',
          origem: 'manual',
          created_at: m.created_at
        })),
        
        // Despesas pagas (excluir as que já têm movimento manual)
        ...(despesasData || [])
          .filter(d => {
            const hasManualMovement = (movimentosData || []).some(m => 
              m.referencia_id === d.id && m.referencia_tipo === 'despesa'
            );
            return !hasManualMovement;
          })
          .map(d => ({
            id: `despesa-${d.id}`,
            tipo: 'saida' as const,
            categoria: d.categoria,
            descricao: d.descricao,
            valor: parseFloat(d.valor) || 0,
            data: d.data_pagamento,
            status: 'pago' as const,
            tipo_saldo: d.tipo_saldo || 'conta',
            origem: 'despesa',
            created_at: d.created_at
          })),
        
        // Pedidos pagos (vendas à vista com entrada no caixa)
        ...(pedidosData || []).map(p => ({
          id: `pedido-${p.id}`,
          tipo: 'entrada' as const,
          categoria: 'Vendas - À Vista',
          descricao: `Venda - ${p.cliente_nome}`,
          valor: parseFloat(p.valor) || 0,
          data: p.data_pagamento,
          status: 'recebido' as const,
          tipo_saldo: p.tipo_saldo || 'conta',
          origem: 'pedido',
          created_at: p.created_at
        })),
        
        // Parcelas de boleto recebidas
        ...parcelasBoletoData.map(p => ({
          id: `boleto-${p.id}`,
          tipo: 'entrada' as const,
          categoria: 'Vendas - Boleto',
          descricao: `Boleto ${p.numero_parcela}/${p.total_parcelas}`,
          valor: parseFloat(p.valor) || 0,
          data: p.data_recebimento,
          status: 'recebido' as const,
          tipo_saldo: 'conta',
          origem: 'boleto',
          created_at: p.created_at
        })),
        
        // Parcelas de cartão recebidas
        ...parcelasCartaoData.map(p => ({
          id: `cartao-${p.id}`,
          tipo: 'entrada' as const,
          categoria: 'Vendas - Crédito',
          descricao: `Cartão ${p.numero_parcela}/${p.total_parcelas}`,
          valor: parseFloat(p.valor) || 0,
          data: p.data_recebimento,
          status: 'recebido' as const,
          tipo_saldo: 'conta',
          origem: 'cartao',
          created_at: p.created_at
        })),

        // Vendas no cartão de crédito recebidas
        ...vendasCreditoData.map(v => ({
          id: `venda-credito-${v.id}`,
          tipo: 'entrada' as const,
          categoria: 'Vendas - Crédito',
          descricao: `Venda Cartão de Crédito`,
          valor: parseFloat(v.valor) || 0,
          data: v.data_recebimento,
          status: 'recebido' as const,
          tipo_saldo: 'conta',
          origem: 'venda-credito',
          created_at: v.created_at
        }))
      ];

      setMovimentos(allMovimentos);
    } catch (error) {
      console.error('Erro ao buscar movimentos:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const movimentoData = {
        tipo: formData.tipo,
        categoria: formData.categoria,
        descricao: formData.descricao,
        valor: formData.valor,
        data: formData.data,
        status: formData.status,
        tipo_saldo: formData.tipo_saldo,
        recorrente: false
      };

      if (editingMovimento && editingMovimento.origem === 'manual') {
        const { error } = await supabase
          .from('movimentos_financeiros')
          .update(movimentoData)
          .eq('id', editingMovimento.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('movimentos_financeiros')
          .insert([movimentoData]);

        if (error) throw error;
      }

      await fetchMovimentos();
      handleCloseForm();
    } catch (error) {
      console.error('Erro ao salvar movimento:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (movimento: MovimentoFinanceiro) => {
    if (movimento.origem !== 'manual') {
      alert('Apenas movimentos manuais podem ser editados');
      return;
    }

    setEditingMovimento(movimento);
    setFormData({
      tipo: movimento.tipo,
      categoria: movimento.categoria,
      descricao: movimento.descricao,
      valor: movimento.valor,
      data: movimento.data,
      status: movimento.status,
      tipo_saldo: movimento.tipo_saldo
    });
    setShowAddForm(true);
  };

  const handleDelete = async (movimento: MovimentoFinanceiro) => {
    if (movimento.origem !== 'manual') {
      alert('Apenas movimentos manuais podem ser excluídos');
      return;
    }

    if (!confirm('Tem certeza que deseja excluir este movimento?')) return;

    try {
      const { error } = await supabase
        .from('movimentos_financeiros')
        .delete()
        .eq('id', movimento.id);

      if (error) throw error;
      await fetchMovimentos();
    } catch (error) {
      console.error('Erro ao excluir movimento:', error);
    }
  };

  const handleCloseForm = () => {
    setShowAddForm(false);
    setEditingMovimento(null);
    setFormData({
      tipo: 'entrada',
      categoria: '',
      descricao: '',
      valor: 0,
      data: new Date().toISOString().split('T')[0],
      status: 'recebido',
      tipo_saldo: 'conta'
    });
  };

  const filteredMovimentos = movimentos.filter(movimento => 
    filter === 'all' || movimento.tipo === filter
  );

  // Calcular totais separados por tipo de saldo
  const totalEntradasConta = movimentos
    .filter(m => 
      m.tipo === 'entrada' && 
      m.status === 'recebido' && 
      m.tipo_saldo === 'conta' &&
      !isNaN(m.valor) &&
      m.valor > 0
    )
    .reduce((sum, m) => sum + m.valor, 0);

  const totalEntradasDinheiro = movimentos
    .filter(m => 
      m.tipo === 'entrada' && 
      m.status === 'recebido' && 
      m.tipo_saldo === 'dinheiro' &&
      !isNaN(m.valor) &&
      m.valor > 0
    )
    .reduce((sum, m) => sum + m.valor, 0);

  const totalSaidasConta = movimentos
    .filter(m => 
      m.tipo === 'saida' && 
      m.status === 'pago' && 
      m.tipo_saldo === 'conta' &&
      !isNaN(m.valor) &&
      m.valor > 0
    )
    .reduce((sum, m) => sum + m.valor, 0);

  const totalSaidasDinheiro = movimentos
    .filter(m => 
      m.tipo === 'saida' && 
      m.status === 'pago' && 
      m.tipo_saldo === 'dinheiro' &&
      !isNaN(m.valor) &&
      m.valor > 0
    )
    .reduce((sum, m) => sum + m.valor, 0);

  const saldoAtualConta = (saldoConfig?.saldo_conta || 0) + totalEntradasConta - totalSaidasConta;
  const saldoAtualDinheiro = (saldoConfig?.saldo_dinheiro || 0) + totalEntradasDinheiro - totalSaidasDinheiro;
  const saldoTotal = saldoAtualConta + saldoAtualDinheiro;

  const totalEntradas = totalEntradasConta + totalEntradasDinheiro;
  const totalSaidas = totalSaidasConta + totalSaidasDinheiro;

  const getOrigemBadge = (origem?: string) => {
    const badges = {
      manual: { text: 'Manual', color: 'bg-gray-100 text-gray-800' },
      despesa: { text: 'Despesa', color: 'bg-orange-100 text-orange-800' },
      pedido: { text: 'Venda', color: 'bg-green-100 text-green-800' },
      boleto: { text: 'Boleto', color: 'bg-blue-100 text-blue-800' },
      cartao: { text: 'Cartão', color: 'bg-purple-100 text-purple-800' }
    };
    
    const badge = badges[origem as keyof typeof badges] || badges.manual;
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${badge.color}`}>
        {badge.text}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Financeiro</h1>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Nova Movimentação
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-lg shadow-md border border-blue-200 dark:border-blue-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-800 dark:text-blue-300">Saldo em Conta</p>
              <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                R$ {saldoAtualConta.toLocaleString('pt-BR')}
              </p>
              <p className="text-xs text-blue-600 dark:text-blue-400">Banco/PIX/Cartão</p>
            </div>
            <Wallet className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-green-50 dark:bg-green-900/20 p-6 rounded-lg shadow-md border border-green-200 dark:border-green-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-800 dark:text-green-300">Saldo em Dinheiro</p>
              <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                R$ {saldoAtualDinheiro.toLocaleString('pt-BR')}
              </p>
              <p className="text-xs text-green-600 dark:text-green-400">Caixa físico</p>
            </div>
            <Banknote className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-emerald-50 dark:bg-emerald-900/20 p-6 rounded-lg shadow-md border border-emerald-200 dark:border-emerald-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-emerald-800 dark:text-emerald-300">Total Entradas</p>
              <p className="text-2xl font-bold text-emerald-900 dark:text-emerald-100">
                R$ {totalEntradas.toLocaleString('pt-BR')}
              </p>
              <p className="text-xs text-emerald-600 dark:text-emerald-400">Valores recebidos</p>
            </div>
            <TrendingUp className="w-8 h-8 text-emerald-500" />
          </div>
        </div>

        <div className={`p-6 rounded-lg shadow-md border ${
          saldoTotal >= 0 
            ? 'bg-cyan-50 dark:bg-cyan-900/20 border-cyan-200 dark:border-cyan-700' 
            : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-700'
        }`}>
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-sm font-medium ${
                saldoTotal >= 0 ? 'text-cyan-800 dark:text-cyan-300' : 'text-red-800 dark:text-red-300'
              }`}>
                Saldo Total
              </p>
              <p className={`text-2xl font-bold ${
                saldoTotal >= 0 ? 'text-cyan-900 dark:text-cyan-100' : 'text-red-900 dark:text-red-100'
              }`}>
                R$ {saldoTotal.toLocaleString('pt-BR')}
              </p>
              <p className={`text-xs ${
                saldoTotal >= 0 ? 'text-cyan-600 dark:text-cyan-400' : 'text-red-600 dark:text-red-400'
              }`}>
                Conta + Dinheiro
              </p>
            </div>
            <DollarSign className={`w-8 h-8 ${
              saldoTotal >= 0 ? 'text-cyan-500' : 'text-red-500'
            }`} />
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md">
        <div className="flex items-center gap-4">
          <Filter className="w-5 h-5 text-gray-500" />
          <div className="flex gap-2">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                filter === 'all' 
                  ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600'
              }`}
            >
              Todas
            </button>
            <button
              onClick={() => setFilter('entrada')}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                filter === 'entrada' 
                  ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600'
              }`}
            >
              Entradas
            </button>
            <button
              onClick={() => setFilter('saida')}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                filter === 'saida' 
                  ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600'
              }`}
            >
              Saídas
            </button>
          </div>
        </div>
      </div>

      {/* Transactions List */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Movimentações Financeiras</h2>
        </div>
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          {filteredMovimentos.length === 0 ? (
            <div className="px-6 py-8 text-center text-gray-500 dark:text-gray-400">
              Nenhuma movimentação encontrada
            </div>
          ) : (
            filteredMovimentos.map((movimento) => (
              <div key={movimento.id} className="px-6 py-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${
                      movimento.tipo === 'entrada' ? 'bg-green-500' : 'bg-red-500'
                    }`} />
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-gray-900 dark:text-white">{movimento.descricao}</p>
                        {getOrigemBadge(movimento.origem)}
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          movimento.tipo_saldo === 'conta' 
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' 
                            : 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
                        }`}>
                          {movimento.tipo_saldo === 'conta' ? 'Conta' : 'Dinheiro'}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{movimento.categoria}</p>
                    </div>
                  </div>
                  <div className="text-right flex items-center gap-3">
                    <div>
                      <p className={`font-semibold ${
                        movimento.tipo === 'entrada' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                      }`}>
                        {movimento.tipo === 'entrada' ? '+' : '-'}R$ {movimento.valor.toLocaleString('pt-BR')}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(movimento.data + 'T00:00:00').toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                    {movimento.origem === 'manual' && (
                      <div className="flex gap-1">
                        <button
                          onClick={() => handleEdit(movimento)}
                          className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                          title="Editar"
                        >
                          <Edit size={16} />
                        </button>
                        <button
                          onClick={() => handleDelete(movimento)}
                          className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                          title="Excluir"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Add/Edit Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {editingMovimento ? 'Editar Movimentação' : 'Nova Movimentação'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Tipo
                  </label>
                  <select
                    value={formData.tipo}
                    onChange={(e) => setFormData({ ...formData, tipo: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  >
                    <option value="entrada">Entrada</option>
                    <option value="saida">Saída</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Tipo de Saldo
                  </label>
                  <select
                    value={formData.tipo_saldo}
                    onChange={(e) => setFormData({ ...formData, tipo_saldo: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  >
                    <option value="conta">Conta Bancária</option>
                    <option value="dinheiro">Dinheiro</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Categoria
                </label>
                <input
                  type="text"
                  required
                  value={formData.categoria}
                  onChange={(e) => setFormData({ ...formData, categoria: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  placeholder="Ex: Vendas, Fornecedores, etc."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Descrição
                </label>
                <input
                  type="text"
                  required
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  placeholder="Descrição da movimentação"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Valor
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={formData.valor || ''}
                    onChange={(e) => setFormData({ ...formData, valor: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                    placeholder="0.00"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Data
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.data}
                    onChange={(e) => setFormData({ ...formData, data: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Status
                </label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                >
                  <option value="pendente">Pendente</option>
                  <option value={formData.tipo === 'entrada' ? 'recebido' : 'pago'}>
                    {formData.tipo === 'entrada' ? 'Recebido' : 'Pago'}
                  </option>
                </select>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={handleCloseForm}
                  className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors disabled:opacity-50"
                >
                  {loading ? 'Salvando...' : (editingMovimento ? 'Atualizar' : 'Criar')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}