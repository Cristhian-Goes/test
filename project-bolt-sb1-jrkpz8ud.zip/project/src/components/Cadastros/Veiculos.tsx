import React, { useState, useEffect } from 'react';
import { Plus, Search, Car, Edit, Trash2, AlertTriangle, Wrench, CheckCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface Veiculo {
  id: string;
  placa: string;
  modelo: string;
  ano: number;
  motoristaResponsavel: string;
  status: 'ativo' | 'manutencao' | 'inativo';
  despesasAssociadas: number;
}

const Veiculos: React.FC = () => {
  const [veiculos, setVeiculos] = useState<Veiculo[]>([]);
  const [colaboradores, setColaboradores] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingVeiculo, setEditingVeiculo] = useState<Veiculo | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('todos');
  const [formData, setFormData] = useState<Omit<Veiculo, 'id'>>({
    placa: '',
    modelo: '',
    ano: new Date().getFullYear(),
    motoristaResponsavel: '',
    status: 'ativo',
    despesasAssociadas: 0
  });

  useEffect(() => {
    fetchVeiculos();
    fetchColaboradores();
  }, []);

  const fetchVeiculos = async () => {
    try {
      const { data, error } = await supabase
        .from('veiculos')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const veiculosFormatted = data?.map(item => ({
        id: item.id,
        placa: item.placa,
        modelo: item.modelo,
        ano: item.ano,
        motoristaResponsavel: item.motorista_responsavel,
        status: item.status,
        despesasAssociadas: item.despesas_associadas || 0
      })) || [];

      setVeiculos(veiculosFormatted);
    } catch (error) {
      console.error('Erro ao buscar veículos:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchColaboradores = async () => {
    try {
      const { data, error } = await supabase
        .from('colaboradores')
        .select('nome')
        .eq('status', 'ativo')
        .order('nome');

      if (error) throw error;
      setColaboradores(data || []);
    } catch (error) {
      console.error('Erro ao buscar colaboradores:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const veiculoData = {
        placa: formData.placa,
        modelo: formData.modelo,
        ano: formData.ano,
        motorista_responsavel: formData.motoristaResponsavel,
        status: formData.status,
        despesas_associadas: formData.despesasAssociadas
      };

      if (editingVeiculo) {
        const { error } = await supabase
          .from('veiculos')
          .update(veiculoData)
          .eq('id', editingVeiculo.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('veiculos')
          .insert([veiculoData]);

        if (error) throw error;
      }

      await fetchVeiculos();
      handleCloseForm();
    } catch (error) {
      console.error('Erro ao salvar veículo:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (veiculo: Veiculo) => {
    setEditingVeiculo(veiculo);
    setFormData({
      placa: veiculo.placa,
      modelo: veiculo.modelo,
      ano: veiculo.ano,
      motoristaResponsavel: veiculo.motoristaResponsavel,
      status: veiculo.status,
      despesasAssociadas: veiculo.despesasAssociadas
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir este veículo?')) {
      try {
        const { error } = await supabase
          .from('veiculos')
          .delete()
          .eq('id', id);

        if (error) throw error;
        await fetchVeiculos();
      } catch (error) {
        console.error('Erro ao excluir veículo:', error);
      }
    }
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingVeiculo(null);
    setFormData({
      placa: '',
      modelo: '',
      ano: new Date().getFullYear(),
      motoristaResponsavel: '',
      status: 'ativo',
      despesasAssociadas: 0
    });
  };

  const filteredVeiculos = veiculos.filter(veiculo => {
    const matchesSearch = veiculo.modelo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         veiculo.placa.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         veiculo.motoristaResponsavel.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'todos' || veiculo.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    const colors = {
      'ativo': 'bg-green-100 text-green-800',
      'manutencao': 'bg-yellow-100 text-yellow-800',
      'inativo': 'bg-red-100 text-red-800'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const getStatusText = (status: string) => {
    const texts = {
      'ativo': 'Ativo',
      'manutencao': 'Manutenção',
      'inativo': 'Inativo'
    };
    return texts[status as keyof typeof texts] || status;
  };

  const getStatusIcon = (status: string) => {
    const icons = {
      'ativo': CheckCircle,
      'manutencao': Wrench,
      'inativo': AlertTriangle
    };
    return icons[status as keyof typeof icons] || AlertTriangle;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-4 sm:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Veículos</h1>
          <p className="text-gray-600">Gerencie a frota de veículos da empresa</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="inline-flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus size={20} />
          <span>Novo Veículo</span>
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Buscar por modelo, placa ou motorista..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="todos">Todos os Status</option>
          <option value="ativo">Ativo</option>
          <option value="manutencao">Manutenção</option>
          <option value="inativo">Inativo</option>
        </select>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-800">Ativos</p>
              <p className="text-2xl font-bold text-green-900">
                {veiculos.filter(v => v.status === 'ativo').length}
              </p>
            </div>
            <CheckCircle className="text-green-600" size={24} />
          </div>
        </div>
        <div className="bg-yellow-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-yellow-800">Manutenção</p>
              <p className="text-2xl font-bold text-yellow-900">
                {veiculos.filter(v => v.status === 'manutencao').length}
              </p>
            </div>
            <Wrench className="text-yellow-600" size={24} />
          </div>
        </div>
        <div className="bg-red-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-red-800">Inativos</p>
              <p className="text-2xl font-bold text-red-900">
                {veiculos.filter(v => v.status === 'inativo').length}
              </p>
            </div>
            <AlertTriangle className="text-red-600" size={24} />
          </div>
        </div>
      </div>

      {/* Vehicles List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredVeiculos.map((veiculo) => {
          const StatusIcon = getStatusIcon(veiculo.status);
          
          return (
            <div key={veiculo.id} className="bg-white rounded-lg p-6 shadow-sm border hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                    <Car size={20} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">{veiculo.modelo}</h3>
                    <p className="text-sm text-gray-600">{veiculo.placa} • {veiculo.ano}</p>
                  </div>
                </div>
                <div className="flex space-x-1">
                  <button 
                    onClick={() => handleEdit(veiculo)}
                    className="p-1 text-gray-400 hover:text-blue-600"
                    title="Editar"
                  >
                    <Edit size={16} />
                  </button>
                  <button 
                    onClick={() => handleDelete(veiculo.id)}
                    className="p-1 text-gray-400 hover:text-red-600"
                    title="Excluir"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Motorista:</span>
                  <span className="text-sm font-medium text-gray-800">{veiculo.motoristaResponsavel}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Status:</span>
                  <div className="flex items-center space-x-1">
                    <StatusIcon size={14} className={getStatusColor(veiculo.status).split(' ')[1].replace('-800', '-600')} />
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(veiculo.status)}`}>
                      {getStatusText(veiculo.status)}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Despesas Associadas:</span>
                  <span className="font-medium text-gray-800">
                    R$ {veiculo.despesasAssociadas.toLocaleString('pt-BR')}
                  </span>
                </div>
              </div>
            </div>
          );
        })}

        {filteredVeiculos.length === 0 && (
          <div className="col-span-full text-center py-12">
            <Car size={48} className="mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-600">Nenhum veículo encontrado</h3>
            <p className="text-gray-500">Comece cadastrando um novo veículo</p>
          </div>
        )}
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-gray-800 mb-6">
              {editingVeiculo ? 'Editar Veículo' : 'Novo Veículo'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Placa
                  </label>
                  <input
                    type="text"
                    value={formData.placa}
                    onChange={(e) => setFormData(prev => ({ ...prev, placa: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="ABC-1234"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Modelo
                  </label>
                  <input
                    type="text"
                    value={formData.modelo}
                    onChange={(e) => setFormData(prev => ({ ...prev, modelo: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Fiat Strada"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Ano
                  </label>
                  <input
                    type="number"
                    min="1900"
                    max={new Date().getFullYear() + 1}
                    value={formData.ano || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, ano: parseInt(e.target.value) || new Date().getFullYear() }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="2024"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Motorista Responsável
                  </label>
                  <select
                    value={formData.motoristaResponsavel}
                    onChange={(e) => setFormData(prev => ({ ...prev, motoristaResponsavel: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Selecione um colaborador</option>
                    {colaboradores.map(colaborador => (
                      <option key={colaborador.nome} value={colaborador.nome}>{colaborador.nome}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value as 'ativo' | 'manutencao' | 'inativo' }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="ativo">Ativo</option>
                    <option value="manutencao">Manutenção</option>
                    <option value="inativo">Inativo</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Despesas Associadas
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.despesasAssociadas || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, despesasAssociadas: parseFloat(e.target.value) || 0 }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Digite o valor"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={handleCloseForm}
                  className="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Salvando...' : (editingVeiculo ? 'Atualizar' : 'Salvar')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Veiculos;