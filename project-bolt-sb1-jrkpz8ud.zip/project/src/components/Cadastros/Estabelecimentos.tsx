import React, { useState, useEffect } from 'react';
import { Plus, Search, Building, Edit, Trash2, MapPin, User, Phone } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface Estabelecimento {
  id: string;
  nome: string;
  endereco: {
    rua: string;
    numero: string;
    bairro: string;
    cidade: string;
    cep: string;
    estado: string;
  };
  cnpj: string;
  responsavel: string;
  telefone: string;
  email: string;
  status: 'ativo' | 'inativo';
}

const Estabelecimentos: React.FC = () => {
  const [estabelecimentos, setEstabelecimentos] = useState<Estabelecimento[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingEstabelecimento, setEditingEstabelecimento] = useState<Estabelecimento | null>(null);
  
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('todos');
  const [formData, setFormData] = useState<Omit<Estabelecimento, 'id'>>({
    nome: '',
    endereco: {
      rua: '',
      numero: '',
      bairro: '',
      cidade: '',
      cep: '',
      estado: ''
    },
    cnpj: '',
    responsavel: '',
    telefone: '',
    email: '',
    status: 'ativo'
  });

  useEffect(() => {
    fetchEstabelecimentos();
  }, []);

  const fetchEstabelecimentos = async () => {
    try {
      const { data, error } = await supabase
        .from('estabelecimentos')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const estabelecimentosFormatted = data?.map(item => ({
        id: item.id,
        nome: item.nome,
        endereco: item.endereco || {
          rua: '',
          numero: '',
          bairro: '',
          cidade: '',
          estado: '',
          cep: ''
        },
        cnpj: item.cnpj,
        responsavel: item.responsavel,
        telefone: item.telefone,
        email: item.email || '',
        status: item.status
      })) || [];

      setEstabelecimentos(estabelecimentosFormatted);
    } catch (error) {
      console.error('Erro ao buscar estabelecimentos:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredEstabelecimentos = estabelecimentos.filter(estabelecimento => {
    const matchesSearch = estabelecimento.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         estabelecimento.cnpj.includes(searchTerm) ||
                         estabelecimento.responsavel.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'todos' || estabelecimento.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const estabelecimentoData = {
        nome: formData.nome,
        endereco: formData.endereco,
        cnpj: formData.cnpj,
        responsavel: formData.responsavel,
        telefone: formData.telefone,
        email: formData.email,
        status: formData.status
      };

      if (editingEstabelecimento) {
        const { error } = await supabase
          .from('estabelecimentos')
          .update(estabelecimentoData)
          .eq('id', editingEstabelecimento.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('estabelecimentos')
          .insert([estabelecimentoData]);

        if (error) throw error;
      }

      await fetchEstabelecimentos();
      handleCloseForm();
    } catch (error) {
      console.error('Erro ao salvar estabelecimento:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (estabelecimento: Estabelecimento) => {
    setEditingEstabelecimento(estabelecimento);
    setFormData({
      nome: estabelecimento.nome,
      endereco: estabelecimento.endereco,
      cnpj: estabelecimento.cnpj,
      responsavel: estabelecimento.responsavel,
      telefone: estabelecimento.telefone,
      email: estabelecimento.email,
      status: estabelecimento.status
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir este estabelecimento?')) {
      try {
        const { error } = await supabase
          .from('estabelecimentos')
          .delete()
          .eq('id', id);

        if (error) throw error;
        await fetchEstabelecimentos();
      } catch (error) {
        console.error('Erro ao excluir estabelecimento:', error);
      }
    }
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingEstabelecimento(null);
    setFormData({
      nome: '',
      endereco: {
        rua: '',
        numero: '',
        bairro: '',
        cidade: '',
        cep: '',
        estado: ''
      },
      cnpj: '',
      responsavel: '',
      telefone: '',
      email: '',
      status: 'ativo'
    });
  };

  const handleInputChange = (field: string, value: string) => {
    if (field.startsWith('endereco.')) {
      const enderecoField = field.split('.')[1];
      setFormData(prev => ({
        ...prev,
        endereco: {
          ...prev.endereco,
          [enderecoField]: value
        }
      }));
    } else {
      setFormData(prev => ({ ...prev, [field]: value }));
    }
  };

  const getStatusColor = (status: string) => {
    return status === 'ativo' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
  };

  const getStatusText = (status: string) => {
    return status === 'ativo' ? 'Ativo' : 'Inativo';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Estabelecimentos</h1>
          <p className="text-gray-600">Gerencie filiais e pontos de atendimento</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="inline-flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus size={20} />
          <span>Novo Estabelecimento</span>
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Buscar por nome, CNPJ ou responsável..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="todos">Todos os Status</option>
          <option value="ativo">Ativo</option>
          <option value="inativo">Inativo</option>
        </select>
      </div>

      {/* Establishments List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredEstabelecimentos.map((estabelecimento) => (
          <div key={estabelecimento.id} className="bg-white rounded-lg p-6 shadow-sm border hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center">
                  <Building size={20} className="text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">{estabelecimento.nome}</h3>
                  <p className="text-sm text-gray-600">{estabelecimento.cnpj}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(estabelecimento.status)}`}>
                  {getStatusText(estabelecimento.status)}
                </span>
                <div className="flex space-x-1">
                  <button 
                    onClick={() => handleEdit(estabelecimento)}
                    className="p-1 text-gray-400 hover:text-blue-600"
                    title="Editar"
                  >
                    <Edit size={16} />
                  </button>
                  <button 
                    onClick={() => handleDelete(estabelecimento.id)}
                    className="p-1 text-gray-400 hover:text-red-600"
                    title="Excluir"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-start space-x-2 text-sm text-gray-600">
                <MapPin size={14} className="mt-0.5" />
                <span>
                  {estabelecimento.endereco.rua}, {estabelecimento.endereco.numero} - {estabelecimento.endereco.bairro}<br/>
                  {estabelecimento.endereco.cidade}, {estabelecimento.endereco.estado} - {estabelecimento.endereco.cep}
                </span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <User size={14} />
                <span>{estabelecimento.responsavel}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Phone size={14} />
                <span>{estabelecimento.telefone}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-gray-800 mb-6">
              {editingEstabelecimento ? 'Editar Estabelecimento' : 'Novo Estabelecimento'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nome do Estabelecimento
                  </label>
                  <input
                    type="text"
                    value={formData.nome}
                    onChange={(e) => handleInputChange('nome', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Matriz - Centro"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    CNPJ
                  </label>
                  <input
                    type="text"
                    value={formData.cnpj}
                    onChange={(e) => handleInputChange('cnpj', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="12.345.678/0001-90"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Rua
                  </label>
                  <input
                    type="text"
                    value={formData.endereco.rua}
                    onChange={(e) => handleInputChange('endereco.rua', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Número
                  </label>
                  <input
                    type="text"
                    value={formData.endereco.numero}
                    onChange={(e) => handleInputChange('endereco.numero', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Bairro
                  </label>
                  <input
                    type="text"
                    value={formData.endereco.bairro}
                    onChange={(e) => handleInputChange('endereco.bairro', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Cidade
                  </label>
                  <input
                    type="text"
                    value={formData.endereco.cidade}
                    onChange={(e) => handleInputChange('endereco.cidade', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Estado
                  </label>
                  <input
                    type="text"
                    value={formData.endereco.estado}
                    onChange={(e) => handleInputChange('endereco.estado', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    CEP
                  </label>
                  <input
                    type="text"
                    value={formData.endereco.cep}
                    onChange={(e) => handleInputChange('endereco.cep', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="00000-000"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Responsável
                  </label>
                  <input
                    type="text"
                    value={formData.responsavel}
                    onChange={(e) => handleInputChange('responsavel', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Nome do responsável"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => handleInputChange('status', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="ativo">Ativo</option>
                    <option value="inativo">Inativo</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Telefone
                  </label>
                  <input
                    type="tel"
                    value={formData.telefone}
                    onChange={(e) => handleInputChange('telefone', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="(11) 99999-9999"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="contato@empresa.com"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={handleCloseForm}
                  className="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Salvando...' : (editingEstabelecimento ? 'Atualizar' : 'Salvar')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Estabelecimentos;