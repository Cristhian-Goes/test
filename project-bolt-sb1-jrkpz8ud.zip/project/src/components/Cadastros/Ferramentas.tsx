import React, { useState, useEffect } from 'react';
import { Plus, Search, Wrench, Edit, Trash2, Calendar, AlertTriangle } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface Ferramenta {
  id: string;
  nome: string;
  descricao: string;
  quantidade: number;
  dataCompra: string;
  proximaManutencao: string;
  despesasAssociadas: number;
}

const Ferramentas: React.FC = () => {
  const [ferramentas, setFerramentas] = useState<Ferramenta[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingFerramenta, setEditingFerramenta] = useState<Ferramenta | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState<Omit<Ferramenta, 'id'>>({
    nome: '',
    descricao: '',
    quantidade: 1,
    dataCompra: '',
    proximaManutencao: '',
    despesasAssociadas: 0
  });

  useEffect(() => {
    fetchFerramentas();
  }, []);

  const fetchFerramentas = async () => {
    try {
      const { data, error } = await supabase
        .from('ferramentas')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const ferramentasFormatted = data?.map(item => ({
        id: item.id,
        nome: item.nome,
        descricao: item.descricao,
        quantidade: item.quantidade,
        dataCompra: item.data_compra,
        proximaManutencao: item.proxima_manutencao,
        despesasAssociadas: item.despesas_associadas || 0
      })) || [];

      setFerramentas(ferramentasFormatted);
    } catch (error) {
      console.error('Erro ao buscar ferramentas:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const ferramentaData = {
        nome: formData.nome,
        descricao: formData.descricao,
        quantidade: formData.quantidade,
        data_compra: formData.dataCompra || null,
        proxima_manutencao: formData.proximaManutencao || null,
        despesas_associadas: formData.despesasAssociadas
      };

      if (editingFerramenta) {
        const { error } = await supabase
          .from('ferramentas')
          .update(ferramentaData)
          .eq('id', editingFerramenta.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('ferramentas')
          .insert([ferramentaData]);

        if (error) throw error;
      }

      await fetchFerramentas();
      handleCloseForm();
    } catch (error) {
      console.error('Erro ao salvar ferramenta:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (ferramenta: Ferramenta) => {
    setEditingFerramenta(ferramenta);
    setFormData({
      nome: ferramenta.nome,
      descricao: ferramenta.descricao,
      quantidade: ferramenta.quantidade,
      dataCompra: ferramenta.dataCompra,
      proximaManutencao: ferramenta.proximaManutencao,
      despesasAssociadas: ferramenta.despesasAssociadas
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir esta ferramenta?')) {
      try {
        const { error } = await supabase
          .from('ferramentas')
          .delete()
          .eq('id', id);

        if (error) throw error;
        await fetchFerramentas();
      } catch (error) {
        console.error('Erro ao excluir ferramenta:', error);
      }
    }
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingFerramenta(null);
    setFormData({
      nome: '',
      descricao: '',
      quantidade: 1,
      dataCompra: '',
      proximaManutencao: '',
      despesasAssociadas: 0
    });
  };

  const filteredFerramentas = ferramentas.filter(ferramenta =>
    ferramenta.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ferramenta.descricao.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const isMaintenanceDue = (proximaManutencao: string) => {
    const today = new Date();
    const maintenanceDate = new Date(proximaManutencao);
    const diffTime = maintenanceDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 30;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-4 sm:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Ferramentas</h1>
          <p className="text-gray-600">Controle de ferramentas e equipamentos</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="inline-flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus size={20} />
          <span>Nova Ferramenta</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          placeholder="Buscar por nome ou descrição..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      {/* Alert for maintenance */}
      {ferramentas.filter(f => isMaintenanceDue(f.proximaManutencao)).length > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="text-yellow-600" size={20} />
            <span className="font-medium text-yellow-800">
              {ferramentas.filter(f => isMaintenanceDue(f.proximaManutencao)).length} ferramenta(s) 
              próxima(s) da manutenção nos próximos 30 dias
            </span>
          </div>
        </div>
      )}

      {/* Tools List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredFerramentas.map((ferramenta) => (
          <div key={ferramenta.id} className="bg-white rounded-lg p-6 shadow-sm border hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center">
                  <Wrench size={20} className="text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">{ferramenta.nome}</h3>
                  <p className="text-sm text-gray-600">Qtd: {ferramenta.quantidade}</p>
                </div>
              </div>
              <div className="flex space-x-1">
                <button 
                  onClick={() => handleEdit(ferramenta)}
                  className="p-1 text-gray-400 hover:text-blue-600"
                  title="Editar"
                >
                  <Edit size={16} />
                </button>
                <button 
                  onClick={() => handleDelete(ferramenta.id)}
                  className="p-1 text-gray-400 hover:text-red-600"
                  title="Excluir"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>

            <p className="text-gray-600 text-sm mb-4">{ferramenta.descricao}</p>

            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Calendar size={14} />
                <span>Compra: {new Date(ferramenta.dataCompra).toLocaleDateString('pt-BR')}</span>
              </div>
              <div className={`flex items-center space-x-2 text-sm ${
                isMaintenanceDue(ferramenta.proximaManutencao) ? 'text-yellow-600' : 'text-gray-600'
              }`}>
                <Calendar size={14} />
                <span>Manutenção: {new Date(ferramenta.proximaManutencao).toLocaleDateString('pt-BR')}</span>
                {isMaintenanceDue(ferramenta.proximaManutencao) && (
                  <AlertTriangle size={14} className="text-yellow-600" />
                )}
              </div>
            </div>

            <div className="mt-4 pt-4 border-t">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Despesas Associadas:</span>
                <span className="font-medium text-gray-800">
                  R$ {ferramenta.despesasAssociadas.toLocaleString('pt-BR')}
                </span>
              </div>
            </div>
          </div>
        ))}

        {filteredFerramentas.length === 0 && (
          <div className="col-span-full text-center py-12">
            <Wrench size={48} className="mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-600">Nenhuma ferramenta encontrada</h3>
            <p className="text-gray-500">Comece cadastrando uma nova ferramenta</p>
          </div>
        )}
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-gray-800 mb-6">
              {editingFerramenta ? 'Editar Ferramenta' : 'Nova Ferramenta'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nome
                  </label>
                  <input
                    type="text"
                    value={formData.nome}
                    onChange={(e) => setFormData(prev => ({ ...prev, nome: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Nome da ferramenta"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Quantidade
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={formData.quantidade || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, quantidade: parseInt(e.target.value) || 1 }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="1"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Descrição
                </label>
                <textarea
                  rows={3}
                  value={formData.descricao}
                  onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Descrição detalhada da ferramenta"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Data de Compra
                  </label>
                  <input
                    type="date"
                    value={formData.dataCompra}
                    onChange={(e) => setFormData(prev => ({ ...prev, dataCompra: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Próxima Manutenção
                  </label>
                  <input
                    type="date"
                    value={formData.proximaManutencao}
                    onChange={(e) => setFormData(prev => ({ ...prev, proximaManutencao: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Despesas Associadas
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.despesasAssociadas || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, despesasAssociadas: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Digite o valor"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={handleCloseForm}
                  className="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Salvando...' : (editingFerramenta ? 'Atualizar' : 'Salvar')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Ferramentas;