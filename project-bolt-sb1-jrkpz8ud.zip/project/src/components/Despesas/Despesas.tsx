import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Plus, Search, Edit, Trash2, Calendar, DollarSign, CreditCard, Wallet, Banknote, TrendingDown } from 'lucide-react';

interface Despesa {
  id: string;
  descricao: string;
  valor: number;
  categoria: string;
  data_vencimento: string;
  status: 'pendente' | 'pago' | 'vencido';
  observacoes?: string;
  tipo_saldo?: 'conta' | 'dinheiro';
  created_at: string;
}

export default function Despesas() {
  const [despesas, setDespesas] = useState<Despesa[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState<string | null>(null);
  const [paymentType, setPaymentType] = useState<'conta' | 'dinheiro'>('conta');
  const [editingDespesa, setEditingDespesa] = useState<Despesa | null>(null);
  const [formData, setFormData] = useState({
    descricao: '',
    valor: '',
    categoria: '',
    data_vencimento: '',
    status: 'pendente' as const,
    observacoes: '',
    tipo_saldo: 'conta' as const
  });

  useEffect(() => {
    fetchDespesas();
  }, []);

  const fetchDespesas = async () => {
    try {
      const { data, error } = await supabase
        .from('despesas')
        .select('*')
        .order('data_vencimento', { ascending: true });

      if (error) throw error;
      setDespesas(data || []);
    } catch (error) {
      console.error('Erro ao buscar despesas:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const despesaData = {
        descricao: formData.descricao,
        valor: parseFloat(formData.valor),
        categoria: formData.categoria,
        data_vencimento: formData.data_vencimento,
        status: formData.status,
        observacoes: formData.observacoes || null,
        tipo_saldo: formData.tipo_saldo
      };

      if (editingDespesa) {
        // Se está editando uma despesa que já foi paga, atualizar o movimento financeiro
        if (editingDespesa.status === 'pago') {
          const { error: movimentoError } = await supabase
            .from('movimentos_financeiros')
            .update({
              categoria: despesaData.categoria,
              descricao: `Pagamento - ${despesaData.descricao}`,
              valor: despesaData.valor,
              data: editingDespesa.data_pagamento || new Date().toISOString().split('T')[0],
              tipo_saldo: despesaData.tipo_saldo
            })
            .eq('referencia_id', editingDespesa.id)
            .eq('referencia_tipo', 'despesa');

          if (movimentoError) {
            console.warn('Erro ao atualizar movimento financeiro:', movimentoError);
          }
        }

        const { error } = await supabase
          .from('despesas')
          .update(despesaData)
          .eq('id', editingDespesa.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('despesas')
          .insert([despesaData]);

        if (error) throw error;
      }

      await fetchDespesas();
      resetForm();
      setShowModal(false);
    } catch (error) {
      console.error('Erro ao salvar despesa:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir esta despesa?')) return;

    try {
      // Primeiro, remover movimento financeiro associado se existir
      const { error: movimentoError } = await supabase
        .from('movimentos_financeiros')
        .delete()
        .eq('referencia_id', id)
        .eq('referencia_tipo', 'despesa');

      if (movimentoError) {
        console.warn('Erro ao remover movimento financeiro associado:', movimentoError);
      }

      // Depois, remover a despesa
      const { error } = await supabase
        .from('despesas')
        .delete()
        .eq('id', id);

      if (error) throw error;
      await fetchDespesas();
    } catch (error) {
      console.error('Erro ao excluir despesa:', error);
    }
  };

  const markAsPaid = async (id: string) => {
    setShowPaymentModal(id);
  };

  const confirmPayment = async () => {
    if (!showPaymentModal) return;
    
    try {
      const despesa = despesas.find(d => d.id === showPaymentModal);
      if (!despesa) return;

      const dataPagamento = new Date().toISOString().split('T')[0];

      // Atualizar despesa como paga
      const { error: despesaError } = await supabase
        .from('despesas')
        .update({
          status: 'pago',
          data_pagamento: dataPagamento,
          tipo_saldo: paymentType
        })
        .eq('id', showPaymentModal);

      if (despesaError) throw despesaError;

      // Verificar se já existe movimento financeiro para esta despesa
      const { data: existingMovimento } = await supabase
        .from('movimentos_financeiros')
        .select('id')
        .eq('referencia_id', showPaymentModal)
        .eq('referencia_tipo', 'despesa')
        .single();

      // Se não existe, criar movimento financeiro automático
      if (!existingMovimento) {
      const { error: movimentoError } = await supabase
        .from('movimentos_financeiros')
        .insert([{
          tipo: 'saida',
          categoria: despesa.categoria,
          descricao: `Pagamento - ${despesa.descricao}`,
          valor: despesa.valor,
          data: dataPagamento,
          status: 'pago',
          recorrente: false,
          tipo_saldo: paymentType,
          referencia_id: showPaymentModal,
          referencia_tipo: 'despesa'
        }]);

      if (movimentoError) throw movimentoError;
      } else {
        // Se já existe, atualizar o movimento existente
        const { error: updateMovimentoError } = await supabase
          .from('movimentos_financeiros')
          .update({
            categoria: despesa.categoria,
            descricao: `Pagamento - ${despesa.descricao}`,
            valor: despesa.valor,
            data: dataPagamento,
            status: 'pago',
            tipo_saldo: paymentType
          })
          .eq('referencia_id', showPaymentModal)
          .eq('referencia_tipo', 'despesa');

        if (updateMovimentoError) throw updateMovimentoError;
      }

      await fetchDespesas();
      setShowPaymentModal(null);
      setPaymentType('conta');
    } catch (error) {
      console.error('Erro ao marcar como pago:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      descricao: '',
      valor: '',
      categoria: '',
      data_vencimento: '',
      status: 'pendente',
      observacoes: '',
      tipo_saldo: 'conta'
    });
    setEditingDespesa(null);
  };

  const openEditModal = (despesa: Despesa) => {
    setEditingDespesa(despesa);
    setFormData({
      descricao: despesa.descricao,
      valor: despesa.valor.toString(),
      categoria: despesa.categoria,
      data_vencimento: despesa.data_vencimento,
      status: despesa.status,
      observacoes: despesa.observacoes || '',
      tipo_saldo: despesa.tipo_saldo || 'conta'
    });
    setShowModal(true);
  };

  const filteredDespesas = despesas.filter(despesa =>
    despesa.descricao.toLowerCase().includes(searchTerm.toLowerCase()) ||
    despesa.categoria.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pago': return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
      case 'vencido': return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300';
      default: return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Despesas</h1>
        <button
          onClick={() => {
            resetForm();
            setShowModal(true);
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Nova Despesa
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Buscar despesas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Descrição
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Categoria
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Valor
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Vencimento
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {filteredDespesas.map((despesa) => (
                <tr key={despesa.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {despesa.descricao}
                    </div>
                    {despesa.observacoes && (
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        {despesa.observacoes}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {despesa.categoria}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    R$ {despesa.valor.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {new Date(despesa.data_vencimento).toLocaleDateString('pt-BR')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 rounded text-xs ${getStatusColor(despesa.status)}`}>
                      {despesa.status.charAt(0).toUpperCase() + despesa.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2">
                      {despesa.status === 'pendente' && (
                        <button
                          onClick={() => markAsPaid(despesa.id)}
                          className="inline-flex items-center space-x-1 bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700 transition-colors"
                          title="Marcar como Pago"
                        >
                          <CreditCard className="w-4 h-4" />
                          <span>Marcar como Pago</span>
                        </button>
                      )}
                      <button
                        onClick={() => openEditModal(despesa)}
                        className="inline-flex items-center space-x-1 bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 transition-colors"
                        title="Editar"
                      >
                        <Edit className="w-4 h-4" />
                        <span>Editar</span>
                      </button>
                      <button
                        onClick={() => handleDelete(despesa.id)}
                        className="inline-flex items-center space-x-1 bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700 transition-colors"
                        title="Excluir"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span>Excluir</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredDespesas.length === 0 && (
          <div className="text-center py-8">
            <DollarSign className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900 dark:text-white">Nenhuma despesa encontrada</h3>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {searchTerm ? 'Tente ajustar sua busca.' : 'Comece criando uma nova despesa.'}
            </p>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h2 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
              {editingDespesa ? 'Editar Despesa' : 'Nova Despesa'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Descrição
                </label>
                <input
                  type="text"
                  required
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Categoria
                </label>
                <input
                  type="text"
                  required
                  value={formData.categoria}
                  onChange={(e) => setFormData({ ...formData, categoria: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Valor
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={formData.valor}
                  onChange={(e) => setFormData({ ...formData, valor: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Data de Vencimento
                </label>
                <input
                  type="date"
                  required
                  value={formData.data_vencimento}
                  onChange={(e) => setFormData({ ...formData, data_vencimento: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Status
                </label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                >
                  <option value="pendente">Pendente</option>
                  <option value="pago">Pago</option>
                  <option value="vencido">Vencido</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Tipo de Pagamento
                </label>
                <select
                  value={formData.tipo_saldo}
                  onChange={(e) => setFormData({ ...formData, tipo_saldo: e.target.value as any })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                >
                  <option value="conta">Conta Bancária</option>
                  <option value="dinheiro">Dinheiro</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Observações
                </label>
                <textarea
                  value={formData.observacoes}
                  onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  {editingDespesa ? 'Atualizar' : 'Criar'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Confirmação de Pagamento */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">
              Confirmar Pagamento
            </h3>
            
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Como a despesa será paga?
            </p>
            
            <div className="space-y-3 mb-6">
              <label className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                <input
                  type="radio"
                  name="paymentType"
                  value="conta"
                  checked={paymentType === 'conta'}
                  onChange={(e) => setPaymentType(e.target.value as any)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                />
                <div className="flex items-center space-x-2">
                  <Wallet className="text-blue-600" size={20} />
                  <div>
                    <p className="font-medium text-gray-800 dark:text-white">Conta Bancária</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">PIX, Transferência, Débito, Cartão</p>
                  </div>
                </div>
              </label>
              
              <label className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                <input
                  type="radio"
                  name="paymentType"
                  value="dinheiro"
                  checked={paymentType === 'dinheiro'}
                  onChange={(e) => setPaymentType(e.target.value as any)}
                  className="h-4 w-4 text-green-600 focus:ring-green-500"
                />
                <div className="flex items-center space-x-2">
                  <Banknote className="text-green-600" size={20} />
                  <div>
                    <p className="font-medium text-gray-800 dark:text-white">Dinheiro</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Pagamento em espécie</p>
                  </div>
                </div>
              </label>
            </div>
            
            <div className="flex space-x-3">
              <button
                onClick={() => {
                  setShowPaymentModal(null);
                  setPaymentType('conta');
                }}
                className="flex-1 px-4 py-2 text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={confirmPayment}
                className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                Confirmar Pagamento
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}