import jsPDF from 'jspdf';

interface ClienteData {
  nome: string;
  endereco: {
    rua: string;
    numero: string;
    bairro: string;
    cidade: string;
    estado: string;
    cep: string;
  };
  telefone: string;
  email?: string;
}

interface OrcamentoData {
  id: string;
  clienteNome: string;
  descricao: string;
  valor: number;
  dataGerado: string;
  observacoes?: string;
  numeroOrcamento?: string;
  dataEmissao?: string;
  responsavel?: string;
}

export const generateOrcamentoPDF = (orcamento: OrcamentoData, cliente: ClienteData, showAddress: boolean = true) => {
  try {
    const doc = new jsPDF();
    
    // Configurações
    const pageWidth = doc.internal.pageSize.width;
    const pageHeight = doc.internal.pageSize.height;
    const margin = 8; // Margem mínima próxima às bordas
    const contentWidth = pageWidth - (margin * 2);
    
    let currentY = margin;

    // Adicionar imagem de fundo com transparência
    const addBackgroundImage = async () => {
      try {
        // Carregar a imagem
        const img = new Image();
        img.crossOrigin = 'anonymous';
        
        return new Promise((resolve, reject) => {
          img.onload = () => {
            try {
              // Criar canvas para aplicar transparência
              const canvas = document.createElement('canvas');
              const ctx = canvas.getContext('2d');
              
              if (!ctx) {
                resolve(null);
                return;
              }
              
              // Definir tamanho do canvas
              canvas.width = img.width;
              canvas.height = img.height;
              
              // Aplicar transparência (30% de opacidade)
              ctx.globalAlpha = 0.3;
              ctx.drawImage(img, 0, 0);
              
              // Converter para base64
              const dataURL = canvas.toDataURL('image/png');
              
              // Adicionar ao PDF centralizado
              const imgWidth = pageWidth * 0.6; // 60% da largura da página
              const imgHeight = (img.height / img.width) * imgWidth;
              const imgX = (pageWidth - imgWidth) / 2;
              const imgY = (pageHeight - imgHeight) / 2;
              
              doc.addImage(dataURL, 'PNG', imgX, imgY, imgWidth, imgHeight);
              resolve(null);
            } catch (error) {
              console.warn('Erro ao processar imagem de fundo:', error);
              resolve(null);
            }
          };
          
          img.onerror = () => {
            console.warn('Erro ao carregar imagem de fundo');
            resolve(null);
          };
          
          img.src = 'https://i.ibb.co/mfrTp0g/imagem-2025-09-01-094313593.png';
        });
      } catch (error) {
        console.warn('Erro ao adicionar imagem de fundo:', error);
        return null;
      }
    };

    // Tentar adicionar imagem de fundo
    addBackgroundImage().then(() => {
      // Continuar com o conteúdo do PDF
      generatePDFContent();
    }).catch(() => {
      // Se falhar, continuar sem a imagem
      generatePDFContent();
    });

    const generatePDFContent = () => {
      // Dados do cliente - compactos no topo
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text('Cliente:', margin, currentY);
      doc.setFont('helvetica', 'normal');
      doc.text(cliente.nome, margin + 20, currentY);
      
      currentY += 8;
      
      if (showAddress && cliente.endereco.rua) {
        doc.setFont('helvetica', 'bold');
        doc.text('Endereço:', margin, currentY);
        doc.setFont('helvetica', 'normal');
        const enderecoCompleto = `${cliente.endereco.rua}, ${cliente.endereco.numero} - ${cliente.endereco.bairro}`;
        doc.text(enderecoCompleto, margin + 24, currentY);
        currentY += 8;
      }
      
      doc.setFont('helvetica', 'bold');
      doc.text('Telefone:', margin, currentY);
      doc.setFont('helvetica', 'normal');
      doc.text(cliente.telefone, margin + 24, currentY);
      
      // Data de emissão na mesma linha do telefone (lado direito)
      doc.setFont('helvetica', 'bold');
      doc.text('Data:', pageWidth - 60, currentY);
      doc.setFont('helvetica', 'normal');
      doc.text(new Date(orcamento.dataGerado).toLocaleDateString('pt-BR'), pageWidth - 35, currentY);
      
      currentY += 15; // Espaço antes do grid

      // Grid GRANDE ocupando a maior parte da página (6 linhas x 4 colunas)
      const gridStartY = currentY;
      const gridWidth = contentWidth;
      const gridHeight = pageHeight - currentY - 60; // Deixar espaço para rodapé
      const cellWidth = gridWidth / 4; // 4 colunas
      const cellHeight = gridHeight / 6; // 6 linhas
      
      // Desenhar grid com linhas mais grossas
      doc.setDrawColor(0, 0, 0);
      doc.setLineWidth(1.2);
      
      // Linhas horizontais
      for (let i = 0; i <= 6; i++) {
        doc.line(margin, gridStartY + (i * cellHeight), margin + gridWidth, gridStartY + (i * cellHeight));
      }
      
      // Linhas verticais
      for (let i = 0; i <= 4; i++) {
        doc.line(margin + (i * cellWidth), gridStartY, margin + (i * cellWidth), gridStartY + gridHeight);
      }
      
      currentY = gridStartY + gridHeight + 10;

      // Campos de responsável e data de execução - compactos
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text('Responsável pela Execução:', margin, currentY);
      doc.line(margin + 50, currentY + 1, margin + 100, currentY + 1);
      
      doc.text('Data de Execução:', margin + 110, currentY);
      doc.line(margin + 145, currentY + 1, pageWidth - margin, currentY + 1);
      
      currentY += 12;

      // Informações do orçamento (se fornecidas) - compactas
      if (orcamento.descricao || orcamento.valor > 0) {
        doc.setFontSize(9);
        doc.setFont('helvetica', 'bold');
        doc.text('OBSERVAÇÕES:', margin, currentY);
        
        currentY += 6;
        
        if (orcamento.descricao) {
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8);
          const splitDescription = doc.splitTextToSize(orcamento.descricao, contentWidth - 10);
          doc.text(splitDescription, margin, currentY);
          currentY += splitDescription.length * 3 + 3;
        }
        
        if (orcamento.valor && orcamento.valor > 0) {
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(10);
          doc.text(`VALOR ESTIMADO: R$ ${orcamento.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, margin, currentY);
          currentY += 6;
        }
      }

      // Rodapé minimalista
      const footerY = pageHeight - 8;
      if (currentY < footerY - 5) {
        doc.setDrawColor(200, 200, 200);
        doc.setLineWidth(0.3);
        doc.line(margin, footerY - 3, pageWidth - margin, footerY - 3);
        
        doc.setTextColor(120, 120, 120);
        doc.setFontSize(6);
        doc.setFont('helvetica', 'normal');
        doc.text('Orçamento gerado pelo Sistema de Gestão', pageWidth / 2, footerY, { align: 'center' });
      }
      
      // Salvar PDF
      const clienteNome = cliente.nome.replace(/[^a-zA-Z0-9\s]/g, '').replace(/\s+/g, '_');
      const dataAtual = new Date().toISOString().slice(0, 10);
      const numeroOrc = orcamento.numeroOrcamento || `ORC-${orcamento.id.slice(-6).toUpperCase()}`;
      const fileName = `Orcamento_${numeroOrc}_${clienteNome}_${dataAtual}.pdf`;
      
      doc.save(fileName);
    };

    // Se não conseguir carregar a imagem, gerar PDF sem ela
    setTimeout(() => {
      generatePDFContent();
    }, 2000);
    
  } catch (error) {
    console.error('Erro ao gerar PDF:', error);
    alert('Erro ao gerar PDF. Tente novamente.');
  }
};