import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { AppProvider } from './contexts/AppContext';
import Login from './components/Login';
import Header from './components/Layout/Header';
import Sidebar from './components/Layout/Sidebar';
import Dashboard from './components/Dashboard/Dashboard';
import Clientes from './components/Cadastros/Clientes';
import Colaboradores from './components/Cadastros/Colaboradores';
import Veiculos from './components/Cadastros/Veiculos';
import Ferramentas from './components/Cadastros/Ferramentas';
import Estabelecimentos from './components/Cadastros/Estabelecimentos';
import Atendimentos from './components/Atendimentos/Atendimentos';
import Orcamentos from './components/Orcamentos/Orcamentos';
import PedidosAprimorados from './components/Pedidos/PedidosAprimorados';
import RecuperacaoVendas from './components/Recuperacao/RecuperacaoVendas';
import Financeiro from './components/Financeiro/Financeiro';
import Despesas from './components/Despesas/Despesas';
import OrcamentosAprimorados from './components/Orcamentos/OrcamentosAprimorados';

const AppContent: React.FC = () => {
  const { user } = useAuth();
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [orcamentoPrefilledData, setOrcamentoPrefilledData] = useState<any>(null);

  if (!user) {
    return <Login />;
  }

  const handleNavigateToOrcamentos = (atendimentoData?: any) => {
    setOrcamentoPrefilledData(atendimentoData);
    setSidebarOpen(false); // Fechar sidebar no mobile
    setCurrentPage('orcamentos');
  };

  const handleNavigateToOrcamentosFromRecuperacao = (clienteData?: any) => {
    setOrcamentoPrefilledData(clienteData);
    setCurrentPage('orcamentos');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />;
      case 'clientes':
        return <Clientes />;
      case 'colaboradores':
        return <Colaboradores />;
      case 'veiculos':
        return <Veiculos />;
      case 'estabelecimentos':
        return <Estabelecimentos />;
      case 'atendimentos':
        return <Atendimentos onNavigateToOrcamentos={handleNavigateToOrcamentos} />;
      case 'orcamentos':
        return <OrcamentosAprimorados prefilledData={orcamentoPrefilledData} />;
      case 'pedidos':
        return <PedidosAprimorados />;
      case 'ferramentas':
        return <Ferramentas />;
      case 'despesas':
        return <Despesas />;
      case 'recuperacao':
        return <RecuperacaoVendas onNavigateToOrcamentos={handleNavigateToOrcamentosFromRecuperacao} />;
      case 'financeiro':
        return <Financeiro />;
      case 'calculox':
        window.open('https://calculox.netlify.app/', '_blank');
        return <Dashboard />;
      default:
        return <Dashboard />;
    }
  };

  // Limpar dados preenchidos quando mudar de página
  const handlePageChange = (page: string) => {
    if (page !== 'orcamentos') {
      setOrcamentoPrefilledData(null);
    }
    setCurrentPage(page);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex transition-colors">
      <Sidebar
        currentPage={currentPage}
        onPageChange={handlePageChange}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />
      
      <div className="flex-1 flex flex-col">
        <Header onMenuToggle={() => setSidebarOpen(!sidebarOpen)} />
        
        <main className="flex-1 p-4 sm:p-6 overflow-y-auto bg-gray-50 dark:bg-gray-900 transition-colors">
          {renderPage()}
        </main>
      </div>
    </div>
  );
};

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppProvider>
          <AppContent />
        </AppProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;