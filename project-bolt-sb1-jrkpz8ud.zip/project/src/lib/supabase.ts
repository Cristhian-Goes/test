import { createClient } from '@supabase/supabase-js'

// Validação de variáveis de ambiente
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Variáveis de ambiente do Supabase não encontradas. Verifique o arquivo .env.')
  console.error('VITE_SUPABASE_URL:', supabaseUrl)
  console.error('VITE_SUPABASE_ANON_KEY:', supabaseAnonKey ? 'Definida' : 'Não definida')
  
  // Usar valores padrão para desenvolvimento se as variáveis não estiverem definidas
  const defaultUrl = 'https://placeholder.supabase.co'
  const defaultKey = 'placeholder-key'
  
  console.warn('Usando valores padrão para desenvolvimento. A aplicação pode não funcionar corretamente.')
}

// Validação adicional de formato das URLs
const finalUrl = supabaseUrl || 'https://placeholder.supabase.co'
const finalKey = supabaseAnonKey || 'placeholder-key'

if (supabaseUrl && (!supabaseUrl.startsWith('https://') || !supabaseUrl.includes('.supabase.co'))) {
  console.error('URL do Supabase inválida:', supabaseUrl)
}

// Configurações de segurança para o cliente Supabase
export const supabase = createClient(finalUrl, finalKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
    flowType: 'pkce'
  },
  global: {
    headers: {
      'X-Client-Info': 'assis-calhas-system'
    }
  }
})

// Interceptador para logs de segurança (apenas em desenvolvimento)
if (import.meta.env.DEV) {
  const originalFrom = supabase.from;
  supabase.from = function(table: string) {
    console.log(`[SECURITY] Accessing table: ${table}`);
    return originalFrom.call(this, table);
  };
}

// Database types
export interface Database {
  public: {
    Tables: {
      clientes: {
        Row: {
          id: string
          nome: string
          cpf_cnpj: string
          endereco: any
          telefone: string
          email: string
          observacoes: string
          data_cadastro: string
          despesas_associadas: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          nome: string
          cpf_cnpj: string
          endereco: any
          telefone: string
          email: string
          observacoes?: string
          data_cadastro?: string
          despesas_associadas?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          nome?: string
          cpf_cnpj?: string
          endereco?: any
          telefone?: string
          email?: string
          observacoes?: string
          data_cadastro?: string
          despesas_associadas?: number
          created_at?: string
          updated_at?: string
        }
      }
      colaboradores: {
        Row: {
          id: string
          nome: string
          funcao: string
          salario: number
          telefone: string
          email: string
          data_entrada: string
          status: string
          despesas_associadas: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          nome: string
          funcao: string
          salario: number
          telefone: string
          email: string
          data_entrada: string
          status?: string
          despesas_associadas?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          nome?: string
          funcao?: string
          salario?: number
          telefone?: string
          email?: string
          data_entrada?: string
          status?: string
          despesas_associadas?: number
          created_at?: string
          updated_at?: string
        }
      }
      orcamentos: {
        Row: {
          id: string
          cliente_id: string
          cliente_nome: string
          descricao: string
          valor: number
          data_gerado: string
          status: string
          observacoes: string
          tipo_pagamento: string
          status_pagamento: string
          data_pagamento: string | null
          data_entrada_caixa: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          cliente_id: string
          cliente_nome: string
          descricao: string
          valor: number
          data_gerado?: string
          status?: string
          observacoes?: string
          tipo_pagamento?: string
          status_pagamento?: string
          data_pagamento?: string | null
          data_entrada_caixa?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          cliente_id?: string
          cliente_nome?: string
          descricao?: string
          valor?: number
          data_gerado?: string
          status?: string
          observacoes?: string
          tipo_pagamento?: string
          status_pagamento?: string
          data_pagamento?: string | null
          data_entrada_caixa?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      despesas: {
        Row: {
          id: string
          categoria: string
          subcategoria: string
          descricao: string
          valor: number
          data_vencimento: string
          data_pagamento: string | null
          status: string
          recorrente: boolean
          frequencia_recorrencia: string | null
          fornecedor: string
          observacoes: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          categoria: string
          subcategoria?: string
          descricao: string
          valor: number
          data_vencimento: string
          data_pagamento?: string | null
          status?: string
          recorrente?: boolean
          frequencia_recorrencia?: string | null
          fornecedor?: string
          observacoes?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          categoria?: string
          subcategoria?: string
          descricao?: string
          valor?: number
          data_vencimento?: string
          data_pagamento?: string | null
          status?: string
          recorrente?: boolean
          frequencia_recorrencia?: string | null
          fornecedor?: string
          observacoes?: string
          created_at?: string
          updated_at?: string
        }
      }
      atendimentos: {
        Row: {
          id: string
          cliente_id: string | null
          cliente_nome: string
          tipo: string
          descricao: string
          data: string | null
          status: string
          responsavel: string | null
          tipo_pagamento: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          cliente_id?: string | null
          cliente_nome: string
          tipo: string
          descricao: string
          data?: string | null
          status?: string
          responsavel?: string | null
          tipo_pagamento?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          cliente_id?: string | null
          cliente_nome?: string
          tipo?: string
          descricao?: string
          data?: string | null
          status?: string
          responsavel?: string | null
          tipo_pagamento?: string
          created_at?: string
          updated_at?: string
        }
      }
      pedidos: {
        Row: {
          id: string
          orcamento_id: string | null
          cliente_nome: string
          descricao: string
          valor: number
          status: string
          data_inicio: string | null
          data_final: string | null
          responsavel: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          orcamento_id?: string | null
          cliente_nome: string
          descricao: string
          valor: number
          status?: string
          data_inicio?: string | null
          data_final?: string | null
          responsavel: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          orcamento_id?: string | null
          cliente_nome?: string
          descricao?: string
          valor?: number
          status?: string
          data_inicio?: string | null
          data_final?: string | null
          responsavel?: string
          created_at?: string
          updated_at?: string
        }
      }
      veiculos: {
        Row: {
          id: string
          placa: string
          modelo: string
          ano: number | null
          motorista_responsavel: string | null
          status: string
          despesas_associadas: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          placa: string
          modelo: string
          ano?: number | null
          motorista_responsavel?: string | null
          status?: string
          despesas_associadas?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          placa?: string
          modelo?: string
          ano?: number | null
          motorista_responsavel?: string | null
          status?: string
          despesas_associadas?: number | null
          created_at?: string
          updated_at?: string
        }
      }
      ferramentas: {
        Row: {
          id: string
          nome: string
          descricao: string
          quantidade: number | null
          data_compra: string | null
          proxima_manutencao: string | null
          despesas_associadas: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          nome: string
          descricao: string
          quantidade?: number | null
          data_compra?: string | null
          proxima_manutencao?: string | null
          despesas_associadas?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          nome?: string
          descricao?: string
          quantidade?: number | null
          data_compra?: string | null
          proxima_manutencao?: string | null
          despesas_associadas?: number | null
          created_at?: string
          updated_at?: string
        }
      }
      estabelecimentos: {
        Row: {
          id: string
          nome: string
          endereco: any
          cnpj: string | null
          responsavel: string | null
          telefone: string | null
          email: string | null
          status: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          nome: string
          endereco?: any
          cnpj?: string | null
          responsavel?: string | null
          telefone?: string | null
          email?: string | null
          status?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          nome?: string
          endereco?: any
          cnpj?: string | null
          responsavel?: string | null
          telefone?: string | null
          email?: string | null
          status?: string
          created_at?: string
          updated_at?: string
        }
      }
      movimentos_financeiros: {
        Row: {
          id: string
          tipo: string
          categoria: string
          descricao: string
          valor: number | null
          data: string | null
          status: string
          recorrente: boolean | null
          referencia_id: string | null
          referencia_tipo: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          tipo: string
          categoria: string
          descricao: string
          valor?: number | null
          data?: string | null
          status?: string
          recorrente?: boolean | null
          referencia_id?: string | null
          referencia_tipo?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          tipo?: string
          categoria?: string
          descricao?: string
          valor?: number | null
          data?: string | null
          status?: string
          recorrente?: boolean | null
          referencia_id?: string | null
          referencia_tipo?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      parcelas_boleto: {
        Row: {
          id: string
          orcamento_id: string
          numero_parcela: number
          total_parcelas: number
          valor: number
          data_vencimento: string
          status: string
          data_recebimento: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          orcamento_id: string
          numero_parcela: number
          total_parcelas: number
          valor: number
          data_vencimento: string
          status?: string
          data_recebimento?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          orcamento_id?: string
          numero_parcela?: number
          total_parcelas?: number
          valor?: number
          data_vencimento?: string
          status?: string
          data_recebimento?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      parcelas_cartao: {
        Row: {
          id: string
          orcamento_id: string
          numero_parcela: number
          total_parcelas: number
          valor: number
          data_recebimento: string
          status: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          orcamento_id: string
          numero_parcela: number
          total_parcelas: number
          valor: number
          data_recebimento: string
          status?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          orcamento_id?: string
          numero_parcela?: number
          total_parcelas?: number
          valor?: number
          data_recebimento?: string
          status?: string
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}