import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user data
const mockUsers: User[] = [
  { id: '1', name: 'Administrador', email: 'admin@grafica505.com', role: 'admin' }
];

// Configuração de segurança
const SECURITY_CONFIG = {
  MAX_LOGIN_ATTEMPTS: 3,
  LOCKOUT_DURATION: 15 * 60 * 1000, // 15 minutos
  SESSION_TIMEOUT: 8 * 60 * 60 * 1000, // 8 horas
  PASSWORD_MIN_LENGTH: 8,
  REQUIRE_STRONG_PASSWORD: true
};

// Armazenamento seguro para tentativas de login
const loginAttempts = new Map<string, { count: number; lastAttempt: number; lockedUntil?: number }>();

// Função para validar força da senha
const validatePasswordStrength = (password: string): boolean => {
  if (password.length < SECURITY_CONFIG.PASSWORD_MIN_LENGTH) return false;
  if (!SECURITY_CONFIG.REQUIRE_STRONG_PASSWORD) return true;
  
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumbers = /\d/.test(password);
  const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
  
  return hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChar;
};

// Função para verificar se o usuário está bloqueado
const isUserLocked = (email: string): boolean => {
  const attempts = loginAttempts.get(email);
  if (!attempts) return false;
  
  if (attempts.lockedUntil && Date.now() < attempts.lockedUntil) {
    return true;
  }
  
  // Reset se o tempo de bloqueio passou
  if (attempts.lockedUntil && Date.now() >= attempts.lockedUntil) {
    loginAttempts.delete(email);
    return false;
  }
  
  return false;
};

// Função para registrar tentativa de login
const recordLoginAttempt = (email: string, success: boolean): void => {
  const now = Date.now();
  const attempts = loginAttempts.get(email) || { count: 0, lastAttempt: now };
  
  if (success) {
    loginAttempts.delete(email);
    return;
  }
  
  attempts.count += 1;
  attempts.lastAttempt = now;
  
  if (attempts.count >= SECURITY_CONFIG.MAX_LOGIN_ATTEMPTS) {
    attempts.lockedUntil = now + SECURITY_CONFIG.LOCKOUT_DURATION;
  }
  
  loginAttempts.set(email, attempts);
};

// Função para sanitizar entrada
const sanitizeInput = (input: string): string => {
  return input.trim().toLowerCase();
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    
    try {
      // Sanitizar entrada
      const sanitizedEmail = sanitizeInput(email);
      
      // Verificar se o usuário está bloqueado
      if (isUserLocked(sanitizedEmail)) {
        const attempts = loginAttempts.get(sanitizedEmail);
        const remainingTime = attempts?.lockedUntil ? Math.ceil((attempts.lockedUntil - Date.now()) / 60000) : 0;
        throw new Error(`Conta bloqueada. Tente novamente em ${remainingTime} minutos.`);
      }
      
      // Validar entrada
      if (!email || !password) {
        throw new Error('Email e senha são obrigatórios');
      }
      
      if (password.length < SECURITY_CONFIG.PASSWORD_MIN_LENGTH) {
        throw new Error(`Senha deve ter pelo menos ${SECURITY_CONFIG.PASSWORD_MIN_LENGTH} caracteres`);
      }
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
      // Verificar credenciais
      const foundUser = mockUsers.find(u => u.email === sanitizedEmail);
      const isValidPassword = foundUser && (
        (sanitizedEmail === 'admin@grafica505.com' && password === 'Grafica2025!')
      );
      
      if (foundUser && isValidPassword) {
        recordLoginAttempt(sanitizedEmail, true);
      setUser(foundUser);
      localStorage.setItem('user', JSON.stringify(foundUser));
        
        // Configurar timeout da sessão
        setTimeout(() => {
          logout();
        }, SECURITY_CONFIG.SESSION_TIMEOUT);
        
      setIsLoading(false);
      return true;
      } else {
        recordLoginAttempt(sanitizedEmail, false);
        throw new Error('Credenciais inválidas');
      }
    } catch (error) {
      setIsLoading(false);
      throw error;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
    // Limpar dados sensíveis da memória
    if (window.history && window.history.replaceState) {
      window.history.replaceState(null, '', window.location.pathname);
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};