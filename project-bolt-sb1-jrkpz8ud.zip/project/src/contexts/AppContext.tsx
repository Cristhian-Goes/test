import React, { createContext, useContext, useState, useEffect } from 'react';
import { Cliente, Colaborador, Atendimento, Orcamento, Pedido, MovimentoFinanceiro, DashboardStats } from '../types';

interface AppContextType {
  // Data
  clientes: Cliente[];
  colaboradores: Colaborador[];
  atendimentos: Atendimento[];
  orcamentos: Orcamento[];
  pedidos: Pedido[];
  movimentosFinanceiros: MovimentoFinanceiro[];
  
  // Actions
  addCliente: (cliente: Omit<Cliente, 'id' | 'dataCadastro'>) => void;
  updateCliente: (id: string, cliente: Omit<Cliente, 'id' | 'dataCadastro'>) => void;
  deleteCliente: (id: string) => void;
  addColaborador: (colaborador: Omit<Colaborador, 'id'>) => void;
  updateColaborador: (id: string, colaborador: Omit<Colaborador, 'id'>) => void;
  deleteColaborador: (id: string) => void;
  addAtendimento: (atendimento: Omit<Atendimento, 'id'>) => void;
  addOrcamento: (orcamento: Omit<Orcamento, 'id' | 'dataGerado'>) => void;
  addPedido: (pedido: Omit<Pedido, 'id' | 'dataInicio'>) => void;
  updateOrcamentoStatus: (id: string, status: Orcamento['status']) => void;
  updatePedidoStatus: (id: string, status: Pedido['status']) => void;
  
  // Stats
  dashboardStats: DashboardStats;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [colaboradores, setColaboradores] = useState<Colaborador[]>([]);
  const [atendimentos, setAtendimentos] = useState<Atendimento[]>([]);
  const [orcamentos, setOrcamentos] = useState<Orcamento[]>([]);
  const [pedidos, setPedidos] = useState<Pedido[]>([]);
  const [movimentosFinanceiros, setMovimentosFinanceiros] = useState<MovimentoFinanceiro[]>([]);

  // Initialize with mock data
  useEffect(() => {
    const mockClientes: Cliente[] = [
      {
        id: '1',
        nome: 'João Silva',
        cpfCnpj: '123.456.789-00',
        endereco: {
          rua: 'Rua das Flores',
          numero: '123',
          bairro: 'Centro',
          cidade: 'São Paulo',
          cep: '01234-567',
          estado: 'SP'
        },
        telefone: '(11) 99999-9999',
        email: 'joao@email.com',
        observacoes: 'Cliente preferencial',
        dataCadastro: '2024-01-15',
        despesasAssociadas: 2500
      },
      {
        id: '2',
        nome: 'Empresa ABC Ltda',
        cpfCnpj: '12.345.678/0001-90',
        endereco: {
          rua: 'Av. Paulista',
          numero: '1000',
          bairro: 'Bela Vista',
          cidade: 'São Paulo',
          cep: '01310-100',
          estado: 'SP'
        },
        telefone: '(11) 88888-8888',
        email: 'contato@empresaabc.com',
        observacoes: 'Empresa de grande porte',
        dataCadastro: '2024-02-10',
        despesasAssociadas: 15000
      }
    ];

    const mockColaboradores: Colaborador[] = [
      {
        id: '1',
        nome: 'Carlos Santos',
        funcao: 'Instalador',
        salario: 3500,
        telefone: '(11) 77777-7777',
        email: 'carlos@grafica505.com',
        dataEntrada: '2023-06-01',
        status: 'ativo',
        despesasAssociadas: 1200
      },
      {
        id: '2',
        nome: 'Ana Costa',
        funcao: 'Vendedora',
        salario: 4000,
        telefone: '(11) 66666-6666',
        email: 'ana@grafica505.com',
        dataEntrada: '2023-03-15',
        status: 'ativo',
        despesasAssociadas: 800
      }
    ];

    setClientes(mockClientes);
    setColaboradores(mockColaboradores);
  }, []);

  const addCliente = (clienteData: Omit<Cliente, 'id' | 'dataCadastro'>) => {
    const newCliente: Cliente = {
      ...clienteData,
      id: Date.now().toString(),
      dataCadastro: new Date().toISOString().split('T')[0]
    };
    setClientes(prev => [...prev, newCliente]);
  };

  const updateCliente = (id: string, clienteData: Omit<Cliente, 'id' | 'dataCadastro'>) => {
    setClientes(prev => prev.map(cliente => 
      cliente.id === id 
        ? { ...cliente, ...clienteData }
        : cliente
    ));
  };

  const deleteCliente = (id: string) => {
    setClientes(prev => prev.filter(cliente => cliente.id !== id));
  };
  const addColaborador = (colaboradorData: Omit<Colaborador, 'id'>) => {
    const newColaborador: Colaborador = {
      ...colaboradorData,
      id: Date.now().toString()
    };
    setColaboradores(prev => [...prev, newColaborador]);
  };

  const updateColaborador = (id: string, colaboradorData: Omit<Colaborador, 'id'>) => {
    setColaboradores(prev => prev.map(colaborador => 
      colaborador.id === id 
        ? { ...colaborador, ...colaboradorData }
        : colaborador
    ));
  };

  const deleteColaborador = (id: string) => {
    setColaboradores(prev => prev.filter(colaborador => colaborador.id !== id));
  };

  const addAtendimento = (atendimentoData: Omit<Atendimento, 'id'>) => {
    const newAtendimento: Atendimento = {
      ...atendimentoData,
      id: Date.now().toString()
    };
    setAtendimentos(prev => [...prev, newAtendimento]);
  };

  const addOrcamento = (orcamentoData: Omit<Orcamento, 'id' | 'dataGerado'>) => {
    const newOrcamento: Orcamento = {
      ...orcamentoData,
      id: Date.now().toString(),
      dataGerado: new Date().toISOString().split('T')[0]
    };
    setOrcamentos(prev => [...prev, newOrcamento]);
  };

  const addPedido = (pedidoData: Omit<Pedido, 'id' | 'dataInicio'>) => {
    const newPedido: Pedido = {
      ...pedidoData,
      id: Date.now().toString(),
      dataInicio: new Date().toISOString().split('T')[0]
    };
    setPedidos(prev => [...prev, newPedido]);
  };

  const updateOrcamentoStatus = (id: string, status: Orcamento['status']) => {
    setOrcamentos(prev => prev.map(orc => 
      orc.id === id ? { ...orc, status } : orc
    ));
  };

  const updatePedidoStatus = (id: string, status: Pedido['status']) => {
    setPedidos(prev => prev.map(ped => 
      ped.id === id ? { ...ped, status } : ped
    ));
  };

  const dashboardStats: DashboardStats = {
    clientesTotal: clientes.length,
    orcamentosAbertos: orcamentos.filter(o => o.status === 'pendente' || o.status === 'enviado').length,
    pedidosAndamento: pedidos.filter(p => p.status !== 'finalizado').length,
    faturamentoMes: 45000,
    despesasMes: 18000,
    saldoAtual: 127000
  };

  return (
    <AppContext.Provider value={{
      clientes,
      colaboradores,
      atendimentos,
      orcamentos,
      pedidos,
      movimentosFinanceiros,
      addCliente,
      updateCliente,
      deleteCliente,
      addColaborador,
      updateColaborador,
      deleteColaborador,
      addAtendimento,
      addOrcamento,
      addPedido,
      updateOrcamentoStatus,
      updatePedidoStatus,
      dashboardStats
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};