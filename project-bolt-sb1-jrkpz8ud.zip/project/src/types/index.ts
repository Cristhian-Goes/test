export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'financial' | 'sales' | 'installer';
  avatar?: string;
}

export interface Cliente {
  id: string;
  nome: string;
  cpfCnpj: string;
  endereco: {
    rua: string;
    numero: string;
    bairro: string;
    cidade: string;
    cep: string;
    estado: string;
  };
  telefone: string;
  email: string;
  observacoes: string;
  dataCadastro: string;
  despesasAssociadas: number;
}

export interface Colaborador {
  id: string;
  nome: string;
  funcao: string;
  salario: number;
  telefone: string;
  email: string;
  dataEntrada: string;
  status: 'ativo' | 'inativo';
  despesasAssociadas: number;
}

export interface Veiculo {
  id: string;
  placa: string;
  modelo: string;
  ano: number;
  motoristaResponsavel: string;
  status: 'ativo' | 'manutencao' | 'inativo';
  despesasAssociadas: number;
}

export interface Ferramenta {
  id: string;
  nome: string;
  descricao: string;
  quantidade: number;
  dataCompra: string;
  proximaManutencao: string;
  despesasAssociadas: number;
}

export interface Atendimento {
  id: string;
  clienteId: string;
  clienteNome: string;
  tipo: 'interno' | 'externo';
  descricao: string;
  data: string;
}

export interface Orcamento {
  id: string;
  clienteId: string;
  clienteNome: string;
  descricao: string;
  anexo?: string;
  valor: number | null;
  dataGerado: string;
  status: 'atrasado' | 'pendente' | 'aprovado' | 'recusado';
  observacoes: string;
  tipoAtendimento: 'interno' | 'externo';
  tipoPagamento: 'dinheiro' | 'pix' | 'debito' | 'credito' | 'boleto' | 'transferencia';
  statusPagamento: 'pendente' | 'pago' | 'parcial' | 'atrasado';
  dataPagamento?: string;
  dataEntradaCaixa?: string;
  tipoAtendimento?: 'interno' | 'externo';
  numeroOrcamento: string;
  dataEmissao: string;
  responsavel: string;
}

export interface Pedido {
  id: string;
  orcamentoId: string;
  clienteNome: string;
  descricao: string;
  valor: number;
  status: 'aguardando_corte' | 'em_corte' | 'aguardando_instalacao' | 'instalado_concluido';
  dataInicio: string;
  dataFinal?: string;
  responsavel: string;
  executores: string[];
}

export interface MovimentoFinanceiro {
  id: string;
  tipo: 'entrada' | 'saida';
  categoria: string;
  descricao: string;
  valor: number | null;
  data: string;
  status: 'pendente' | 'pago' | 'recebido';
  recorrente: boolean;
  tipoSaldo?: 'conta' | 'dinheiro';
}

export interface DashboardStats {
  clientesTotal: number;
  orcamentosAbertos: number;
  pedidosAndamento: number;
  faturamentoMes: number;
  despesasMes: number;
  saldoAtual: number;
}

export interface Despesa {
  id: string;
  categoria: string;
  subcategoria: string;
  descricao: string;
  valor: number;
  dataVencimento: string;
  dataPagamento?: string;
  status: 'pendente' | 'pago' | 'atrasado' | 'cancelado';
  recorrente: boolean;
  frequenciaRecorrencia?: 'mensal' | 'bimestral' | 'trimestral' | 'semestral' | 'anual';
  fornecedor: string;
  observacoes: string;
  tipoSaldo?: 'conta' | 'dinheiro';
}